// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;

import {Ledger} from "./Ledger.sol";
import {Keys} from "./Keys.sol";

/// DISPOSABLE LAB: authentic signed claims, never admission or current authority.
abstract contract SignedClaimArchiveBase {
    enum ProofLevel { NONE, AUTHOR_SIGNATURE_VERIFIED }
    struct BodyInput { uint16 leaf; bytes body; }
    struct ClaimCell {
        Ledger.Intent source;
        bytes32 actionsHash;
        bytes32 r;
        bytes32 s;
        uint64 bodyCoverage;
        uint64 retainedAt;
        address firstImporter;
        uint16 leafCount;
        uint8 v;
        ProofLevel proof;
    }
    struct CachedBody { bool exists; bytes data; }
    struct Posting { bytes32 claimId; uint16 leaf; }

    error E_BOUNDS(uint8 code);
    error E_SIGNATURE();
    error E_SOURCE_UNSUPPORTED();
    error E_UNKNOWN_CLAIM(bytes32 claimId);
    error E_LEAF(uint16 leaf);
    error E_BODY_LEAF(uint16 leaf);
    error E_BODY_MISMATCH(uint16 leaf, bytes32 expected, bytes32 actual);

    uint256 public constant MAX_ACTIONS = 64;
    uint256 public constant MAX_BODY_INPUTS = 64;
    uint256 public constant MAX_BODY_BYTES_PER_CALL = 8192;
    uint256 public constant MAX_RETAIN_CALLDATA = 37_316;
    uint256 public constant MAX_ATTACH_CALLDATA = 18_468;

    // ABI-only RED stub: no retention semantics until the observed behavioral gate.
    function retainSignedClaim(Ledger.Intent calldata, Ledger.Action[] calldata, bytes calldata, BodyInput[] calldata)
        external virtual returns (bytes32 claimId) {}
    function attachBodies(bytes32, BodyInput[] calldata) external virtual {}
    function claim(bytes32) external view virtual returns (
        Ledger.Intent memory source, bytes32 actionsHash, uint16 leafCount,
        bytes32 r, bytes32 s, uint8 v, uint64 bodyCoverage,
        ProofLevel proof, address firstImporter, uint64 retainedAt
    ) {}
    function actionAt(bytes32, uint16) external view virtual returns (Ledger.Action memory action) {}
    function selectedRecord(bytes32, uint16) external view virtual returns (
        bytes32 recordId, bytes32 typeId, bool claimBodyAttached, bytes memory body
    ) {}
    function signedRecordClaimCount(bytes32) external view virtual returns (uint64 count) {}
    function signedRecordClaimAt(bytes32, uint64) external view virtual returns (bytes32 claimId, uint16 leaf) {}
}

contract SignedClaimArchivePacked is SignedClaimArchiveBase {
    struct PackedAction {
        uint256 meta;
        bytes32 typeId;
        bytes32 bodyHashOrRecordId;
        bytes32 purpose;
        bytes32 subject;
        bytes32 role;
        bytes32 target;
        bytes32 salt;
    }
}

contract SignedClaimArchive is SignedClaimArchivePacked {}
