// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;
import {FilesCarrierIndexTest} from "./FilesCarrierProfile.t.sol";
import {LiveFilesLayout,LiveFilesDescriptorRule,LiveFilesRootRule,LiveFilesChildRule,LiveFilesIndex} from "./LiveFilesProfile.sol";
import {FilesDirectoryIndex} from "./FilesDirectoryProfile.sol";
import {Keys} from "../src/Keys.sol";

contract LiveFitProvider {
    function quote(bytes32) external pure returns(uint128,bool){return (42,true);}
}
contract LiveFilesTest is FilesCarrierIndexTest {
    bytes32[3] lt; bytes32[3] lh;
    LiveFitProvider provider;
    function setUp() public override {
        super.setUp();provider=new LiveFitProvider();
        address rule=address(new LiveFilesDescriptorRule(address(this),BINARY));lh[0]=rule.codehash;
        lt[0]=registry.register(LiveFilesLayout.DESCRIPTOR,rule,new bytes32[](0));
        bytes32[] memory refs=new bytes32[](1);refs[0]=lt[0];
        rule=address(new LiveFilesRootRule());lh[1]=rule.codehash;lt[1]=registry.register(LiveFilesLayout.ROOT,rule,refs);
        rule=address(new LiveFilesChildRule([rt,ct,ts[2],ts[3],lt[1]]));lh[2]=rule.codehash;
        refs=new bytes32[](2);refs[1]=lt[0];lt[2]=registry.register(LiveFilesLayout.CHILD,rule,refs);
    }
    function recipe() internal view returns(bytes memory){
        return abi.encode(LiveFilesLayout.Recipe(1,block.chainid,LiveFilesLayout.VENUE,address(provider),address(provider).codehash,
            LiveFilesLayout.SELECTOR,bytes32(uint256(7)),BINARY,1,50000,64,address(this)));
    }
    function rejected(bytes32 t,bytes memory b) internal {
        uint64 before_=admissions();(bool ok,)=address(ledger).call(abi.encodeCall(ledger.publish,(t,b)));
        require(!ok,"invalid live fact admitted");require(admissions()==before_,"failed live admission leaked");
    }
    function test_live_descriptor_admits_exact_recipe() public {
        (bool ok,)=address(ledger).call(abi.encodeCall(ledger.publish,(lt[0],recipe())));
        require(ok,"exact finite live recipe rejected");
    }
    function test_live_checked_composition_and_directed_parent_matrix() public {
        bytes32 d=ledger.publish(lt[0],recipe());bytes32 f=ledger.create(bytes32(uint256(51)));bytes32 other=ledger.create(bytes32(uint256(52)));
        bytes32 root=ledger.publish(lt[1],abi.encode(d,f));
        bytes32 stored=ledger.publish(ts[0],abi.encode(sha256("")));
        bytes32 desc=ledger.publish(ts[1],abi.encode(stored,uint256(1),uint256(0),uint256(1),uint256(0),sha256(""),uint256(0),uint256(0),bytes32(0),uint256(0),sha256("")));
        bytes32 inlineRoot=ledger.publish(rt,abi.encode(f));bytes32 inlineChild=ledger.publish(ct,abi.encode(inlineRoot,f));
        bytes32 carrierRoot=ledger.publish(ts[2],abi.encode(desc,f));bytes32 carrierChild=ledger.publish(ts[3],abi.encode(carrierRoot,desc,f));
        bytes32 child=ledger.publish(lt[2],abi.encode(root,d,f));
        bytes32[6] memory p=[inlineRoot,inlineChild,carrierRoot,carrierChild,root,child];
        for(uint256 i;i<6;i++){ledger.publish(lt[2],abi.encode(p[i],d,f));rejected(lt[2],abi.encode(p[i],d,other));}
        rejected(ct,abi.encode(root,f));rejected(ts[3],abi.encode(root,desc,f));
        rejected(lt[2],abi.encode(ledger.publish(BINARY,abi.encode(f)),d,f));
        rejected(lt[1],abi.encode(bytes32(uint256(88)),f));rejected(lt[1],abi.encode(stored,f));
        rejected(lt[1],abi.encode(d,bytes32(uint256(99))));rejected(lt[2],abi.encode(root,d,f,uint256(1)));
    }
    function test_live_descriptor_exact_widths_context_and_cap() public {
        bytes memory d=recipe();ledger.publish(lt[0],d);
        rejected(lt[0],bytes.concat(d,hex"00"));
        for(uint256 word;word<12;word++){
            if(word==6)continue; // every bytes32 key is supported
            bytes memory bad=recipe();assembly("memory-safe"){mstore(add(add(bad,32),mul(word,32)),0)}
            rejected(lt[0],bad);
        }
        d=recipe();d[127]=bytes1(uint8(1));rejected(lt[0],d);
        d=recipe();d[191]=bytes1(uint8(1));rejected(lt[0],d);
    }
    function test_live_index_generic_refs_once_on_reuse() public {
        bytes32[8] memory old=[rt,ct,live.expectedRootRuleHash(),live.expectedChildRuleHash(),nt,live.expectedNameRuleHash(),dt,FilesDirectoryIndex(address(live)).expectedDirectoryRuleHash()];
        live=new LiveFilesIndex(address(ledger),old,ts,hs,lt,lh);index=live;ledger.setIndexModule(address(index));
        bytes32 d=ledger.publish(lt[0],recipe());bytes32 f=ledger.create(bytes32(uint256(81)));bytes32 root=ledger.publish(lt[1],abi.encode(d,f));
        bytes memory body=abi.encode(root,d,f);ledger.publish(lt[2],body);ledger.publish(lt[2],body);
        (uint64 count,,,)=index.postingHead(Keys.referenceList(lt[2],0,root));require(count==1,"live parent posting duplicated");
        (count,,,)=index.postingHead(Keys.referenceList(lt[2],1,d));require(count==1,"live descriptor posting duplicated");
    }
}
