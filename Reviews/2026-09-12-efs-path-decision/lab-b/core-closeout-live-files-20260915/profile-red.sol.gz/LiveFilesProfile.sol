// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;
import {IAcceptor} from "../src/Interfaces.sol";
import {ProfiledFilesIndex} from "./ProfiledFilesIndex.sol";

library LiveFilesLayout {
    bytes32 internal constant DESCRIPTOR = keccak256("lab/type/files-live-descriptor/1");
    bytes32 internal constant ROOT = keccak256("lab/type/files-live-root/1");
    bytes32 internal constant CHILD = keccak256("lab/type/files-live-child/1");
    bytes32 internal constant VENUE = keccak256("evm/cancun/staticcall/1");
    bytes4 internal constant SELECTOR = bytes4(keccak256("quote(bytes32)"));
    struct Recipe {
        uint256 version; uint256 chainId; bytes32 venue; address provider;
        bytes32 providerHash; bytes4 selector; bytes32 key; bytes32 outputType;
        uint256 representation; uint256 callGas; uint256 maxReturn; address caller;
    }
}
contract LiveFilesDescriptorRule is IAcceptor {
    address public immutable adapter; bytes32 public immutable outputType;
    constructor(address a,bytes32 t){adapter=a;outputType=t;}
    function accept(bytes32,bytes calldata,bytes32[] calldata) external pure returns(bool){return false;}
}
contract LiveFilesRootRule is IAcceptor {
    function accept(bytes32,bytes calldata,bytes32[] calldata) external pure returns(bool){return false;}
}
contract LiveFilesChildRule is IAcceptor {
    bytes32[5] public parents;
    constructor(bytes32[5] memory p){parents=p;}
    function accept(bytes32,bytes calldata,bytes32[] calldata) external pure returns(bool){return false;}
}
contract LiveFilesIndex is ProfiledFilesIndex {
    constructor(address c,bytes32[8] memory legacy,bytes32[5] memory ts,bytes32[5] memory hs,bytes32[3] memory,bytes32[3] memory)
        ProfiledFilesIndex(c,legacy,ts,hs){}
}
