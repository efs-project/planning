import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {audit,prepare} from './audit-files-paid-quantities.mjs';
const run='/tmp/efs-b-archive-task1.OXPOfb';
const gate=JSON.parse(fs.readFileSync(run+'/files-paid-2.json'));
assert.equal(gate.outcome.code,0);assert(!gate.failure&&!gate.stopReason);assert(gate.ownedProcessesStopped&&gate.slotReleased);
const bytes=fs.readFileSync(run+'/files-paid-2.measurement.json.raw.json');
const packet=JSON.parse(bytes);assert.equal(packet.status,'MEASURED_AWAITING_INDEPENDENT_AUDIT');
assert.deepEqual(prepare({},packet.build),packet.prepared,'original pre-run expected fixture remains unchanged');
assert.equal(packet.chain.stopped,true);assert.equal(packet.measurement.status,'MEASURED_AWAITING_INDEPENDENT_AUDIT');
const result=audit(packet);
result.rawPacketSha256=createHash('sha256').update(bytes).digest('hex');
result.outerGateSourceDigest=gate.sourceDigest;
result.chainStopped=true;result.rootGateProcessesStopped=true;
fs.writeFileSync(run+'/files-paid-root-audit.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:result.status,transactions:result.transactions,admissions:result.admissions,
  cellsPerBasis:result.storageCellsPerBasis,rawPacketSha256:result.rawPacketSha256,
  gas:result.gasRows.map(r=>({label:r.label,gas:Number(BigInt(r.gasUsed)),calldataBytes:r.calldataBytes}))},null,2));
