# Root review: actual Files measurement and independent oracle

September14, pre-run. Approved for the bounded one-shot local experiment, not
production or actual paid success. Root read the full 281-line measure-files
runner, 28-line GREEN wrapper, unchanged focused test, 339-line independent
oracle, and their reports. Root authored neither runner nor oracle.

The wrapper forwards to the checked consumer and hashes its entire return;
the query key commits consumer/method/arguments/basis. It has one immutable,
no mutable state or expected-answer parameter. Actual compiling RED was the
missing result event; GREEN at ac548107... passes the unchanged six-result
test, including exact stale-basis rejection and checked no-storage-write
targets. Normal wrapper runtime/initcode is 2,908/3,047 bytes. No old tests or
production contracts changed; inherited test duplication is disclosed.

The runner has no node/process/compiler/filesystem launcher. Its provided-RPC
interface matches the root driver. It freezes nine predicted deployment
addresses, twelve setup transactions, six logical writes and six independent
paid reads. It retains signed outer transactions before sending; receipt,
transaction and block joins precede marking success. Every whole outer
transaction is charged, including Bob's real contract forwarding and mandatory
index maintenance. The one-entry scan budget is fixed at1, not raised at failure.

Runtime non-immutable-byte checks in the runner are explicitly insufficient
alone. The independent oracle instead patches all exact immutable values from
compiler AST names, independently predicted addresses, constructors and prior
code hashes. It pins source bytes/settings and checks metadata/artifact joins.
Its literal workload fold derives File/Record/Type identities, 11 admissions,
3 records, 6 bindings/publications, parent ordinals7/9, author-specific heads,
queried absent tag tiers and required coverage, separately from runner outputs.
It computes all six complete result/cursor encodings before seeing any events.

The audit requires all24 exact signed transaction boundaries, genuine Alice
intent signatures and Bob Actor calldata, full emitted events, block ancestry,
all nine runtimes and247 semantic cells at both seals. Candidate getter/results,
cost summaries and manifest assertions are not accepted as independent expected
answers. Native historical authority and authenticated state proofs are not
claimed. The247 cells are not exhaustive state-growth measurement.

Actual root offline preflight against final e45d649592bb9722 compiler output:
oracle self-tests pass; prepare returns247 cells/six expected results; altered
pinned Ledger source rejects. Saved preparation SHA256
94ef68850782cdff11eaf4f9f6a11551eba3b79fa207a6a2d42db9524b743c35.
Oracle SHA fd6b0212b6dc8f1d2294e5ce9b42b3a30141038b593666bdc4e2565e9cb3097e;
runner SHA247cc361ec980f2cf42aa787c594f79f8e409e6bc7d70d8633a471d5cfe012df.

No blocking source issue found for this scope. Separate root transport/launcher
review must approve its final hashes before launch. Actual packet audit and
negative corruption controls remain unrun. Root must also verify successful
outer gate, explicit stopped chain and unchanged pins; the pure semantic audit
does not by itself establish process cleanup or a completed measurement run.
