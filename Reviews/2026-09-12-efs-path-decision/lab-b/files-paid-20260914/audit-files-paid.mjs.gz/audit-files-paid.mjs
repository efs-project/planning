// Independent finite Files oracle. No runner imports, no network, no compiler.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
const e=createRequire(import.meta.url)(process.env.EFS_ETHERS_PATH||'/Users/james/Code/EFS/planning-efs21/Reviews/2026-09-04-mvp-rehearsal/node_modules/ethers');
const c=e.AbiCoder.defaultAbiCoder(), Z=e.ZeroHash, id=e.id;
const h=(types,values)=>e.keccak256(c.encode(types,values));
const word=x=>e.toBeHex(BigInt(x),32), sha=b=>createHash('sha256').update(b).digest('hex');
const ACT='tuple(uint8,bytes32,bytes32,bytes32,bytes32,bytes32,bytes32,uint32,bytes32)';
const BASIS='tuple(uint64,uint64,uint64,bytes32)';
const REV='tuple(bytes32,bytes32,bytes32,bytes32,bytes,bytes32)';
const TAG='tuple(bytes32,bytes32,uint8,bool,bool)';
const POINT=`tuple(uint8,bytes32,${REV},${TAG},${TAG})`;
const CURSOR='tuple(uint64,uint64,uint64,bytes32,bytes32,bytes32,bytes32,uint8,uint64,uint64)';
const FOLDER_RESULT=`tuple(uint8,bool,${CURSOR},${POINT}[])`;
const alice=new e.Wallet(word(0xA11CE)).address;
const purpose={head:id('efs2/purpose/head/1'),folder:id('efs2/purpose/folder/1'),tag:id('efs2/purpose/tag/1')};
const folder=id('/drafts'), role=id('note.txt');
const pos=(p,s,r)=>h(['bytes32','bytes32','bytes32','bytes32'],[id('efs2/position/1'),p,s,r]);
const rid=(t,b)=>h(['bytes32','bytes32','bytes32'],[id('efs2/record/1'),t,e.keccak256(b)]);
const typeId=(shape,refs,rule)=>h(['bytes32','bytes32','bytes32','bytes32'],[id('efs2/type/1'),id(shape),h(['bytes32[]'],[refs]),rule]);
const SOURCE_PINS={
 'src/Ledger.sol':'7576874b52a81ebc0f7b64640332b345096e0c09000ed4f09811bdc21dd6c3d5',
 'src/TypeRegistry.sol':'ef2bd89de58298977058ba98a4ac2c03416a3fde991d74cc52fdc00634c09459',
 'src/Keys.sol':'583e168dcf43f3d63e2cedf6dfffe2ecab9a872b981acedc34539657ce28c2bc',
 'src/IndexModule.sol':'43618a994095f3d73902f23521c055c8950cdc043f8d8ca74e9b83aef67f1592',
 'src/LensReader.sol':'7d0a167b684d700642fd1510bb237bc4ae59b630696603e94f08dd7c3dda0d2e',
 'src/Interfaces.sol':'5c8c5cf858c48fa814bf212b8922def0ca05e98b9c11248bc149a5f8f44af4b7',
 'src/LabHarness.sol':'0f09edfd71c8bc8cd133d102f56803e1de2ef40b5c1e5bb2b22c7d590a1deeb5',
 'test/FilesJoinedProfile.sol':'c701bf700c122d0c1fd0c3f6b51630c3c0b9bdb6902e0975b8b6a3095cf43cdf',
 'test/FilesJoinedConsumer.sol':'faf1e68e5dc92d56da6d39a7893ec0f7d4b06f13e04678ee04a62655c803005d',
 'test/FilesPaidRead.sol':'49b50c9aa7faeab7eeba1375468f68af4070a65373686758f56a01b919ceb169'
};
const ART={registry:['src/TypeRegistry.sol','TypeRegistry',0],ledger:['src/Ledger.sol','Ledger',1],rootRule:['test/FilesJoinedProfile.sol','FilesRootRule',2],childRule:['test/FilesJoinedProfile.sol','FilesChildRule',4],index:['test/FilesJoinedProfile.sol','FilesParentIndex',6],lens:['src/LensReader.sol','LensReader',8],bob:['src/LabHarness.sol','Actor',9],consumer:['test/FilesJoinedConsumer.sol','FilesJoinedConsumer',10],wrapper:['test/FilesPaidRead.sol','FilesPaidRead',11]};
const deployer=e.HDNodeWallet.fromPhrase('test test test test test test test test test test test junk',undefined,"m/44'/60'/0'/0/0").address;
const domain=e.TypedDataEncoder.hashDomain({name:'EFS2-RoadB-Lab',version:'1'});
const map=(key,slot)=>h(['bytes32','uint256'],[typeof key==='string'&&key.startsWith('0x')?e.zeroPadValue(key,32):word(key),slot]);
const plus=(slot,n)=>word(BigInt(slot)+BigInt(n));
const principal=(account,origin)=>account.toLowerCase()===alice.toLowerCase()?e.zeroPadValue(account,32):h(['bytes32','uint256','bytes32','address'],[id('efs2/principal/1'),2,origin,account]);
const binding=(p,position)=>h(['bytes32','bytes32','bytes32'],[id('efs2/binding/1'),p,position]);
const scope=(p,purpose,subject)=>h(['bytes32','bytes32','bytes32','bytes32'],[id('efs2/vk/binding-scope/1'),p,purpose,subject]);
const posting=(type,kind,ordinal,value)=>h(['bytes32','bytes32','uint256','uint256','bytes32'],[id('efs2/pk/1'),type,kind,ordinal,value]);

function buildContext(build) {
  const b=build.compilerInfo||build;
  assert.equal(b.solcVersion,'0.8.30');assert.equal(b.input.settings.evmVersion,'cancun');
  assert.equal(b.input.settings.viaIR,true);assert.equal(b.input.settings.optimizer.enabled,true);assert.equal(b.input.settings.optimizer.runs,200);
  for(const [path,pin] of Object.entries(SOURCE_PINS))assert.equal(sha(Buffer.from(b.input.sources[path].content)),pin,`reviewed source ${path}`);
  assert(!b.output.errors?.some(x=>x.severity==='error'),'successful full compiler output');
  const names=new Map();
  function walk(v){if(!v||typeof v!=='object')return;if(v.nodeType==='VariableDeclaration')names.set(String(v.id),v.name);for(const x of Object.values(v))if(typeof x==='object')Array.isArray(x)?x.forEach(walk):walk(x);}
  for(const source of Object.values(b.output.sources))walk(source.ast);
  const a=Object.fromEntries(Object.entries(ART).map(([k,[,,nonce]])=>[k,e.getCreateAddress({from:deployer,nonce})]));
  const runtime={},compiled={},args={};
  function patch(k,values,constructorArgs){
    const [path,name]=ART[k],out=b.output.contracts[path]?.[name];assert(out,`full compiler contract ${path}:${name}`);
    const metadata=JSON.parse(out.metadata);assert.equal(metadata.compiler.version.split('+')[0],'0.8.30');
    assert.equal(metadata.settings.evmVersion,'cancun');assert.equal(metadata.settings.optimizer.runs,200);assert.equal(metadata.settings.viaIR,true);
    for(const [path,source] of Object.entries(metadata.sources))assert.equal(source.keccak256,e.keccak256(e.toUtf8Bytes(b.input.sources[path].content)),`metadata source ${path}`);
    const bytes=e.getBytes('0x'+out.evm.deployedBytecode.object);
    for(const [astId,refs] of Object.entries(out.evm.deployedBytecode.immutableReferences||{})) {
      const n=names.get(astId);assert(Object.hasOwn(values,n),`unmapped immutable ${k}.${n}`);
      for(const r of refs){assert.equal(r.length,32);bytes.set(e.getBytes(e.zeroPadValue(typeof values[n]==='number'?e.toBeHex(values[n]):values[n],32)),r.start);}
    }
    runtime[k]=e.hexlify(bytes);compiled[k]=out;args[k]=constructorArgs;
    assert(bytes.length<=24576,`${k} runtime size`);
    const ctors=out.abi.filter(x=>x.type==='constructor');
    const data='0x'+out.evm.bytecode.object+(ctors.length?c.encode(ctors[0].inputs,constructorArgs).slice(2):'');
    assert(e.dataLength(data)<=49152,`${k} initcode size`);return e.keccak256(runtime[k]);
  }
  patch('registry',{admin:deployer},[]);
  const core=patch('ledger',{registry:a.registry,realmId:id('lab/realm/1'),admin:deployer,domainSeparator:domain},[a.registry,id('lab/realm/1')]);
  const rh=patch('rootRule',{},[]),rt=typeId('lab/type/files-joined-root/1',[],rh);
  const ch=patch('childRule',{rootType:rt},[rt]),ct=typeId('lab/type/files-joined-child/1',[Z],ch);
  const ih=patch('index',{ledger:a.ledger,admin:deployer,attachedFrom:1,rootType:rt,childType:ct,expectedRootRuleHash:rh,expectedChildRuleHash:ch},[a.ledger,rt,ct,rh,ch]);
  const lh=patch('lens',{ledger:a.ledger,index:a.index},[a.ledger,a.index]);
  patch('bob',{ledger:a.ledger},[a.ledger]);
  patch('consumer',{ledger:a.ledger,lensReader:a.lens,filesIndex:a.index,rootType:rt,childType:ct,expectedRootRuleHash:rh,expectedChildRuleHash:ch,coreCodeHash:core,lensCodeHash:lh,indexCodeHash:ih},[a.ledger,a.lens,a.index,rt,ct,rh,ch]);
  patch('wrapper',{reader:a.consumer,consumer:a.consumer},[a.consumer]);
  const f=deriveFixture(a,core,rh,ch);
  return {b,a,runtime,compiled,args,f,core,rh,ch};
}

function stateModel(ctx) {
  const {a,f,core}=ctx, origin=h(['uint256','bytes32'],[31337,core]);
  const cells=new Map(),heads=new Map(),lists=new Map(),admissionRows=[],publicationRows=[];
  const put=(name,slot,value,label)=>cells.set(`${name}:${word(BigInt(slot))}`,{name,address:a[name],slot:word(BigInt(slot)),value:typeof value==='string'?e.zeroPadValue(value,32):word(value),label});
  const append=(key,ordinal,audit)=>{const row=lists.get(key)||{ordinals:[],live:0,audit};row.ordinals.push(ordinal);row.live++;lists.set(key,row);};
  const release=key=>{const row=lists.get(key);assert(row&&row.live>0);row.live--;};
  let adm=0,bord=0,pub=0;
  for(const w of f.writes) {
    pub++;const first=adm+1,p=principal(w.author,origin),actionHash=h([ACT+'[]'],[w.actions]);
    publicationRows.push({...w,publication:pub,first,actionHash});
    for(let leaf=0;leaf<w.actions.length;leaf++) {
      const x=w.actions[leaf],k=x[0];adm++;let meta=BigInt(k)|(BigInt(leaf)<<4n)|(BigInt(pub)<<20n),aa=Z,bb=Z;
      if(k===5){aa=x[8];put('ledger',map(f.file,4),adm,'File Subject create admission');}
      if(k===1) {
        aa=x[2];bb=x[1];meta|=1n<<152n;const body=w.bodies[leaf],r=rid(x[1],body),base=map(r,2);
        put('ledger',base,x[1],'exact Record Type');put('ledger',plus(base,1),BigInt(adm)|(BigInt(e.dataLength(body))<<48n)|(1n<<80n),'Record first/length/occurrence');
        const bytes=e.getBytes(body);for(let i=0;i<Math.ceil(bytes.length/32);i++)put('ledger',map(i,map(r,3)),e.hexlify(bytes.slice(i*32,(i+1)*32)).padEnd(66,'0'),'body word');
        append(posting(x[1],1,0,Z),adm,false);append(posting(Z,4,0,p),adm,false);
        if(x[1]===f.childType)append(posting(x[1],11,0,f.r0),adm,true);
      }
      if(k===3){
        const position=pos(x[3],x[4],x[5]),key=binding(p,position),old=heads.get(key),b=old?.bord||++bord;
        assert.equal(old?.rev||0,x[7],'independent CAS fold');
        if(old)release(posting(Z,5,0,old.target));
        else {append(posting(Z,10,0,scope(p,x[3],x[4])),b,true);put('ledger',map(b,9),position,'binding ordinal position');}
        const row={target:x[6],rev:x[7]+1,admission:adm,bord:b,position,author:w.author};heads.set(key,row);
        put('ledger',map(key,8),1n|(BigInt(row.rev)<<8n)|(BigInt(adm)<<40n)|(1n<<88n)|(BigInt(old?.admission||0)<<120n)|(BigInt(b)<<168n),'live Head metadata');
        put('ledger',plus(map(key,8),1),x[6],'Head target');
        [x[3],x[4],x[5]].forEach((v,i)=>put('ledger',plus(map(position,10),i),v,'position preimage'));
        append(posting(Z,5,0,x[6]),adm,false);append(posting(Z,8,0,key),adm,true);
        aa=x[6];meta|=BigInt(b)<<68n;meta|=BigInt(x[7])<<116n;
      }
      const base=map(adm,5);[meta,aa,bb].forEach((v,i)=>put('ledger',plus(base,i),v,'admission row'));
      admissionRows.push({ordinal:adm,publication:pub,leaf,action:x,principal:p});
    }
    put('ledger',map(w.author,11),w.nonce+1,'author next nonce');
    put('ledger',map(h(['address','uint64','bytes32'],[w.author,w.nonce,actionHash]),7),pub,'publication replay map');
  }
  put('ledger',0,a.index,'required index address');put('ledger',1,11n|(3n<<64n)|(6n<<128n)|(6n<<192n),'four counters');
  // Absence is checked from raw slots for every tag tier that contributes to six results.
  for(const account of [alice,a.bob])for(const s of [f.file,f.r0,f.ra,f.rb])for(const concept of ['project_efs','draft','approved']){
    const key=binding(principal(account,origin),pos(purpose.tag,s,id(concept)));
    if(!heads.has(key)){put('ledger',map(key,8),0,'absent tag Head');put('ledger',plus(map(key,8),1),0,'absent tag target');}
  }
  const bobFolder=binding(principal(a.bob,origin),pos(purpose.folder,folder,role));
  put('ledger',map(bobFolder,8),0,'absent Bob placement');put('ledger',plus(map(bobFolder,8),1),0,'absent Bob placement target');
  put('index',0,11n|(6n<<64n),'family progress generation gap flag');
  for(const family of ['scope','history','backlink','by-type','by-author','files-parent'])put('index',map(id(`efs2/family/${family}/1`),1),1n|(1n<<8n)|(1n<<16n),'mandatory family from admission one');
  // Explicit empty Bob folder list and empty RA/RB parent lists matter to completeness.
  for(const key of [posting(Z,10,0,scope(principal(a.bob,origin),purpose.folder,folder)),posting(f.childType,11,0,f.ra),posting(f.childType,11,0,f.rb)])if(!lists.has(key))lists.set(key,{ordinals:[],live:0,audit:false});
  for(const [key,list] of lists){
    const n=list.ordinals.length;put('index',map(key,2),BigInt(n)|(BigInt(list.live)<<64n)|(BigInt(list.ordinals.at(-1)||0)<<128n)|(list.audit?1n<<176n:0n),'posting head count live last flags');
    for(let wi=0;wi<=Math.floor(n/5);wi++){let v=0n;for(let j=0;j<5;j++)v|=BigInt(list.ordinals[wi*5+j]||0)<<(48n*BigInt(j));put('index',map(wi,map(key,3)),v,'posting ordinals including exhausted tail');}
  }
  put('registry',0,2,'registry epoch');
  // Record profile headers include deployment block numbers, filled by the audit from signed config TXs.
  return {cells,put,heads,lists,admissionRows,publicationRows,origin};
}

export function prepare(manifest,build) {
  const ctx=buildContext(build),s=stateModel(ctx);
  for(const pub of s.publicationRows)for(let i=0;i<7;i++)s.put('ledger',plus(map(pub.publication,6),i),0,'evidence requested; value checked from signed TX');
  for(const t of [ctx.f.rootType,ctx.f.childType]){
    for(let i=0;i<3;i++)s.put('registry',plus(map(t,1),i),0,'descriptor requested');
    s.put('registry',map(t,2),0,'ref vector count requested');s.put('registry',e.keccak256(map(t,2)),0,'ref vector first word requested');
    for(let i=0;i<2;i++)s.put('registry',plus(map(1,map(t,3)),i),0,'activation row requested');
  }
  return {schema:'efs-lab-b/files-paid-oracle-preparation/1',addresses:ctx.a,fixture:ctx.f,sourcePins:SOURCE_PINS,
    runtimes:ctx.runtime,storageRequests:[...s.cells.values()].map(({name,address,slot,label})=>({name,address,slot,label})),
    limitation:'Fixed six-operation literal fixture; raw RPC observations, not authenticated state proofs; persistent slot growth UNKNOWN'};
}

const INTENT='tuple(bytes32,bytes32,address,uint64,uint64,bytes32,bytes32)';
const fields=[{name:'realmId',type:'bytes32'},{name:'coreCodeCommitment',type:'bytes32'},{name:'author',type:'address'},{name:'nonce',type:'uint64'},{name:'deadline',type:'uint64'},{name:'acceptanceProfile',type:'bytes32'},{name:'indexObligations',type:'bytes32'},{name:'actionsHash',type:'bytes32'}];
const lower=x=>typeof x==='string'?x.toLowerCase():x;
const normalize=v=>typeof v==='string'?v.toLowerCase():Array.isArray(v)?v.map(normalize):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).map(([k,x])=>[k,normalize(x)])):v;
const same=(a,b,label)=>assert.deepEqual(normalize(a),normalize(b),label);

export function audit(envelope) {
  const p=envelope.measurement||envelope,ctx=buildContext(envelope.build||p.build),s=stateModel(ctx),{a,f,compiled,runtime,core,rh,ch}=ctx;
  assert(!p.failure,'no runner failure');assert.equal(p.schema,'efs-lab-b/files-paid/1');
  const rpc=envelope.rpc||p.rpc;assert(Array.isArray(rpc),'raw RPC transcript required');
  function observation(method,params,result) {
    const matches=rpc.filter(x=>x.request?.method===method&&JSON.stringify(normalize(x.request.params))===JSON.stringify(normalize(params))&&x.response&&!x.response.error&&JSON.stringify(normalize(x.response.result))===JSON.stringify(normalize(result)));
    assert(matches.length,`missing joined raw RPC ${method}: ${JSON.stringify(params)}`);
    for(const x of matches){assert.equal(x.response.id,x.request.id);assert.equal(x.response.jsonrpc,'2.0');}
  }
  const txs=p.transactions;assert.equal(txs.length,24,'all setup/config/W/read transactions retained');
  const byNonce=new Map(),gasRows=[];
  for(const t of txs) {
    const d=e.Transaction.from(t.rawTransaction),r=t.receipt,b=t.block,o=t.transaction;
    assert.equal(d.hash,t.hash);assert.equal(e.keccak256(t.rawTransaction),t.hash);same(o.hash,t.hash);same(r.transactionHash,t.hash);
    same(d.from,deployer,'genuine outer deployer signature');same(o.from,d.from);same(r.from,d.from);same(o.to,d.to);same(r.to,d.to);same(o.input,d.data);
    assert.equal(d.chainId,31337n);assert.equal(BigInt(o.chainId),31337n);assert.equal(BigInt(o.nonce),BigInt(d.nonce));assert.equal(d.value,0n);assert.equal(BigInt(o.value),0n);
    assert.equal(BigInt(o.type),BigInt(d.type));assert.equal(BigInt(r.type),BigInt(d.type));same(o.r,d.signature.r);same(o.s,d.signature.s);
    assert.equal(BigInt(o.v),d.type===0?d.signature.networkV:BigInt(d.signature.yParity));
    assert.equal(BigInt(o.gas),d.gasLimit);assert.equal(BigInt(r.status),1n);assert(BigInt(r.gasUsed)>0n&&BigInt(r.gasUsed)<=d.gasLimit);
    if(d.type===0||d.type===1){assert.equal(BigInt(o.gasPrice),d.gasPrice);assert.equal(BigInt(r.effectiveGasPrice),d.gasPrice);}
    else {assert.equal(d.type,2);assert.equal(BigInt(o.maxFeePerGas),d.maxFeePerGas);assert.equal(BigInt(o.maxPriorityFeePerGas),d.maxPriorityFeePerGas);const effective=BigInt(b.baseFeePerGas)+d.maxPriorityFeePerGas;assert.equal(BigInt(r.effectiveGasPrice),effective<d.maxFeePerGas?effective:d.maxFeePerGas);}
    same(o.blockHash,b.hash);same(r.blockHash,b.hash);same(o.blockNumber,b.number);same(r.blockNumber,b.number);same(o.transactionIndex,r.transactionIndex);
    assert.equal(b.transactions.length,1,'isolated one-transaction blocks');same(b.transactions[Number(BigInt(r.transactionIndex))],t.hash);
    assert.equal(BigInt(r.cumulativeGasUsed),BigInt(r.gasUsed));assert.equal(BigInt(b.gasUsed),BigInt(r.gasUsed));
    assert(BigInt(b.gasUsed)<=BigInt(b.gasLimit),'block gas budget');
    for(const log of r.logs){same(log.transactionHash,t.hash);same(log.blockHash,b.hash);same(log.blockNumber,b.number);same(log.transactionIndex,r.transactionIndex);assert(!log.removed);}
    observation('eth_sendRawTransaction',[t.rawTransaction],t.hash);observation('eth_getTransactionReceipt',[t.hash],r);observation('eth_getTransactionByHash',[t.hash],o);observation('eth_getBlockByHash',[b.hash,false],b);
    assert(!byNonce.has(d.nonce),'no duplicate nonce');byNonce.set(d.nonce,{...t,decoded:d});
    const bytes=e.getBytes(d.data);gasRows.push({nonce:d.nonce,label:t.label,transactionHash:t.hash,gasUsed:r.gasUsed,calldataBytes:bytes.length,calldataZeroBytes:bytes.filter(x=>x===0).length});
  }
  for(let n=0;n<24;n++){assert(byNonce.has(n),`nonce ${n}`);if(n)same(byNonce.get(n).block.parentHash,byNonce.get(n-1).block.hash,'one uninterrupted isolated chain');}
  const iface=Object.fromEntries(Object.entries(compiled).map(([k,v])=>[k,new e.Interface(v.abi)]));
  function exactCall(n,to,data){const t=byNonce.get(n);same(t.decoded.to,to);same(t.decoded.data,data,`exact logical boundary nonce ${n}`);return t;}
  function exactLogs(n,expected){const logs=byNonce.get(n).receipt.logs;assert.equal(logs.length,expected.length,`event count nonce ${n}`);for(let i=0;i<logs.length;i++){same(logs[i].address,expected[i].address);same(logs[i].topics,expected[i].topics);same(logs[i].data,expected[i].data);}}
  function ev(contract,event,values){return {address:a[contract],...iface[contract].encodeEventLog(iface[contract].getEvent(event),values)};}
  for(const [k,[,,n]] of Object.entries(ART)){
    const out=compiled[k],constructor=out.abi.find(x=>x.type==='constructor'),data='0x'+out.evm.bytecode.object+(constructor?c.encode(constructor.inputs,ctx.args[k]).slice(2):'');
    const t=exactCall(n,null,data);assert.equal(t.label,`deploy/${k}`);same(t.receipt.contractAddress,a[k]);
    observation('eth_getCode',[a[k],{blockHash:t.block.hash,requireCanonical:true}],runtime[k]);
    const dep=p.deployments?.[k];if(dep){same(dep.address,a[k]);if(dep.code)same(dep.code,runtime[k]);if(dep.runtime?.code)same(dep.runtime.code,runtime[k]);}
    if(k!=='index')exactLogs(n,[]);
  }
  exactLogs(6,['scope','history','backlink','by-type','by-author','files-parent'].map(x=>ev('index','FamilyDeclared',[id(`efs2/family/${x}/1`),true,1])));
  for(const [n,t,shape,rule,refs,epoch] of [[3,f.rootType,id('lab/type/files-joined-root/1'),a.rootRule,[],1],[5,f.childType,id('lab/type/files-joined-child/1'),a.childRule,[Z],2]]){
    exactCall(n,a.registry,iface.registry.encodeFunctionData('register',[shape,rule,refs]));
    const tx=byNonce.get(n),ruleHash=epoch===1?rh:ch;
    assert.equal(tx.label,epoch===1?'registerRoot':'registerChild');
    exactLogs(n,[ev('registry','TypeRegistered',[t,shape,ruleHash,rule,refs.length]),ev('registry','PolicyActivated',[t,1,e.ZeroAddress,Z,epoch])]);
    const header=1n|(BigInt(refs.length)<<8n)|(1n<<16n)|(BigInt(tx.block.number)<<32n)|(BigInt(rule)<<96n);
    [header,shape,ruleHash].forEach((v,i)=>s.put('registry',plus(map(t,1),i),v,'pinned Type descriptor'));
    s.put('registry',map(t,2),refs.length,'checked reference vector length');s.put('registry',e.keccak256(map(t,2)),0,'wildcard reference word');
    s.put('registry',map(1,map(t,3)),(BigInt(epoch)<<160n)|(BigInt(tx.block.number)<<208n),'no additional policy activation');s.put('registry',plus(map(1,map(t,3)),1),0,'no policy hash');
  }
  assert.equal(exactCall(7,a.ledger,iface.ledger.encodeFunctionData('setIndexModule',[a.index])).label,'setIndex');exactLogs(7,[ev('ledger','IndexModuleSet',[a.index])]);
  for(const [i,w] of s.publicationRows.entries()) {
    const n=12+i,t=byNonce.get(n),actionsHash=w.actionHash,proof=i===4?1:2;
    assert.equal(t.label,w.label);
    let deadline=0n,v=0,r=Z,ss=Z;
    let acceptance=Z;for(const x of w.actions)if(x[0]===1)acceptance=h(['bytes32','bytes32','bytes32','bytes32','uint64'],[acceptance,x[1],x[1]===f.rootType?rh:ch,Z,2]);
    const obligations=h(['address','bytes32'],[a.index,e.keccak256(runtime.index)]);
    if(i===4)exactCall(n,a.bob,iface.bob.encodeFunctionData('execute',[w.actions,w.bodies]));
    else {
      const decoded=iface.ledger.decodeFunctionData('executeSigned',t.decoded.data),intent=decoded[0],sig=decoded[3];deadline=intent[4];
      assert(deadline>=BigInt(t.block.timestamp),'intent not expired');
      const expected=[id('lab/realm/1'),core,alice,w.nonce,deadline,acceptance,obligations];
      exactCall(n,a.ledger,iface.ledger.encodeFunctionData('executeSigned',[expected,w.actions,w.bodies,sig]));
      const message=Object.fromEntries(fields.slice(0,7).map((x,i)=>[x.name,expected[i]]));message.actionsHash=actionsHash;
      const digest=e.TypedDataEncoder.hash({name:'EFS2-RoadB-Lab',version:'1'},{PublicationIntent:fields},message);
      same(e.recoverAddress(digest,sig),alice,'actual Alice signature');({v,r,s:ss}=e.Signature.from(sig));
    }
    const base=map(w.publication,6),w0=BigInt(w.author)|(BigInt(proof)<<160n)|(BigInt(v)<<164n)|(BigInt(w.actions.length)<<172n)|(BigInt(w.first)<<188n);
    const w3=BigInt(w.nonce)|(deadline<<64n)|((BigInt(t.block.number)&((1n<<40n)-1n))<<128n);
    [w0,r,ss,w3,acceptance,obligations,actionsHash].forEach((x,j)=>s.put('ledger',plus(base,j),x,'actual signed/native evidence'));
    const logs=s.admissionRows.filter(x=>x.publication===w.publication).map(row=>{
      const x=row.action,p=row.principal;
      const sc=x[0]===5?f.file:x[0]===1?x[1]:scope(p,x[3],x[4]);
      const record=x[0]===5?Z:x[0]===1?rid(x[1],w.bodies[row.leaf]):x[6];
      return ev('ledger','Admitted',[p,sc,record,row.ordinal]);
    });
    logs.push(ev('ledger','Published',[w.publication,h(['address','uint64','bytes32'],[w.author,w.nonce,actionsHash]),w.author,proof,w.first,w.actions.length]));exactLogs(n,logs);
  }
  const sealed=byNonce.get(17).block,final=byNonce.get(23).block;
  if(p.sealed){same(p.sealed.blockHash||p.sealed.hash,sealed.hash);same(p.sealed.blockNumber||p.sealed.number,sealed.number);}
  for(const [i,q] of f.queries.entries()){
    const n=18+i;assert.equal(exactCall(n,a.wrapper,iface.wrapper.encodeFunctionData(q.method,q.args)).label,q.label);
    exactLogs(n,[ev('wrapper','FilesRead',[q.queryKey,q.resultHash])]);
  }
  for(const basis of [sealed,final]) {
    for(const [k,code] of Object.entries(runtime))observation('eth_getCode',[a[k],{blockHash:basis.hash,requireCanonical:true}],code);
    for(const cell of s.cells.values())observation('eth_getStorageAt',[cell.address,cell.slot,{blockHash:basis.hash,requireCanonical:true}],cell.value);
  }
  // Raw cells above assert the full finite model, including all absent queried tag tiers.
  // Independent query results were encoded BEFORE reading any paid wrapper event.
  return {status:'INDEPENDENT_FILES_RAW_AUDIT_PASS',evidenceLevel:'OWNED_LOCAL_RPC_OBSERVATION_NOT_AUTHENTICATED_STATE_PROOF',
    transactions:24,admissions:11,records:3,bindings:6,publications:6,storageCellsPerBasis:s.cells.size,
    sourcePins:SOURCE_PINS,compilerInputSha256:sha(Buffer.from(JSON.stringify(ctx.b.input))),sealedBlockHash:sealed.hash,finalBlockHash:final.hash,
    ids:{file:f.file,r0:f.r0,ra:f.ra,rb:f.rb,rootType:f.rootType,childType:f.childType},
    expectedQueries:f.queries.map(({label,queryKey,resultHash,encoded})=>({label,queryKey,resultHash,encoded})),gasRows:gasRows.sort((a,b)=>a.nonce-b.nonce),
    persistentSlotGrowth:'UNKNOWN',limitations:['Fixed one-File three-revision graph only','All state values are RPC observations, not trie/header-authenticated proof','No cold filename recovery','No portable historical native source proof','No dollar affordability, full Files UX or lifetime-cost claim']};
}

function deriveFixture(a,coreHash,rootHash,childHash) {
  const rt=typeId('lab/type/files-joined-root/1',[],rootHash),ct=typeId('lab/type/files-joined-child/1',[Z],childHash);
  const file=h(['bytes32','bytes32','bytes32'],[id('efs2/subject/1'),e.zeroPadValue(alice,32),word(401)]);
  const text=['Meeting at 10:00.\n','Meeting at 11:00.\n','Meeting at 09:00.\n'].map(x=>e.toUtf8Bytes(x));
  const rootBody=e.concat([file,text[0]]),r0=rid(rt,rootBody);
  const raBody=e.concat([r0,file,text[1]]),rbBody=e.concat([r0,file,text[2]]),ra=rid(ct,raBody),rb=rid(ct,rbBody);
  const action=(kind,patch={})=>Object.assign([kind,Z,Z,Z,Z,Z,Z,0,Z],patch);
  const publish=(t,b)=>action(1,{1:t,2:e.keccak256(b)});
  const bind=(p,s,r,t,rev=0)=>action(3,{3:p,4:s,5:r,6:t,7:rev});
  const writes=[
    {label:'W1',author:alice,nonce:0,actions:[action(5,{8:word(401)}),publish(rt,rootBody),bind(purpose.head,file,Z,r0),bind(purpose.folder,folder,role,file)],bodies:['0x',rootBody,'0x','0x']},
    {label:'W2',author:alice,nonce:1,actions:[bind(purpose.tag,file,id('project_efs'),file)],bodies:['0x']},
    {label:'W3',author:alice,nonce:2,actions:[bind(purpose.tag,r0,id('draft'),file)],bodies:['0x']},
    {label:'W4',author:alice,nonce:3,actions:[publish(ct,raBody),bind(purpose.head,file,Z,ra,1)],bodies:[raBody,'0x']},
    {label:'W5',author:a.bob,nonce:0,actions:[publish(ct,rbBody),bind(purpose.head,file,Z,rb)],bodies:[rbBody,'0x']},
    {label:'W6',author:alice,nonce:4,actions:[bind(purpose.tag,ra,id('approved'),file)],bodies:['0x']}
  ];
  const basis=[11,0,2,coreHash];
  const point=(selected,concept)=>{
    const approved=concept===id('approved'),project=concept===id('project_efs');
    const doc=selected===ra?text[1]:text[2];
    return [1,file,[selected,ct,r0,file,e.hexlify(doc),e.keccak256(doc)],
      [file,project?file:Z,project?1:0,true,project],
      [selected,approved&&selected===ra?file:Z,approved&&selected===ra?1:0,true,approved&&selected===ra]];
  };
  const selectors={point:e.id(`readFilePoint(bytes32,address[],bytes32,(uint64,uint64,uint64,bytes32))`).slice(0,10),folder:e.id(`readFolderTaggedOnce(bytes32,address[],bytes32,uint8,uint256,(uint64,uint64,uint64,bytes32))`).slice(0,10)};
  const queries=[];
  for(const [prefix,concept,scope] of [['P',id('approved'),null],['F',id('project_efs'),0],['R',id('approved'),1]]) {
    for(const [suffix,authors,selected] of [['A',[alice,a.bob],ra],['B',[a.bob,alice],rb]]) {
      const p=point(selected,concept),method=prefix==='P'?'point':'folder';
      const args=method==='point'?[file,authors,concept,basis]:[folder,authors,concept,scope,1,basis];
      const types=method==='point'?['bytes32','address[]','bytes32',BASIS]:['bytes32','address[]','bytes32','uint8','uint256',BASIS];
      const cursor=[11,0,2,coreHash,h(['bytes32','bytes32'],[purpose.folder,folder]),e.keccak256(e.solidityPacked(['address[]'],[authors])),pos(purpose.folder,folder,role),2,0,1];
      const result=method==='point'?p:[2,false,cursor,(scope===0||selected===ra)?[p]:[]];
      const encoded=c.encode([method==='point'?POINT:FOLDER_RESULT],[result]);
      queries.push({label:`${prefix}-${suffix}`,method,args,result,encoded,resultHash:e.keccak256(encoded),queryKey:h(['address','bytes4',...types],[a.consumer,selectors[method],...args])});
    }
  }
  return {admissions:11,recordCount:3,bindingCount:6,writes,queries,rootType:rt,childType:ct,file,r0,ra,rb,rootBody,raBody,rbBody,basis};
}

function selfTest() {
  const a={ledger:e.getAddress('0x1000000000000000000000000000000000000001'),bob:e.getAddress('0x1000000000000000000000000000000000000002'),consumer:e.getAddress('0x1000000000000000000000000000000000000003'),index:e.getAddress('0x1000000000000000000000000000000000000004'),registry:e.getAddress('0x1000000000000000000000000000000000000005')};
  const f=deriveFixture(a,id('core'),id('root rule'),id('child rule'));
  assert.equal(f.admissions,11,'W1–W6 admission count');
  assert.equal(f.recordCount,3,'three retained revisions');
  assert.equal(f.bindingCount,6,'six author-qualified binding keys');
  assert.equal(f.writes.length,6,'six separately priced writes');
  assert.equal(f.queries.length,6,'six separately submitted reads');
  assert.equal(f.queries[0].result[2][0],f.ra,'Alice-first selects RA');
  assert.equal(f.queries[1].result[2][0],f.rb,'Bob-first selects RB');
  assert.equal(f.queries[0].result[4][4],true,'approved only on selected RA');
  assert.equal(f.queries[1].result[4][4],false,'RB is not approved');
  assert.equal(f.queries[2].result[3].length,1,'File project tag includes Alice-first');
  assert.equal(f.queries[3].result[3].length,1,'File project tag includes Bob-first');
  assert.equal(f.queries[4].result[3].length,1,'selected RA approved');
  assert.equal(f.queries[5].result[3].length,0,'selected RB not approved');
  assert.equal(f.queries[5].result[0],2,'empty R-B COMPLETE');
  assert.equal(f.queries[5].result[2][7],2,'empty R-B exhausted Lens');
  assert.equal(f.queries[5].result[2][9],1,'cursor counts selected placement before tag filtering');
  const model=stateModel({a,f,core:id('core')});
  assert.deepEqual(model.lists.get(posting(f.childType,11,0,f.r0)).ordinals,[7,9],'first-admission parent postings');
  const aliceHead=model.heads.get(binding(e.zeroPadValue(alice,32),pos(purpose.head,f.file,Z)));
  assert.deepEqual([aliceHead.rev,aliceHead.admission,aliceHead.bord],[2,8,1],'Alice current Head metadata');
  const bobHead=model.heads.get(binding(principal(a.bob,model.origin),pos(purpose.head,f.file,Z)));
  assert.deepEqual([bobHead.rev,bobHead.admission,bobHead.bord],[1,10,5],'genuine contract-author Head');
  for(const q of f.queries){assert.equal(e.keccak256(q.encoded),q.resultHash);const changed=e.getBytes(q.encoded);changed[changed.length-1]^=1;assert.notEqual(e.keccak256(changed),q.resultHash,'full encoded result mutation changes event hash');}
  console.log('SELF_TEST_PASS: literal workflow counts, raw posting/head fold, six selections/tag tiers/full result hashes, complete empty cursor');
}
if(process.argv[2]==='--self-test') selfTest();
else if(process.argv[2]==='--prepare') {
  const build=JSON.parse(fs.readFileSync(process.argv[3]));console.log(JSON.stringify(prepare({},build),null,2));
} else if(process.argv[2]==='--audit') {
  const bytes=fs.readFileSync(process.argv[3]);assert(bytes.length<128*1024**2,'bounded raw packet');
  const report=audit(JSON.parse(bytes));report.rawPacketSha256=sha(bytes);console.log(JSON.stringify(report,null,2));
}
