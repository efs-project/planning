# Independent paid Files oracle preparation

**Status (2026-09-14): source implementation ready for independent review; no paid/RPC audit has run.** Root's final GREEN compiler artifact and retained preparation JSON remain prerequisites to launching the one paid workflow. Root runs all Forge/Anvil/RPC gates; this worker ran only Node syntax/unit checks and source reads.

Owned files: `/tmp/efs-b-archive-task1.OXPOfb/audit-files-paid.mjs` and this report. No source/Git/dependency/subagent writes. Existing `audit-paid.mjs` was read as transport precedent, not imported or edited. Task 1's published acceptance code remains frozen; this task does not reopen it.

## Independence and exact pre-run expectations

I implemented the earlier mandatory acceptance/index profile, not FilesJoinedConsumer or the new paid wrapper/runner. This oracle imports neither implementation nor runner helpers. It derives the source codecs from pinned Keys/Ledger/IndexModule/TypeRegistry semantics, then independently constructs the literal W1–W6 fold. Expected query structs are encoded before inspection of any wrapper output. The auditor requires raw state to match the complete finite model, including all absent tag tiers; the event hash must match the independently encoded entire struct, not a candidate-provided expected answer.

The inputs are realm `keccak256("lab/realm/1")`, genuine signed Alice key `0xA11CE`, File salt 401, `/drafts` and `note.txt` coordinate hashes, and the exact three `Meeting at …\n` documents. Root/Child Type identities use reviewed runtime hashes patched from full compiler immutables. All nine deployment addresses are independently predicted from default test account 0 and nonces 0,1,2,4,6,8,9,10,11; register/config nonces are 3,5,7; W1–W6 are 12–17; six paid reads are 18–23. Budget is 1 for one Alice placement.

Before any paid run, these literal semantic expectations are already tested:

| Query | Selected revision | File tag for query concept | Selected revision tag | Returned Files |
| --- | --- | --- | --- | --- |
| P-A approved | RA | absent | present on RA | full FilePoint RA |
| P-B approved | RB | absent | absent on RB | full FilePoint RB |
| F-A project_efs | RA | present on F | absent on RA | F@RA |
| F-B project_efs | RB | present on F | absent on RB | F@RB |
| R-A approved | RA | absent | present on RA | F@RA |
| R-B approved | RB | absent | absent on RB | empty, COMPLETE and exhausted |

Every folder result has status 2, mutated=false, exact current cursor with frontier 11, generation 0, epoch 2, actual Core runtime commitment, scope/Lens/position hashes, lensIndex 2, rawIndex 0, selectedSoFar 1. The final cursor still counts the selected placement before filtering even when R-B returns zero Files. Full revision body/document/digest and both tag-assessment structs are included in expected encoded results.

W1–W6 produce 11 admissions, 3 Records, 6 bindings, 6 publications. Root/RA/RB first admissions are 2/7/9; parent postings R0->{7,9}, no RA or RB descendants. Alice HEAD is revision2/admission8/bindingOrdinal1; Bob HEAD is revision1/admission10/bindingOrdinal5. Alice next nonce5, Bob next nonce1. Coverage requires all six mandatory families from admission1 with lastProcessed11, lastPublication6, generation0 and no gap; it is family-wide, not independently maintained per parent.

## Interface and capture contract

```js
import { prepare, audit } from "/tmp/efs-b-archive-task1.OXPOfb/audit-files-paid.mjs";
const expected = prepare({}, build); // offline BEFORE launch; save this object independently
// expected.storageRequests = [{name,address,slot,label}], 247 cells
// expected.fixture.queries holds full encoded independent expected structs/hashes
// Root transport captures requests at w6 and final, plus all nine runtime codes.
const report = audit({measurement, rpc, build, chain});
```

`build` is the full compiler-info object or `{compilerInfo: fullObject, artifacts: ...}`. Full output must retain AST and immutable references, ABI, metadata, creation and deployed bytecode. Expected immutable values come from exact constructors, independently predicted addresses, and earlier patched runtimes. Immutable bytes are not merely ignored. Compiler source pins and metadata source hashes are checked. Root's compilation provenance is trusted; the worker does not independently recompile or turn compiler output into a cryptographic build proof.

CLI forms: `node audit-files-paid.mjs --self-test`, `--prepare FULL_COMPILER_INFO_JSON`, or `--audit RETAINED_ENVELOPE_JSON`. Output is stdout only. Imports do not write files or use network. The optional ethers path is `EFS_ETHERS_PATH`; default uses the already installed ethers 6.15.0 from the previous rehearsal. No dependency install is needed.

Envelope: `{measurement: packet, rpc:[{request,response}], build:{compilerInfo,...}, chain}`. Measurement packet schema is `efs-lab-b/files-paid/1`; it has 24 `transactions` retaining label/rawTransaction/hash/transaction/receipt/block. Deployment labels and workflow labels are exact. Runner captures `snapshots.w6/final` plus direct raw RPC records. The oracle primarily matches the raw RPC transcript, not synthesized getter responses, summaries, manifest IDs, row costs, or candidate expected answers. Constructor arguments are reconstructed from source/fixture and compared to signed initcode.

For each outer transaction the checker verifies raw signed transaction hash and recovered sender, nonce, exact calldata/value/chain/fee/gas fields, observed transaction and successful receipt, one-transaction header/log joins and uninterrupted block ancestry. It independently checks all deployment/config/Admitted/Published/FilesRead events, actual Alice intent signatures, native Bob's Actor.execute call and retained author/proof category. Entire outer receipt gas and calldata are reported without subtraction. Six paid reads are alternatives, not a combined compulsory bill.

## Verification so far

- TDD Node RED: intentionally empty deriveFixture stub failed literal `0 !== 11` admission-count assertion.
- GREEN: Node self-test passes literal counts, first-admission parent postings `[7,9]`, author-qualified heads, six selection/tag outcomes, full-result hash mutation sensitivity and COMPLETE empty R-B cursor.
- `node --check` passes.
- Offline preparation against root's RED full compiler info succeeded with 247 cells and six independent full encoded results. This was a preparation check, not paid execution; the wrapper was still a false instrument there. The final reviewed wrapper source is now explicitly pinned, so that old RED compiler input is deliberately rejected until root supplies GREEN compiler output.
- Mutating pinned Ledger source bytes was rejected before preparation. No source/RPC/measurement output was synthesized as passing evidence.

Current checker SHA256: `fd6b0212b6dc8f1d2294e5ce9b42b3a30141038b593666bdc4e2565e9cb3097e` (root should re-pin after review changes). Final wrapper source pin: `49b50c9aa7faeab7eeba1375468f68af4070a65373686758f56a01b919ceb169`; source pins for the nine prior files are embedded in SOURCE_PINS.

## Remaining gates and unknowns

Independent source review and offline prepare against the final full GREEN compiler output must precede the one paid run. Actual transport integration and audit are unrun; do not claim an observed paid or raw-state PASS from the unit test. Root owns preserving the pre-run preparation artifact, matching the captured raw packet, watchdog/chain shutdown and publication.

Persistent slot growth is UNKNOWN: the 247 requested cells are semantic verification coverage, not an exhaustive storage-diff count or a price estimate. State and headers are owned-local RPC observations, not authenticated trie/state proofs. No native historical source portability, cold filename recovery, full Files UX, scale, USD affordability or total lifetime-overhead claim is made.
