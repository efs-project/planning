# Files paid root transport/preflight review

Verdict: **NeedsChanges**. Critical: 0. Important: 2. Minor: 1.

Scope: independent read-only review of the new root-owned paid gate and driver, not Task 3 review and not a verdict on the unfinished measurement runner or oracle fixture/audit implementation. Read the full files-paid-workflow-plan-20260914.md, full files-paid-gate.mjs and files-driver.mjs, their delta from the original paid-gate.mjs, the original pure validator tests, and the relevant existing archive launcher boundary. No archive files were changed.

Reviewed SHA256 pins:

- files-paid-gate.mjs: `4449dcfceee80f28f942077285d0686b9562849316cb36af940800f09ced9a43`
- files-driver.mjs: `a11d91a4460420b146c7f26caa0bdc2f5c30cd3fe2aac312c1207297906ebf09`
- original paid-gate.mjs: `2290b8af5a5a21646517a3e994e1f33c81bb58066b679b27f4bc9c6e3e788fc9`

## Important 1: new executable driver and oracle are not pinned to reviewed expected bytes before launch

Locations: files-paid-gate.mjs:152-172, 320-323, 341-355, 369-372; files-driver.mjs:33-38, 88-90.

The explicit expected source digest covers the lab's foundry.toml/src/test/script inventory. The new executable driver and imported independent oracle live outside that inventory in the temporary run directory. The gate hashes whatever driver bytes exist immediately before launch, but never compares them to an independently supplied reviewed expected hash. The driver similarly hashes whatever oracle is currently present and imports it immediately; it only compares that observed hash again after the paid work. Thus replacing either temporary script after independent review but before preflight produces a run with the same accepted expected source digest and no rejection. The post-run equality proves stability during the run, not execution of the reviewed program. This is a new authority/provenance gap introduced by moving the launch entrypoint outside the previously inventoried lab script tree.

Required scoped repair: supply mandatory exact expected hashes for both new scripts as root handoff inputs, validate them before the gate launches the driver and before the driver imports/prepares with the oracle, and retain those expected/observed values. Prefer executing/importing immutable gate-created copies; otherwise recheck the expected hashes immediately at use and after the run. Add pure rejection controls for a missing expected pin and changed driver/oracle bytes. This is independent of whether the eventual runner/oracle algorithms are correct.

## Important 2: evidence size limits can fail only after transactions, losing final raw output and summary

Locations: files-paid-gate.mjs:235-245; files-driver.mjs:25-30, 40, 46-50, 72-75, 95-99.

Preflight permits a 64 MiB complete compiler-info file plus nine separately accepted 8 MiB artifacts. The driver embeds all of them in `packet.build`, along with prepared expectations, measurement state and retained RPC traffic (up to 32 MiB of response bodies, plus request bytes). The final 96 MiB packet assertion is only evaluated after chain execution and cleanup. If it fails, it throws before either the raw sidecar or summary is created. The earlier checkpoint is not a complete fallback: it omits build/prepared provenance and is only updated when the runner calls onProgress, so it need not include the failing/latest request. Even a perfectly valid set of per-file preflight inputs can already exceed the final aggregate cap before the first transaction.

Required scoped repair: before spawning Anvil, bound the aggregate retained static packet and reserve explicit request/response/measurement space, or store bounded compiler/artifact evidence separately by content hash. Keep a small failure summary writable even if full evidence serialization/cap enforcement fails. For observations collected after the latest progress checkpoint, use a bounded append-only/raw observation sink or an equally durable final fallback. At minimum, prove with a pure boundary test that permitted preflight inputs cannot reach the post-run size assertion without preserved evidence; do not start a paid chain merely to test the limit.

## Minor 1: importing pure validators from Node stdin unexpectedly resolves '-' as a path

Location: files-paid-gate.mjs:400; inherited from the original gate.

The import-safe entrypoint check executes `fs.realpath(process.argv[1])` without handling a non-file argv entry. A normal `node --input-type=module -` stdin caller importing the validators fails with ENOENT realpath '-'. It does not start a subprocess, so this is an ergonomics/test-harness issue rather than a paid-run safety bypass. Making the entrypoint check tolerate a nonexistent/non-file argv path would restore the stated pure-import behavior. Existing file-based node:test callers are unaffected.

## Verified retained controls and API boundary

- The gate preserves exclusive wx slot acquisition, owner token/inode checks before release, a finite at-most-30-minute lease, absolute 14:00 cutoff, cleanup headroom, preflight cancellation checks, a no-await gap between the final check and spawn, and the existing heavy-process scan. The paid driver is launched as an owned detached process group; Anvil inherits that group. Cleanup escalates TERM/KILL, verifies group disappearance and child reaping, and retains the slot if cleanup fails.
- A gate-launched driver is additionally bounded by the five-minute/lease watchdog; resource monitoring retains the 50 GiB free reserve, 15 GiB aggregate scratch cap and bounded directory walk. Driver Anvil is loopback-only, Cancun/31337, block gas limit30,000,000, two accounts, prune-history128, private cache and fixed local mnemonic. No secondary node or compiler launch is introduced by the driver.
- Source snapshots preserve import containment, non-symlink bounded reads and immutable snapshot modes. The gate checks a successful same-source size report, compiler version/settings/source hashes, and all nine ABI/creation/runtime artifact joins twice before launch. It rechecks the lab source after successful execution. These are meaningful retained controls, subject to the external-script pin gap above.
- Gate and driver agree on nine artifact keys: registry, ledger, rootRule, childRule, index, lens, bob, consumer, wrapper. Driver calls `runFiles({rpc, artifacts, ethers:e, build, prepare:oracle.prepare, timeoutMs:30000, onProgress:checkpoint})` and prepares the independent fixture before spawning Anvil. Runtime/source proof and `audit(envelope)` correctness remain for the separate runner/oracle review; the driver honestly labels successful collection MEASURED_AWAITING_INDEPENDENT_AUDIT.
- Driver RPC transport checks response ID/version/result and streams bounded response bytes. Output creation uses exclusive writes; cleanup runs before final persistence. The driver alone does not acquire the heavy slot or validate a root lease/resource reserve: approved execution must remain through the gate, not a direct invocation of files-driver.mjs. This is an explicit operating boundary, not standalone-driver safety approval.

## Actual read-only checks

Both files passed Node26 `--check`. Pure in-memory Node validator tests passed for successful/failed build qualification, version/settings/source drift rejection, and all nine artifact keys with independent ABI/creation/runtime mismatch rejection. The first stdin import exposed Minor1; the retry explicitly removed the stdin-only argv placeholder before dynamic import and passed. No gate main, Forge, Anvil, RPC, installation, git mutation or subagent was invoked. Only this report was written.

The two Important findings block approval of the new root transport/launcher at the reviewed hashes. A focused re-review can inspect only those repairs and their pure controls; no paid run is needed to validate them.

## Focused re-review 1

Reviewed revised gate SHA256 `549cae58eda7d83dd5638f32f3d2296e6cfdbb3b1c73cf37c28882e22273a9ac` and driver SHA256 `f87fc5df6b3361b35022c7347197e6422ab50a1782de6e6488d5eca08598114f`. Original archive gate hash remains unchanged.

Important1: ADDRESSED for the missing expected-review pin. The gate now requires matching EFS_FILES_EXPECTED_DRIVER_HASH and EFS_FILES_EXPECTED_ORACLE_HASH before the paid child launch, and supplies the expected oracle pin to the driver, which checks it before import. Existing post-run driver and oracle stability checks remain. Root must supply the independently reviewed expected values, not derive them blindly from whatever is present at launch.

Important2: NOT YET FULLY ADDRESSED. The pre-chain static packet cap64 MiB, checkpoint measurement cap8 MiB, retained transcript cap8 MiB and final FAILED summary fallback are good scoped improvements. However, driver line93 assigns the final `runFiles` result directly to packet.measurement, bypassing checkpoint's measurement cap; request bytes at lines72-74 are retained and sent with no size bound; and line81 deletes the already-observed response on transcript overflow. These paths still permit a larger-than-reserved final packet and loss of collected evidence even when all new preflight checks passed.

Scoped remaining repair: validate/persist the final runner return through the same bounded checkpoint before replacing packet.measurement; impose a request-byte cap before sending; retain the last bounded response on transcript overflow and stop with a finite one-response overshoot allowance. With static packet<64 MiB, measurement<8 MiB and a transcript bounded to8 MiB plus one bounded response/request, the96 MiB final budget has provable room rather than depending on the runner's good behavior. Keep the explicit FAILED fallback as defense in depth.

Current verdict remains NeedsChanges solely for this remaining Important2 bound/preservation path. Minor1 remains nonblocking. No runtime/paid-workflow test was run during re-review.

## Focused re-review 2: Approved

Current reviewed hashes:

- files-driver.mjs: `621c2be70cb04a4dd853ffb5521ce15294a15085d05a0883f8f6d4635ac0d9e1`
- files-paid-gate.mjs: `549cae58eda7d83dd5638f32f3d2296e6cfdbb3b1c73cf37c28882e22273a9ac`
- original paid-gate.mjs remains `2290b8af5a5a21646517a3e994e1f33c81bb58066b679b27f4bc9c6e3e788fc9`.

Important1 remains ADDRESSED. Important2 is now ADDRESSED for the bounded one-shot Files workflow. Driver lines72-74 reject requests over1 MiB before retaining or sending them. Lines82-89 retain the final observed bounded response when the8 MiB soft transcript limit is crossed, annotate failure and throw; they no longer erase that response. Lines97-98 pass the final runner return through the same checkpoint cap before it can replace packet.measurement. The pre-launch64 MiB static budget,8 MiB measurement budget, bounded transport and final explicit FAILED fallback remain in place.

Actual pure controls passed against code extracted from these exact files, evaluated in a Node VM with a deterministic in-memory HTTP response and file sink only: an ordinary RPC result succeeds; an oversized request fails before fetch or packet insertion; transcript overflow preserves the complete last bounded response and records failure; oversized checkpoint output leaves the prior measured packet intact; missing/mismatched expected helper pins fail and matching pins pass. Both complete helper files also passed Node26 `--check`. No executable driver or gate main was imported/run; no actual HTTP, RPC, file write by the test sink, child process, compiler or Anvil was used.

A narrow interface inspection of the new runner and full wrapper found no obvious root-transport API mismatch: the nine artifact key names match, runFiles accepts the supplied RPC/build/prepare/progress arguments, prepare is consumed through its storageRequests field, and the wrapper's point/folder entrypoints emit the actual consumer-result hash using the expected query arguments. This is not a full semantic review of the runner or independent oracle and does not certify a future measured result.

Final scoped verdict: **Approved** for the root-owned gate/transport at the exact hashes above. Zero open Critical/Important findings in this scope. The inherited Minor1 stdin-import ergonomics issue remains nonblocking/deferred. Approval assumes invocation through the gate with the separately reviewed expected oracle hash, successful matching final build provenance, and the stated finite lease/resource checks. No paid run has been observed or authorized by this review itself; root retains execution authority and the independent output-audit gate.

## Focused re-review 3: compact machine JSON, Approved

Current driver SHA256: `e4656612a4c93cf14600bced1caaaa97ee34b4235806f75eadbf896d1eb4bc68`. Gate remains `549cae58eda7d83dd5638f32f3d2296e6cfdbb3b1c73cf37c28882e22273a9ac`.

Verified the entire driver differs from the previously approved version only by removing the indentation argument2 from its JSON helper (current line18). Restoring that one argument in memory reproduces the exact prior approved SHA256 `621c2be70cb04a4dd853ffb5521ce15294a15085d05a0883f8f6d4635ac0d9e1`. Node syntax passes, and a pure serialization control confirms identical parsed values, including unchanged bigint-to-string normalization. No caps, request handling, checkpoint behavior, hash pins, process controls or failure semantics changed; stored machine JSON is simply compact.

Root reports files-paid-1 failed the pre-chain static packet cap with67,456,046 pretty-JSON bytes versus29,205,486 compact bytes for the same values. This review did not independently remeasure those full packet sizes. It verifies the one-line change and unchanged semantics, not a paid result. Root reports no Anvil was spawned and retains the initial preflight report/log. A unique files-paid-2 gate remains the proposed first actual Anvil launch, not a rerun to improve a measured price.

Verdict: **Approved** for this one-line formatting change at the new exact driver hash. No new findings. Prior scoped approval and deferred Minor1 remain otherwise unchanged. Only this report was written; no heavy process, RPC, compiler or gate main was run.
