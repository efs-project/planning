# Paid Files runner — source-only work report

Assigned scope: the disposable approved six-write/six-read Files workflow, with
unchanged Core, Files profile and joined consumer. No Forge, Anvil, RPC, package
installation, Git or process-management actions are performed by this worker.

## Preparation

Read the full approved `files-paid-workflow-plan-20260914.md`, the local agent
brief, actual joined profile/consumer/fixture, Lens, Registry, Keys and existing
archive measurement helpers. Using test-first development. Parent runs RED and
GREEN under its resource lease; this report never substitutes source inspection
for execution evidence.

The new test inherits FilesJoinedTest to use real signed Alice publications and
genuine native Bob Actor. This duplicates inherited tests when running this
derived contract without a test-name filter; parent should select the new paid
test for focused RED. The actual paid runner deploys only the nine necessary
contracts, not LabBase's unrelated mocks or types.

## Runtime contract (frozen proposal)

`runFiles({rpc, artifacts, ethers, build, prepare, timeoutMs, onProgress})` receives the parent's
bounded recorded RPC function and complete artifact objects. It does not start a
node, install, compile or access the network except through the provided RPC.
Artifact and deployment keys are exactly registry, ledger, rootRule, childRule,
index, lens, bob, consumer and wrapper. Parent retains its literal RPC envelopes
and full compiler input/output beside the returned measurement packet.

Deployment/configuration nonces for default local account zero: registry0,
ledger1, rootRule2, registerRoot3, childRule4, registerChild5, index6, setIndex7,
lens8, bob9, consumer10, wrapper11. W1..W6 occupy12..17, and the six independent
paid reads18..23. No snapshots, resets or interleaved graph writes are needed.

The wrapper has immutable reader configuration, no storage result, and emits
`FilesRead(bytes32 indexed queryKey, bytes32 resultHash)`. Query keys bind the
reader address, exact consumer method selector, all arguments and the current
basis. The wrapper accepts no caller-provided expected answer hash. Result hashes
cover ABI encoding of the actual complete result struct from the checked reader.

Fixture: realm `lab/realm/1`, Alice deterministic local test key0xA11CE, File
salt401, folder `/drafts`, name `note.txt`, the existing three Meeting documents
at10:00/11:00/09:00 with trailing newline. Scan budget1 is frozen for exactly one
Alice placement and no Bob placement. Native authorship is not a portable proof.

## Test-first evidence and current source

Parent reports compiling RED at input
`27ae19f03a6f2df221a29a47b1346215385e24dee75eda50086ab8c691f72372`:
one focused test failed with `one actual paid Files result event`, zero passed.
The RED stub hash was
`0b796b01f6571313333654b692838851a39404608c76e8cd93eec9e87fa069e2`.
The parent retained its snapshot and `/tmp/.../files-paid-red.{json,log}` and
reported all its owned compiler processes stopped before authorizing GREEN code.
This worker did not run Forge and does not independently claim that gate passed.

Implemented minimal wrapper forwarding to the actual checked consumer, hashing
the entire returned struct, and emitting the exact method/arguments/basis key.
The focused test remains byte-for-byte unchanged from RED. It hand-constructs all
six full point/folder structs, including the complete empty Bob revision-filter
result and full exhausted cursor. It checks seven involved addresses have no
storage writes and that a stale point basis produces the exact consumer rejection
with no result event. Inputs include no expected-answer parameter.

GREEN-ready source hashes (September14, execution still parent-owned):

- `test/FilesPaidRead.sol`:
  `49b50c9aa7faeab7eeba1375468f68af4070a65373686758f56a01b919ceb169`
- `test/FilesPaidRead.t.sol`:
  `795c3647a64ad063813718d9d23003b39a3bd5fbe62f3d365394e7e4cc07d74c`
- `script/measure-files.mjs`:
  `247cc361ec980f2cf42aa787c594f79f8e409e6bc7d70d8633a471d5cfe012df`

Node syntax check and workspace whitespace check are clean. No actual chain run,
gas result, GREEN pass or affordability claim has been made by this worker.

## Raw packet / oracle handshake

The returned schema is `efs-lab-b/files-paid/1`. It retains all 24 signed outer
transactions with exact nonce, calldata, transaction/receipt/header joins, logs,
per-action gas and calldata counts. Nine deployments are itemized separately
from the two Type registrations and index attachment. Setup has no unrelated
Quote, binary, mock acceptance, archive or reconstructed-answer deployments.

`prepare(manifest, build)` is called after setup but before W1, before any of the
semantic workload. It receives a fully fixed fixture and returns the independent
oracle's flat `storageRequests`; the runner never copies expected answers or
passes them to the wrapper. The root may also call this pure preparation before
launch using predicted deployment addresses and full immutable-patched runtimes.
`snapshots.w6` and `.final` retain `{blockHash, blockNumber, cells}` with complete
32-byte cells at EIP-1898 block-hash bases. Root retains literal RPC envelopes.
All nine runtime byte strings are read at their own deployment block and again
at both seals. Runner compares non-immutable bytes and size only; the independent
AST/constructor checker is responsible for exact immutable values.

Signed Alice workloads are frozen before W1, with acceptance profiles derived
from exact rule identities, epoch2 and the index address/runtime commitment.
W5's whole genuine Bob forwarder transaction is charged. Every paid query is a
separate transaction after W6 without intervening graph writes; paid-event
answers are verified independently, not by candidate-generated read summaries.

Failure preserves the pending signed transaction before submission through the
parent's checkpoint callback. It leaves `FAILED`, never replaces missing rows
with an estimate, and throws so the parent stops the one-shot chain. There is no
snapshot/reset branch, transaction retry, external RPC discovery, gas quote,
state-growth estimate or benchmark-price optimization loop.
