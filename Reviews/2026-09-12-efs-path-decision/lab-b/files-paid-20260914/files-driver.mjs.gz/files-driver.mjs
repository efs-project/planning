// Root-owned one-shot local Files measurement driver. Outer gate owns process group.
import assert from 'node:assert/strict';
import * as fs from 'node:fs';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { pathToFileURL } from 'node:url';

const run='/tmp/efs-b-archive-task1.OXPOfb';
const lab='/Users/james/Code/EFS/planning-warroom-b-run/Reviews/2026-09-12-efs-path-decision/lab-b';
const anvil='/Users/james/.foundry/bin/anvil';
const map={registry:['TypeRegistry.sol','TypeRegistry'],ledger:['Ledger.sol','Ledger'],
  rootRule:['FilesJoinedProfile.sol','FilesRootRule'],childRule:['FilesJoinedProfile.sol','FilesChildRule'],
  index:['FilesJoinedProfile.sol','FilesParentIndex'],lens:['LensReader.sol','LensReader'],
  bob:['LabHarness.sol','Actor'],consumer:['FilesJoinedConsumer.sol','FilesJoinedConsumer'],wrapper:['FilesPaidRead.sol','FilesPaidRead']};
const sha=x=>createHash('sha256').update(x).digest('hex');
const json=x=>JSON.stringify(x,(_,v)=>typeof v==='bigint'?v.toString():v)+'\n';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const [flag,out,...extra]=process.argv.slice(2);
assert(flag==='--out'&&!extra.length&&/^\/tmp\/efs-b-archive-task1\.OXPOfb\/[a-z0-9-]+\.measurement\.json$/.test(out??''),'specific owned output required');
assert.equal(process.version,'v26.0.0');
assert(Date.now()<Date.parse('2026-09-14T13:55:00Z'),'no last-minute launch');
for(const p of [out,out+'.raw.json',out+'.checkpoint.json'])assert(!fs.existsSync(p),'output exists');
function readJson(p,cap=64*1024**2){const st=fs.lstatSync(p);assert(st.isFile()&&!st.isSymbolicLink()&&st.size<=cap,'JSON bound');return JSON.parse(fs.readFileSync(p,'utf8'));}
const input=process.env.EFS_FILES_COMPILER_INPUT;
assert(input?.startsWith(run+'/')&&process.env.FOUNDRY_OUT?.startsWith(run+'/'),'owned compiler artifacts required');
const compilerInfo=readJson(input);
const artifacts=Object.fromEntries(Object.entries(map).map(([k,[f,c]])=>[k,readJson(`${process.env.FOUNDRY_OUT}/${f}/${c}.json`,8*1024**2)]));
const build={compilerInfo,artifacts};
const e=createRequire(import.meta.url)(process.env.EFS_ETHERS_PATH);
assert.equal(e.version,'6.15.0');
const oraclePath=run+'/audit-files-paid.mjs';
const oracleHash=sha(fs.readFileSync(oraclePath));
assert(/^[a-f0-9]{64}$/.test(process.env.EFS_FILES_EXPECTED_ORACLE_HASH??''),'reviewed oracle hash required');
assert.equal(oracleHash,process.env.EFS_FILES_EXPECTED_ORACLE_HASH,'unreviewed oracle refused before import');
const oracle=await import(pathToFileURL(oraclePath));
assert.equal(typeof oracle.prepare,'function');
const prepared=await oracle.prepare({},build); // independent expected fixture before starting chain
const {runFiles}=await import(pathToFileURL(lab+'/script/measure-files.mjs'));
assert.equal(typeof runFiles,'function');
const packet={schema:'efs-lab-b/files-paid-root/1',evidenceLevel:'OWNED_LOCAL_RPC_OBSERVATION',
  startedAt:new Date().toISOString(),status:'UNMEASURED',build,prepared,oracleHash,rpc:[],chain:{},measurement:null};
assert(Buffer.byteLength(json(packet))<64*1024**2,'compiler/prepared packet exceeds pre-launch budget');
const dir=fs.mkdtempSync(run+'/files-anvil-');
const log=fs.openSync(dir+'/anvil.log','wx',0o600);
const abort=new AbortController();
let child,closed=true,done,timer,id=0,totalResponse=0,checkpointCreated=false;
function checkpoint(measurement){
  assert(Buffer.byteLength(json(measurement))<8*1024**2,'measurement packet cap');
  packet.measurement=measurement;
  const bytes=json({startedAt:packet.startedAt,chain:packet.chain,measurement,rpc:packet.rpc});
  assert(Buffer.byteLength(bytes)<48*1024**2,'checkpoint cap');
  fs.writeFileSync(out+'.checkpoint.json',bytes,{flag:checkpointCreated?'w':'wx',mode:0o600});checkpointCreated=true;
}
function stop(){if(child&&!closed)child.kill('SIGKILL');}
function interrupt(){abort.abort(Error('interrupted'));stop();}
process.once('SIGTERM',interrupt);process.once('SIGINT',interrupt);process.once('exit',stop);
try {
  const server=createServer();await new Promise((ok,no)=>{server.once('error',no);server.listen(0,'127.0.0.1',ok);});
  const port=server.address().port;await new Promise(ok=>server.close(ok));
  const args=['--host','127.0.0.1','--port',String(port),'--hardfork','cancun','--chain-id','31337',
    '--gas-limit','30000000','--accounts','2','--prune-history','128','--cache-path',dir+'/cache',
    '--timestamp','1800000000','--no-cors','--quiet','--mnemonic','test test test test test test test test test test test junk'];
  child=spawn(anvil,args,{stdio:['ignore',log,log]});closed=false;
  packet.chain={pid:child.pid,args,runDir:dir,port};
  done=new Promise(resolve=>{child.once('error',err=>{packet.chain.spawnError=err.message;});child.once('close',(code,signal)=>{closed=true;packet.chain.exitCode=code;packet.chain.exitSignal=signal;resolve();});});
  timer=setTimeout(()=>{abort.abort(Error('five minute deadline'));stop();},300000);
  const url=`http://127.0.0.1:${port}`;
  const rpc=async(method,params)=>{
    abort.signal.throwIfAborted();assert(++id<=5000,'RPC call cap');
    const request={jsonrpc:'2.0',id,method,params};const requestBytes=JSON.stringify(request);
    assert(Buffer.byteLength(requestBytes)<=1024**2,'RPC request byte cap before send');
    const observation={request};packet.rpc.push(observation);
    try {
      const res=await fetch(url,{method:'POST',headers:{'content-type':'application/json'},body:requestBytes,
        signal:AbortSignal.any([abort.signal,AbortSignal.timeout(10000)])});
      assert(res.ok,`RPC HTTP ${res.status}`);const reader=res.body.getReader();const chunks=[];let length=0;
      try {for(;;){const {value,done:ended}=await reader.read();if(ended)break;length+=value.length;totalResponse+=value.length;
        assert(length<=2*1024**2&&totalResponse<=32*1024**2,'RPC byte cap');chunks.push(Buffer.from(value));}}
      finally{await reader.cancel();}
      observation.response=JSON.parse(Buffer.concat(chunks,length).toString());
      // Keep the last bounded response even if it crosses the soft transcript
      // threshold. Stop further work rather than erase an observed chain fact.
      assert(Buffer.byteLength(json(packet.rpc))<8*1024**2,'retained RPC transcript cap');
      assert.equal(observation.response.id,request.id);assert.equal(observation.response.jsonrpc,'2.0');
      assert(!observation.response.error,JSON.stringify(observation.response.error));
      assert(Object.hasOwn(observation.response,'result'),'RPC result missing');return observation.response.result;
    }catch(err){observation.failure=err.message;throw err;}
  };
  let ready=false;
  for(let i=0;i<100;++i){assert(!closed&&!packet.chain.spawnError,'Anvil startup failed');
    try{assert.equal(await rpc('eth_chainId',[]),'0x7a69');ready=true;break;}
    catch{abort.signal.throwIfAborted();await sleep(50);}}
  assert(ready,'startup timeout');
  packet.chain.genesis=await rpc('eth_getBlockByNumber',['0x0',false]);
  const measured=await runFiles({rpc,artifacts,ethers:e,build,prepare:oracle.prepare,timeoutMs:30000,onProgress:checkpoint});
  checkpoint(measured); // final return cannot bypass the incremental packet cap
  assert.equal(sha(fs.readFileSync(oraclePath)),oracleHash,'oracle source drift');
  packet.status='MEASURED_AWAITING_INDEPENDENT_AUDIT';
}catch(err){packet.failure={message:err.message,stack:err.stack};packet.status='FAILED';process.exitCode=1;}
finally{
  clearTimeout(timer);stop();if(done)await done;packet.chain.stopped=closed;
  fs.closeSync(log);process.removeListener('SIGTERM',interrupt);process.removeListener('SIGINT',interrupt);process.removeListener('exit',stop);
  packet.finishedAt=new Date().toISOString();
  let bytes=json(packet);
  if(Buffer.byteLength(bytes)>=96*1024**2){
    packet.status='FAILED';packet.failure={message:'final evidence cap; complete sidecar unavailable; retain checkpoint'};process.exitCode=1;
    bytes=json({schema:packet.schema,status:packet.status,failure:packet.failure,chain:packet.chain,
      startedAt:packet.startedAt,finishedAt:packet.finishedAt,checkpoint:out+'.checkpoint.json',compilerInput:input,oracleHash});
  }
  fs.writeFileSync(out+'.raw.json',bytes,{flag:'wx',mode:0o600});
  fs.writeFileSync(out,json({status:packet.status,failure:packet.failure,rawSidecar:out+'.raw.json',sha256:sha(bytes),
    chainStopped:packet.chain.stopped,oracleHash,startedAt:packet.startedAt,finishedAt:packet.finishedAt}),{flag:'wx',mode:0o600});
}
console.log(json({status:packet.status,out,chainStopped:packet.chain.stopped}));
