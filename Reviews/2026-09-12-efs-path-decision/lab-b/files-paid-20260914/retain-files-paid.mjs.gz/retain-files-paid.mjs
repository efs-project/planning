import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {gzipSync, gunzipSync} from 'node:zlib';

// Mechanical retention only: no imports of executable experiments or oracles,
// subprocesses, RPC, compilation, test runs, git operations, or deletion.
const run = '/tmp/efs-b-archive-task1.OXPOfb';
const dest = '/Users/james/Code/EFS/planning-warroom-b-run/Reviews/2026-09-12-efs-path-decision/lab-b/files-paid-20260914';
const plan = '/Users/james/Code/EFS/planning/Reviews/2026-09-12-efs-path-decision/files-paid-workflow-plan-20260914.md';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const jsonBytes = value => Buffer.from(JSON.stringify(value, null, 2) + '\n');
function read(file) {
  const st = fs.lstatSync(file);
  assert(st.isFile() && !st.isSymbolicLink(), `regular input required: ${file}`);
  assert(st.size <= 96 * 1024 * 1024, `bounded input required: ${file}`);
  return fs.readFileSync(file);
}
const readJson = file => JSON.parse(read(file));
const pinned = {
  'files-paid-2.measurement.json.raw.json': '80f7b6ac5a81d44ce46c7d107bb4f332b341bbfde24512bcd1c368bbe7d5906a',
  'audit-files-paid.mjs': 'fd6b0212b6dc8f1d2294e5ce9b42b3a30141038b593666bdc4e2565e9cb3097e',
  'audit-files-paid-quantities.mjs': '848aea6291c05007b503af6f21d597a6df26dd3ab61e1d601a8f7326937d2b1e',
  'files-driver.mjs': 'e4656612a4c93cf14600bced1caaaa97ee34b4235806f75eadbf896d1eb4bc68',
  'files-paid-gate.mjs': '549cae58eda7d83dd5638f32f3d2296e6cfdbb3b1c73cf37c28882e22273a9ac',
  'files-paid-prepared.json': '94ef68850782cdff11eaf4f9f6a11551eba3b79fa207a6a2d42db9524b743c35',
  'files-paid-root-audit.json': '0cbd8d760e48e2e1f59a2169a9ff03c4c1988728251a23c32c452636889a395f',
  'files-paid-audit-negatives.json': 'fa3958331340014197965ec602c5cc67c7ddef01833ad0030eae129f7c0849fa',
};
for (const [name, expected] of Object.entries(pinned)) assert.equal(sha(read(path.join(run, name))), expected, name);

const sourceDigest = 'ac5481077ab59ad11131e861f6ed2722c27377d93b043a916aeae446a3e2360c';
const red = readJson(`${run}/files-paid-red.json`);
const green = readJson(`${run}/files-paid-green.json`);
const size = readJson(`${run}/files-paid-size.json`);
const first = readJson(`${run}/files-paid-1.json`);
const actual = readJson(`${run}/files-paid-2.json`);
const audit = readJson(`${run}/files-paid-root-audit.json`);
const negatives = readJson(`${run}/files-paid-audit-negatives.json`);
for (const gate of [red, green, size, first, actual]) {
  assert.equal(sha(JSON.stringify(gate.source)), gate.sourceDigest, `${gate.label} source manifest`);
  assert.equal(gate.expectedSourceDigest, gate.sourceDigest);
  assert(gate.ownedProcessesStopped && gate.slotReleased, `${gate.label} cleanup`);
}
for (const gate of [green, size, actual]) {
  assert.equal(gate.sourceDigest, sourceDigest);
  assert.equal(gate.outcome.code, 0);
  assert(!gate.failure && !gate.stopReason);
}
assert.equal(first.outcome.code, 1);
assert.equal(first.sourceDigest, sourceDigest);
assert.match(read(`${run}/files-paid-1.log`).toString(), /compiler\/prepared packet exceeds pre-launch budget/);
assert.equal(red.outcome.code, 1);
assert.equal(red.sourceDigest, '27ae19f03a6f2df221a29a47b1346215385e24dee75eda50086ab8c691f72372');
assert.match(read(`${run}/files-paid-red.log`).toString(), /one actual paid Files result event/);
assert.match(read(`${run}/files-paid-red.log`).toString(), /0 tests passed, 1 failed, 0 skipped/);
assert.match(read(`${run}/files-paid-green.log`).toString(), /1 tests passed, 0 failed, 0 skipped/);
assert.equal(red.source['test/FilesPaidRead.t.sol'], green.source['test/FilesPaidRead.t.sol']);
assert.equal(audit.status, 'INDEPENDENT_FILES_RAW_AUDIT_PASS');
assert.equal(audit.rawPacketSha256, pinned['files-paid-2.measurement.json.raw.json']);
assert.equal(negatives.rawSha256, audit.rawPacketSha256);
assert.equal(negatives.negative.length, 4);
assert(negatives.negative.every(row => row.rejected));
assert.equal(negatives.candidateCostSummaryIgnored, true);

const files = new Map();
function add(name, file, description) {
  assert.equal(path.basename(name), name);
  assert(!files.has(name), `unique retained basename: ${name}`);
  files.set(name, {file, description});
}
function generated(name, value, description) {
  assert(!files.has(name));
  files.set(name, {bytes: jsonBytes(value), description});
}
for (const label of ['files-paid-red-pin', 'files-paid-red', 'files-paid-green-pin', 'files-paid-green', 'files-paid-size', 'files-paid-1', 'files-paid-2']) {
  for (const ext of ['json', 'log']) add(`${label}.${ext}`, `${run}/${label}.${ext}`, 'Original gate report or complete log; empty pin logs intentionally retained.');
}
for (const name of [
  'files-paid-2.measurement.json', 'files-paid-2.measurement.json.checkpoint.json',
  'files-paid-2.measurement.json.raw.json', 'files-paid-prepared.json',
  'files-paid-root-audit.json', 'files-paid-audit-negatives.json',
  'files-paid-audit-negatives.mjs', 'audit-files-paid.mjs',
  'audit-files-paid-quantities.mjs', 'audit-files-final.mjs',
  'files-driver.mjs', 'files-paid-gate.mjs', 'retain-files-paid.mjs',
]) add(name, `${run}/${name}`, 'Unmodified original evidence or explicitly named executable source; retention does not execute it.');
add('approved-files-paid-workflow-plan.md', plan, 'Executed bounded plan; exhaustive storage growth explicitly optional/UNKNOWN.');
for (const label of ['scope-plan', 'runner-report', 'oracle-report', 'source-review', 'root-preflight-review', 'final-review']) {
  add(`${label}-20260914.md`, `/tmp/efs-b-files-paid-${label}-20260914.md`,
    label === 'scope-plan' ? 'Earlier proposal only; approved plan supersedes its mandatory exhaustive-slot-capture request.' : 'Full original preparation/review report; read dated follow-ups and final verdict.');
}

const compilers = [
  ['red', red, `${run}/files-paid-red.state/build-info/a050f785177b4dc4.json`],
  ['green', green, `${run}/files-paid-green.state/build-info/ac4d92334ad138c9.json`],
  ['size', size, `${run}/files-paid-size.state/build-info/e45d649592bb9722.json`],
];
for (const [label, gate, file] of compilers) {
  const build = readJson(file);
  assert(build.input?.sources && build.output?.contracts && build.output?.sources);
  for (const [name, source] of Object.entries(build.input.sources)) {
    assert.equal(sha(source.content), gate.source[name], `${label} full compiler source ${name}`);
  }
  add(`${label}-full-compiler-info.json`, file, 'Original complete compiler input and output, including source, AST, settings, metadata, ABI, creation/deployed bytecode and immutable references.');
  const snapshot = {};
  for (const [name, expected] of Object.entries(gate.source)) {
    assert(!path.isAbsolute(name) && !name.split('/').includes('..'));
    const bytes = read(path.join(gate.snapshot, name));
    assert.equal(sha(bytes), expected, `${label} frozen source ${name}`);
    snapshot[name] = {sha256: expected, bytes: bytes.length, content: bytes.toString('utf8')};
    assert.equal(sha(snapshot[name].content), expected, `${label} utf8 roundtrip ${name}`);
  }
  generated(`${label}-frozen-source-inventory.json`, {sourceDigest: gate.sourceDigest, sourceHashes: gate.source, files: snapshot},
    'Mechanical UTF-8 escrow of every gate-inventoried foundry/src/test/script source, copied from the frozen snapshot, not the changing worktree.');
}
assert.equal(sha(read(actual.build.input.path)), actual.build.input.sha256);
assert.equal(sha(read(actual.build.report.path)), actual.build.report.sha256);
for (const [key, artifact] of Object.entries(actual.build.artifacts)) {
  assert.equal(sha(read(artifact.path)), artifact.sha256, `${key} exact artifact`);
  add(`artifact-${key}.json`, artifact.path, 'Exact original deployment artifact pinned by the actual paid gate; full objects are also embedded in raw evidence.');
}
for (const [name, source] of [
  ['red-stub-FilesPaidRead.sol', `${red.snapshot}/test/FilesPaidRead.sol`],
  ['green-FilesPaidRead.sol', `${green.snapshot}/test/FilesPaidRead.sol`],
  ['unchanged-FilesPaidRead.t.sol', `${green.snapshot}/test/FilesPaidRead.t.sol`],
  ['frozen-measure-files.mjs', `${actual.snapshot}/script/measure-files.mjs`],
]) add(name, source, 'Convenience copy from exact frozen snapshot; complete source inventory is retained separately.');

const priced = audit.gasRows.map(row => ({label: row.label, gas: Number(BigInt(row.gasUsed)), calldataBytes: row.calldataBytes}));
const expectedGas = [758965,3792004,164153,148387,332251,153743,1439629,45139,2092488,520560,3601492,682872,1289277,523569,523557,708640,777820,523544,197363,204877,269336,284384,269360,280014];
assert.deepEqual(priced.map(row => row.gas), expectedGas, 'reviewed receipt economics unchanged');
assert.equal(priced.length, 24);
const sum = rows => rows.reduce((n, row) => n + row.gas, 0);
const manifest = {
  kind: 'DISPOSABLE_REAL_FILES_ONE_RUN_RECEIPT_ECONOMICS',
  date: '2026-09-14',
  sourceCommit: 'de56345e07863d46d656b4a1a077348de7d2c25d',
  sourceDigest,
  actualChainRuns: 1,
  refusedPreflights: 1,
  actualRun: {label: actual.label, startedAt: actual.startedAt, finishedAt: actual.finishedAt, exitCode: actual.outcome.code, ownedProcessesStopped: actual.ownedProcessesStopped, slotReleased: actual.slotReleased},
  sourceTests: {focusedRedFailed: 1, focusedGreenPassed: 1, focusedTestUnchanged: true, inheritedTestsDuplicatedUnlessFiltered: true, normalSizeBuildExitCode: size.outcome.code},
  audit: {status: audit.status, expectedFixtureFrozenBeforeRun: true, transactions: audit.transactions, admissions: audit.admissions, records: audit.records, bindings: audit.bindings, publications: audit.publications, modeledCellsPerBasis: audit.storageCellsPerBasis, corruptionsRejected: negatives.negative.length, candidateCostSummaryIgnored: true},
  pins: pinned,
  corrections: {
    preflight: 'Pretty compiler/preparation machine JSON exceeded static 64MiB cap before Anvil; formatting-only compact JSON change; same semantics and cap; one actual run after refusal.',
    audit: 'Original oracle retained; post-run quantity-aware oracle compares signature r/s as equal integers despite JSON-RPC padding. Exact source diff reviewed; expected fixtures/state/answers unchanged; changed signature integer still rejected.',
  },
  evidenceLevel: 'OWNED_LOCAL_RPC_OBSERVATION_NOT_AUTHENTICATED_STATE_PROOF',
  persistentStorageGrowth: 'UNKNOWN; 247 modeled cells are not exhaustive slot differences',
  economics: {setupGas: sum(priced.slice(0,12)), sixWritesGas: sum(priced.slice(12,18)), sixAlternativeReadsInventoryGas: sum(priced.slice(18)), readSumIsCompulsoryBill: false, effectiveGasPriceWei: '2000000000', liveNetworkQuote: false, rows: priced},
  limits: 'B_ONLY_TINY_FILES; NO_MUD_PARITY; NO_FULL_LIFECYCLE_PRICE; NO_COLD_NAMES_BROWSER_SCALE_HISTORY_PAGING_OR_NATIVE_HISTORICAL_PROOF; NO_USD_AFFORDABILITY_TOTAL_LIFETIME_OVERHEAD_OR_PRODUCTION_CLAIM',
  custody: 'Retained without source/test/chain/audit rerun. Original byte inputs are compressed unchanged; generated source escrows label their derivation. Prior reports remain historical even where later reviews supersede them.',
  files: {},
};
assert.equal(manifest.economics.setupGas, 13731683);
assert.equal(manifest.economics.sixWritesGas, 4346407);
assert.equal(manifest.economics.sixAlternativeReadsInventoryGas, 1505334);

// Refuse existing evidence; never overwrite or delete a packet.
assert(!fs.existsSync(dest), 'retention destination must be new');
fs.mkdirSync(dest);
for (const [name, item] of files) {
  const bytes = item.bytes ?? read(item.file);
  if (pinned[name]) assert.equal(sha(bytes), pinned[name], `input stayed pinned: ${name}`);
  const zipped = gzipSync(bytes, {level: 9});
  const retainedName = `${name}.gz`;
  const retainedPath = path.join(dest, retainedName);
  fs.writeFileSync(retainedPath, zipped, {flag: 'wx'});
  const kept = read(retainedPath);
  const roundtrip = gunzipSync(kept);
  assert.deepEqual(roundtrip, bytes, `roundtrip: ${name}`);
  manifest.files[retainedName] = {
    rawBytes: bytes.length, rawSha256: sha(bytes), gzipBytes: kept.length,
    gzipSha256: sha(kept), roundtripVerified: true, description: item.description,
  };
}
manifest.totals = Object.values(manifest.files).reduce((n, item) => ({files: n.files + 1, rawBytes: n.rawBytes + item.rawBytes, gzipBytes: n.gzipBytes + item.gzipBytes}), {files: 0, rawBytes: 0, gzipBytes: 0});
const manifestBytes = jsonBytes(manifest);
fs.writeFileSync(path.join(dest, 'manifest.json'), manifestBytes, {flag: 'wx'});
assert.deepEqual(readJson(path.join(dest, 'manifest.json')), manifest);
console.log(JSON.stringify({status: 'RETENTION_BYTE_ROUNDTRIP_PASS', dest, manifestSha256: sha(manifestBytes), ...manifest.totals}, null, 2));
