// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;

import {FilesJoinedConsumer} from "./FilesJoinedConsumer.sol";

/// Disposable paid-call instrument. No cached answer, caller-supplied result hash,
/// or persistent read result. This is not a production SDK or proof of chain state.
contract FilesPaidRead {
    FilesJoinedConsumer public immutable reader;
    event FilesRead(bytes32 indexed queryKey, bytes32 resultHash);

    constructor(FilesJoinedConsumer reader_) { reader = reader_; }

    function point(bytes32, address[] calldata, bytes32, FilesJoinedConsumer.Basis calldata) external {
        // RED stub: the focused test must observe the missing real result event.
    }

    function folder(bytes32, address[] calldata, bytes32, FilesJoinedConsumer.TagScope,
        uint256, FilesJoinedConsumer.Basis calldata) external
    {
        // RED stub: deliberately no event until root observes the compiling RED.
    }
}
