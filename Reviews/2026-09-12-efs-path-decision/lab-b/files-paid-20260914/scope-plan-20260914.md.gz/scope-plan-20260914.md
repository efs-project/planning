# B actual Files: one bounded paid-workflow proposal

Standing: source-only proposal, 2026-09-14; no implementation/run authorization. Candidate pin d54a120 is supplied by the coordinator, not independently rechecked here.

## Recommendation and value

Do one B-only micro-run **only if** its new runner/wrapper and independent expected packet can be frozen within 60 minutes and reviewed before 13:00 UTC; reserve 13:00–14:00 for audit/handoff. Otherwise report Files economics unmeasured and stop. Existing Quote receipts cannot price real checked parents or selected-revision tags. Do not repeat C, Quote, reverse-query or archive comparisons.

This answers “what does this exact tiny checked workflow cost?” It cannot prove “affordable” without a user workload/fee budget: report gas per action and an explicit workload formula, not a dollar quote, adoption verdict or invented affordability threshold. The implementation effort is worthwhile only as a thin reuse of current Files contracts plus the retained paid-event/evidence pattern; any new query architecture makes it not worth this cutoff.

## Frozen scope and exact transaction boundaries

Use one fresh private Realm, Alice EOA, deployed native Bob producer, one folder `/drafts`, one stable File F, and exact UTF-8 R0=`Meeting at 10:00.\n`, RA=`Meeting at 11:00.\n`, RB=`Meeting at 09:00.\n`. Root body is F || document; Child body is parent || F || document. RA and RB both reference R0, never each other. L-A=[Alice,Bob], L-B=[Bob,Alice].

| Row | One separately priced logical action |
| --- | --- |
| S | Deploy/configure registry, Ledger, Root/Child mandatory rules and registered Types, FilesParentIndex, LensReader, FilesJoinedConsumer, native producer and tiny event wrapper. Attach Files index before any admission. Itemize every setup transaction; omit LabBase's unrelated Quote/Pair, mocks and diagnostic deployments. |
| W1 | Alice signed create F + publish R0 + bind HEAD(F)=R0 + place F at `/drafts/note.txt`, atomically; **no tags**. |
| W2 | Alice separate File tag: TAG(subject=F, concept=project_efs, target=F). |
| W3 | Alice separate revision tag: TAG(subject=R0, concept=draft, target=F). |
| W4 | Alice signed publish RA + checked HEAD update from her R0 head; one atomic action. |
| W5 | Outer EOA calls the genuine deployed Bob producer; it natively publishes RB + Bob's competing HEAD(F)=RB. Charge the entire outer transaction, including forwarding; no Bob EOA signature, impersonation or prewritten storage. |
| W6 | Alice separate revision tag: TAG(subject=RA, concept=approved, target=F). |

Use expected binding revisions/nonces, current acceptance profile and mandatory index obligations. Freeze exact intents, actions, bodies and expected IDs before writes. If an action requires multiple receipts, expose their total and partial-landing risk; do not quietly batch W1–W6. No rename/move/restore, scale, archive retention, SDK, browser or live-chain arm: lifecycle coverage is separate.

## Minimal unrelated paid reads

At sealed post-W6 graph basis, execute six independent transactions, with no intervening graph writes. Current FilesJoinedConsumer requires the exact current admission/generation/epoch/core tuple; retain that tuple plus graph block hash and each later paid block hash. Independent transactions avoid cross-query warm-storage discounts; no snapshot arms are needed when reads emit logs only.

| Rows | Existing call and independently expected outcome |
| --- | --- |
| P-A/P-B | `readFilePoint(F, L-A/L-B, approved, basis)`: present F; RA/RB respectively; exact document digest and parent R0; approved revision stance present/absent. The File-tag assessment for concept approved is absent in both, not project_efs. |
| T-F-A/T-F-B | `readFolderTaggedOnce(drafts, L-A/L-B, project_efs, File, budget, basis)`: complete singleton F with RA/RB respectively. |
| T-R-A/T-R-B | Same folder method with concept approved and SelectedRevision scope: complete singleton F@RA / complete empty result. The empty result must prove complete coverage, not merely hash an empty array. |

Freeze the smallest sufficient raw scan budget from this exact fixture before execution (one Alice placement and no Bob placement; include both author scans). Do not raise it after a failure. These six reads jointly test open/filtered-list agreement and preserve the excluded Bob revision's checked point result.

Add only a storage-free paid wrapper, using ArchiveReadConsumer's pattern: call the pinned deployed FilesJoinedConsumer and emit one `FilesRead(queryKey, resultHash)` event where resultHash=keccak256(abi.encode(actual full returned struct)). queryKey commits method, arguments and basis; it must not accept a caller-supplied answer hash. One event per transaction; no cached/mocked expected response. Report wrapper-inclusive gas, not a bare getter estimate. Existing view consumer need not be edited.

## Cost/evidence rows required

For S's individual transactions, W1–W6 and each paid read retain raw signed transaction, destination/data/nonce/value/chain, mined receipt/status/gas, matching header/logs, calldata length and zero/nonzero-byte counts, transaction count and approval count. Receipt gas includes publication, required parent-index maintenance and wrapper event overhead; never subtract maintenance into an unpriced prerequisite.

For every deployment report whole deployment gas, exact complete initcode (constructor arguments included), patched deployed runtime bytes/codehash and normal EIP-170/EIP-3860 limits. Separate common bootstrap, Files-specific setup and measurement-only wrapper setup; disclose extra deployments if the minimal route is unavailable.

For each W row and setup report persistent slot changes across every touched contract: zero→nonzero, nonzero→nonzero, nonzero→zero and net occupied 32-byte slots; retain bounded raw pre/post values or trace-derived diffs tied to blocks and independently check them. Report deployed code bytes separately. Paid reads must add no contract storage. Do not equate ABI body size or record count with total state growth; if complete bounded storage capture cannot be reused safely, stop preparation rather than fabricate this row.

Present W1 create, W2/W3/W6 tag marginals, W4 EOA edit and W5 native edit separately; total six-write journey excludes S. Query costs are alternatives, not a compulsory six-read bill. Give totalGas = setup + sum(write counts × corresponding receipt gas) + sum(query counts × corresponding paid gas), with this fixture's counts explicit and no scaling inference.

## Independent success test and stop conditions

Before launch, a preparer independent of runner outputs derives Type/Record/File identities, byte hashes, bindings/revisions, contract-origin principal, expected admissions and parent postings from pinned codecs/source and frozen actions. After W1 and W6, independently read raw admitted state, not FilesJoinedConsumer/LensReader/SDK outputs, to check exact retained R0/RA/RB, distinct authorship, checked same-F parentage, native admission provenance, both heads, exact folder coordinate, all three tag subjects and required-index coverage. Parent enumeration must contain RA and RB once each under R0; preservation is independently visible even though these six paid queries do not price enumeration.

Independently derive every full returned struct/cursor and both Lens outcomes from that state, then compute all six exact expected event bytes. Verify deployed runtime against compiler output and constructor immutables, event emitter/count/topics/data, transaction-to-receipt-to-header joins and unchanged graph bases. An event hash or receipt status alone is not success; neither is matching a candidate-generated expected hash. No historical native-contract source-proof claim follows from checking local current admission.

Use the same coordinator-owned private root-runner/lease discipline, bounded scratch/cache, local-only RPC, one launch, fixed resource watchdog and explicit process shutdown; create a separately named Files runner/packet, **never edit archived runners/evidence**. New paid wrapper/runner source tests and independent packet review precede launch. Keep compiler profile and normal deployment/block limits unchanged; no dependencies, feature expansion or optimization loop.

Stop at preparation deadline, source drift, unavailable independent oracle, unsupported storage capture, test failure, normal-size failure, failed receipt, budget exhaustion, incomplete/conflicting coverage, native-authorship mismatch or any semantic/event mismatch. Preserve failure evidence and report UNMEASURED/FAILED by exact row; no second launch to improve prices. Even a passing run remains local RPC-observed tiny-Files economics, not full lifecycle, portable proof, production readiness or owner-approved affordability.
