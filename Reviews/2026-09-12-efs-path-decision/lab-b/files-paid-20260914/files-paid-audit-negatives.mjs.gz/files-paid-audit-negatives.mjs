import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {audit} from './audit-files-paid-quantities.mjs';
const run='/tmp/efs-b-archive-task1.OXPOfb';
const raw=fs.readFileSync(run+'/files-paid-2.measurement.json.raw.json','utf8');
const report={rawSha256:createHash('sha256').update(raw).digest('hex'),negative:[]};
function reject(name,mutate,expected){const p=JSON.parse(raw);mutate(p);let error;try{audit(p);}catch(e){error=e;}assert(error,`missed corruption ${name}`);assert.match(error.message,expected);report.negative.push({name,rejected:true,error:error.message.slice(0,450)});}
reject('missing transaction',p=>p.measurement.transactions.pop(),/all setup\/config\/W\/read transactions/);
reject('changed signature integer',p=>{
  const tx=p.measurement.transactions[5];tx.transaction.r='0x1';
  for(const x of p.rpc)if(x.request.method==='eth_getTransactionByHash'&&x.request.params[0]===tx.hash)x.response.result.r='0x1';
},/signature r quantity/);
reject('fabricated complete paid answer',p=>{
  const tx=p.measurement.transactions.find(t=>t.label==='P-A'),data='0x'+'00'.repeat(32);
  tx.receipt.logs[0].data=data;
  for(const x of p.rpc)if(x.request.method==='eth_getTransactionReceipt'&&x.request.params[0]===tx.hash)x.response.result.logs[0].data=data;
},/exact value mismatch/);
reject('wrong selected Head raw target',p=>{
  const cell=p.measurement.snapshots.w6.cells.find(x=>x.label==='Head target'&&x.value===p.measurement.fixture.ra);assert(cell);
  for(const x of p.rpc)if(x.request.method==='eth_getStorageAt'&&x.request.params[0].toLowerCase()===cell.address.toLowerCase()&&x.request.params[1]===cell.slot)x.response.result='0x'+'00'.repeat(32);
},/missing joined raw RPC eth_getStorageAt/);
const tamperedSummary=JSON.parse(raw);for(const row of tamperedSummary.measurement.rows)row.gasUsed='1';
const independent=audit(tamperedSummary);assert(independent.gasRows.every(x=>BigInt(x.gasUsed)>1n));
report.candidateCostSummaryIgnored=true;report.status='FOUR_CORRUPTIONS_REJECTED_AND_RECEIPT_COST_CONTROL_PASS';
fs.writeFileSync(run+'/files-paid-audit-negatives.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(report,null,2));
