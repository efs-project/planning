# Final paid Files packet review

**Verdict: Approved** for the retained one-run receipt-economics experiment. No open Critical or Important findings in this final packet/reconciliation scope. This does not approve a future chain run or new workflow.

## Evidence identity and actual checks

Reviewed the full corrected340-line oracle, its complete diff against the original339-line oracle, source/preparer reviews, final audit script, retained gate/log/raw packet/audit report, and corruption-control source/report. Ran bounded offline Node checks only; no Forge, compiler, Anvil, RPC, git mutation or subagent. Only this report was written.

- Actual raw packet: `files-paid-2.measurement.json.raw.json`,31,288,779 bytes, SHA256 `80f7b6ac5a81d44ce46c7d107bb4f332b341bbfde24512bcd1c368bbe7d5906a`.
- Original prelaunch oracle retained: `fd6b0212b6dc8f1d2294e5ce9b42b3a30141038b593666bdc4e2565e9cb3097e`.
- Corrected quantity-aware audit oracle: `848aea6291c05007b503af6f21d597a6df26dd3ab61e1d601a8f7326937d2b1e`.
- Retained root audit report SHA256: `0cbd8d760e48e2e1f59a2169a9ff03c4c1988728251a23c32c452636889a395f`.
- Retained negative-control report SHA256: `fa3958331340014197965ec602c5cc67c7ddef01833ad0030eae129f7c0849fa`.
- Gate/source digest: `ac5481077ab59ad11131e861f6ed2722c27377d93b043a916aeae446a3e2360c`; actual driver pin is the independently reviewed `e4656612a4c93cf14600bced1caaaa97ee34b4235806f75eadbf896d1eb4bc68`.

Independently verified the raw-packet hash, gate expected/source manifest digest, exact size-report hash, full compiler-info file hash and parsed content, and all nine artifact file hashes/content joins against the raw envelope. Recovered all24 outer signed transactions from their raw bytes and checked nonce order, transaction hashes, successful receipt gas versus block gas, actual retained RPC receipt equality, signature integer equality,2,000,000,000 wei effective gas price, and calldata/zero-byte counts. The displayed cost numbers below are derived from those receipt/signature inputs, not candidate gas summaries.

Ran one offline corrected-oracle replay against the retained packet and compared every field it returns to the stored root audit report: exact equality, `INDEPENDENT_FILES_RAW_AUDIT_PASS`. This was a CPU-only replay of existing evidence, not a chain rerun or new measurement.

## Audit correction is representational, not a relaxed signature or answer check

The complete diff contains only (1) an explicit default assertion message, (2) comparison of observed transaction r/s and decoded-signature r/s as BigInt integers instead of lowercased padded strings, and (3) one trailing blank line. Reconstructing those changes in memory reproduced the entire original source byte-for-byte.

Three retained transactions have r or s strings with padding differing from ethers' fixed-width signature strings; all integer values match. Raw transaction hash checks, decoded sender recovery, exact signed transaction/calldata boundaries, chain/nonce/fee checks, Alice intent recovery, and all event/state expectations remain unchanged. The new comparison still rejects a changed signature integer, as the retained actual corruption control demonstrates. It does not merely skip r/s checks.

The original model was not retrofitted to the observed answers. Independently loaded the external pre-run `files-paid-prepared.json` and verified its SHA256 `94ef68850782cdff11eaf4f9f6a11551eba3b79fa207a6a2d42db9524b743c35`; it is deeply identical to original-oracle prepare, corrected-oracle prepare, and the raw packet's prepared value. This additionally verifies the external frozen artifact, beyond audit-files-final.mjs's comparison to the packet's embedded preparation. All six expected full encodings/query keys/hashes and all247 storage-request coordinates are unchanged.

## Observed run, provenance and cleanup

files-paid-1 failed at the initial packet-size assertion before the driver reaches its Anvil spawn. Its log records `compiler/prepared packet exceeds pre-launch budget`; its gate reports exit1, stopped ownership and released slot. There is no first price to optimize. The compact-JSON-only change and unique files-paid-2 label produced the first actual Anvil run; previous failed-preflight evidence remains retained.

files-paid-2 gate ran from11:48:29.022Z to11:48:31.566Z on2026-09-14 and exited0 with no failure, stop reason, or signal. Its driver packet records the owned Anvil stopped; Anvil's SIGKILL is the intentional cleanup action, not a failed workflow receipt. Gate records ownedProcessesStopped=true and slotReleased=true. The finite lease and14:00 absolute cutoff checks passed; retained prelaunch resources were291,584,188,416 free bytes and1,190,162,147 scratch bytes, satisfying50 GiB reserve and15 GiB aggregate scratch caps. This short run finished before the five-second recurring resource monitor interval; do not imply a longer sampled resource series.

Actual chain settings are loopback-only, chain31337, Cancun,30,000,000 block gas, two local accounts, prune-history128, private run cache and fixed test mnemonic/timestamp. Compiler settings are Solidity0.8.30, viaIR, optimizer enabled/runs200, Cancun. All nine patched deployed runtimes are below normal24,576-byte limits: registry3270, Ledger17280, RootRule513, ChildRule1284, index5287, Lens9445, Bob2159, consumer15896, wrapper2908. Actual deployment initcode/calldata is below49,152 bytes for each deployment, including constructor arguments; no enlarged runtime/initcode setting was used to excuse an oversized production instrument.

## Semantic result and controls

The replay joins all24 signed outer transactions and exact expected logs with retained RPC transactions/receipts/headers, checks uninterrupted block ancestry, and verifies exact immutable-patched deployed runtime bytes. It derives expectations from the pinned compiler/source and literal workflow, not producer-returned IDs/results or gas rows.

At the post-W6 seal and after all six paid reads, all247 modeled raw cells match independently derived values. The model covers11 admissions,3 Records,6 bindings and6 publications; genuine signed Alice and native Bob evidence; exact Root/Child bodies; author-qualified heads; relevant absent/present tag tiers; index progress/coverage; and retained R0 children at first admissions7 and9. The six wrapper events equal the independently encoded entire result structs:

| Read | Verified result |
| --- | --- |
| P-A | Alice-first F@RA, approved present on selected RA |
| P-B | Bob-first F@RB, approved absent on selected RB |
| F-A | Complete File-project join returns F@RA |
| F-B | Complete File-project join returns F@RB |
| R-A | Complete selected-revision-approved join returns F@RA |
| R-B | Complete, exhausted, empty selected-revision-approved result |

All six reads share frontier11/generation0/epoch2/Core commitment with no intervening graph write. R-B's cursor retains selectedSoFar1 for the placement before tag filtering while the returned Files array is empty; it is not PARTIAL silently represented as empty.

Read the four retained corruption controls and their actual rejection report: missing transaction, changed signature integer, fabricated paid answer, and changed selected-HEAD raw target each reject. The candidate gas-summary mutation control still returns receipt-derived gas greater than1. These controls were not rerun needlessly during this review; their code/report and input hash were verified, while the actual base packet received one offline replay.

## Receipt economics: exact logical boundaries

All gas numbers charge the whole outer transaction, including required index callbacks, Bob forwarding where relevant, and wrapper event/forwarding for reads. No internal-test gas is substituted, no callback cost is subtracted, and setup is not hidden inside application rows.

| Setup row | Gas | Calldata bytes |
| --- | ---: | ---: |
| deploy/registry | 758,965 | 3,329 |
| deploy/ledger | 3,792,004 | 17,734 |
| deploy/rootRule | 164,153 | 539 |
| registerRoot | 148,387 | 132 |
| deploy/childRule | 332,251 | 1,434 |
| registerChild | 153,743 | 164 |
| deploy/index | 1,439,629 | 8,884 |
| setIndex | 45,139 | 36 |
| deploy/lens | 2,092,488 | 9,835 |
| deploy/bob | 520,560 | 2,363 |
| deploy/consumer | 3,601,492 | 20,231 |
| deploy/wrapper | 682,872 | 3,079 |

Setup total: **13,731,683 gas** (nine deployments plus three configuration transactions).

| Workflow row | Gas | Calldata bytes |
| --- | ---: | ---: |
| W1: signed CREATE F + PUBLISH R0 + HEAD + placement | 1,289,277 | 1,988 |
| W2: separate project_efs tag on F | 523,569 | 868 |
| W3: separate draft tag on R0 | 523,557 | 868 |
| W4: signed PUBLISH RA + HEAD CAS expected1 | 708,640 | 1,316 |
| W5: Bob Actor native PUBLISH RB + HEAD expected0 | 777,820 | 932 |
| W6: separate approved tag on RA | 523,544 | 868 |
| P-A | 197,363 | 324 |
| P-B | 204,877 | 324 |
| F-A | 269,336 | 388 |
| F-B | 284,384 | 388 |
| R-A | 269,360 | 388 |
| R-B | 280,014 | 388 |

W1–W6 total: **4,346,407 gas**. The six paid read receipts are separate alternative operations, not a compulsory user journey or a combined necessary bill; each was a separate transaction without cross-transaction warm-storage sharing. Their receipt inventory sums to1,505,334 gas only as an experiment-accounting fact, not a recommended six-read purchase.2 gwei is a fixed local transaction parameter, not a current network fee quote.

## Mandatory limits on claims

This closes one B-only tiny actual paid Files workflow: one File, three real revisions, one hashed placement, six exact read alternatives. It does not price the Task3 move/reuse/whiteout/restore lifecycle or a complete Files product. No cold-name reconstruction, browser, scale, historical pagination, portable historical native authority, dollar affordability, mainnet readiness, or total lifetime cost follows.

Persistent storage growth remains **UNKNOWN**. The247 semantic cells at each seal are not exhaustive storage diffs or state-bloat measurements. Headers, receipts and raw state are joined owned-local RPC observations, not authenticated trie/header/state proofs. Compiler/build provenance is retained and checked, not independently recompiled into a cryptographic reproducible-build claim. Review approval does not authorize another benchmark, future withdrawal controls or a new chain run.
