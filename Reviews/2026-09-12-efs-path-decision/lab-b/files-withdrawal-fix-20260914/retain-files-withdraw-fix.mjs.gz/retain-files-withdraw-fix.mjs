import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {gzipSync, gunzipSync} from 'node:zlib';

// Evidence retention only. Never imports or runs a gate/test/oracle; no RPC,
// process launch, installation, git, deletion, or changing live source inputs.
const run = '/tmp/efs-b-archive-task1.OXPOfb';
const dest = '/Users/james/Code/EFS/planning-warroom-b-run/Reviews/2026-09-12-efs-path-decision/lab-b/files-withdrawal-fix-20260914';
const task = '/Users/james/Code/EFS/planning-warroom-b-run/.superpowers/sdd/files-withdrawal-reader-fix-plan-20260914/task-1-report.md';
const plan = '/Users/james/Code/EFS/planning/Reviews/2026-09-12-efs-path-decision/files-withdrawal-reader-fix-plan-20260914.md';
const review = '/tmp/efs-b-files-withdrawal-fix-review-20260914.md';
const sha = b => createHash('sha256').update(b).digest('hex');
function read(file) {
  const st = fs.lstatSync(file);
  assert(st.isFile() && !st.isSymbolicLink(), `regular input: ${file}`);
  assert(st.size <= 64 * 1024 * 1024, `bounded input: ${file}`);
  return fs.readFileSync(file);
}
const json = file => JSON.parse(read(file));
const encode = value => Buffer.from(JSON.stringify(value, null, 2) + '\n');
const red = json(`${run}/files-withdraw-fix-red.json`);
const full = json(`${run}/files-withdraw-fix-full.json`);
const size = json(`${run}/files-withdraw-fix-size.json`);
const redDigest = '20a9fdbe7e6f4f6caba836ce95717d2f4f78d9fc97d8bac4e787156befc18db9';
const greenDigest = 'a03f75cdc3de9f8db1ccc3aa5fdc66dad5dede451756ac2498545dee17bc9c67';
const testHash = 'f191978d5881a9660ceb58b3424f90bb5361503230905f3cf9dae5c5b2b8e0d2';
const oldConsumerHash = 'faf1e68e5dc92d56da6d39a7893ec0f7d4b06f13e04678ee04a62655c803005d';
const newConsumerHash = '0d45a6603f4fd055abe59307d93bcf651b4d66d98d89854a073265d0860713ae';
assert.equal(sha(read(review)), '0957266b21df512c228c0d4223fd8ad886acfb558046057f7f244179bf9505dd');
assert.equal(red.sourceDigest, redDigest);
assert.equal(red.outcome.code, 1);
for (const gate of [red, full, size]) {
  assert.equal(sha(JSON.stringify(gate.source)), gate.sourceDigest);
  assert.equal(gate.sourceDigest, gate.expectedSourceDigest);
  assert.equal(gate.source['test/FilesWithdrawal.t.sol'], testHash);
  assert.equal(gate.outcome.signal, null);
  assert(gate.ownedProcessesStopped && gate.slotReleased);
  assert(!gate.failure && !gate.stopReason);
  for (const [name, hash] of Object.entries(gate.source)) {
    assert(!path.isAbsolute(name) && !name.split('/').includes('..'));
    assert.equal(sha(read(path.join(gate.snapshot, name))), hash, `${gate.label} ${name}`);
  }
}
for (const gate of [full, size]) {
  assert.equal(gate.outcome.code, 0);
  assert.equal(gate.sourceDigest, greenDigest);
  assert.equal(gate.source['test/FilesJoinedConsumer.sol'], newConsumerHash);
  assert.deepEqual(Object.keys(gate.source).filter(n => gate.source[n] !== red.source[n]), ['test/FilesJoinedConsumer.sol']);
}
assert.equal(red.source['test/FilesJoinedConsumer.sol'], oldConsumerHash);
const redLog = read(`${run}/files-withdraw-fix-red.log`).toString();
const fullLog = read(`${run}/files-withdraw-fix-full.log`).toString();
assert.match(redLog, /0 tests passed, 3 failed, 0 skipped/);
assert.equal([...redLog.matchAll(/^\[FAIL: E_PROFILE\(\)\] test_withdraw_/gm)].length, 6); // summary repeats the three failures
assert.match(fullLog, /158 tests passed, 0 failed, 0 skipped/);
const names = [...fullLog.matchAll(/^\[PASS\] (\S+) /gm)].map(m => m[1]);
assert.equal(names.length, 158);
assert.equal(new Set(names).size, 124);
assert.equal(names.filter(n => n.startsWith('test_withdraw_')).length, 3);
const multiplicities = new Map();
for (const n of names) multiplicities.set(n, (multiplicities.get(n) ?? 0) + 1);
assert.equal([...multiplicities.values()].filter(n => n === 3).length, 17);
assert([...multiplicities.values()].every(n => n === 1 || n === 3));

const payloads = new Map();
function add(name, file, description) {
  assert.equal(path.basename(name), name);
  assert(!payloads.has(name));
  payloads.set(name, {file, description});
}
function generated(name, value, description) {
  assert(!payloads.has(name));
  payloads.set(name, {bytes: encode(value), description});
}
for (const label of ['files-withdraw-fix-red', 'files-withdraw-fix-full', 'files-withdraw-fix-size']) {
  for (const ext of ['json', 'log']) add(`${label}.${ext}`, `${run}/${label}.${ext}`, 'Complete original gate report or unabridged log.');
}
for (const [name, gate, file] of [
  ['red-full-compiler-info.json', red, `${run}/files-withdraw-fix-red.state/build-info/579d98e679854390.json`],
  ['size-full-compiler-info.json', size, `${run}/files-withdraw-fix-size.state/build-info/749d33d224d58d18.json`],
]) {
  const build = json(file);
  assert(build.input?.sources && build.output?.contracts && build.output?.sources);
  for (const [source, value] of Object.entries(build.input.sources)) assert.equal(sha(value.content), gate.source[source], source);
  add(name, file, 'Original complete compiler input/output: source, settings, AST, metadata, ABI, creation/deployed bytecode and immutable references.');
}
add('task-report.md', task, 'Full original phase-1/phase-2 implementation report; its then-pending gates are closed only by the separate final review.');
add('independent-final-review.md', review, 'Execution-linked final independent review; Approved, with bounded claims.');
add('approved-plan.md', plan, 'Actual approved narrow reversible reader-fix plan.');
add('red-FilesJoinedConsumer.sol', `${red.snapshot}/test/FilesJoinedConsumer.sol`, 'Exact old consumer used by the actual failing corrective regression.');
add('green-FilesJoinedConsumer.sol', `${size.snapshot}/test/FilesJoinedConsumer.sol`, 'Exact new consumer used by passing regression and normal-size gates.');
add('unchanged-FilesWithdrawal.t.sol', `${size.snapshot}/test/FilesWithdrawal.t.sol`, 'Corrective test bytes identical across actual RED and GREEN.');
add('frozen-foundry.toml', `${size.snapshot}/foundry.toml`, 'Frozen unchanged compiler configuration; never copied from the changing live worktree.');
add('retain-files-withdraw-fix.mjs', `${run}/retain-files-withdraw-fix.mjs`, 'Mechanical retention source; not executed by archive inspection.');
for (const [name, gate] of [['red', red], ['green', size]]) {
  const files = {};
  for (const [source, hash] of Object.entries(gate.source)) {
    const bytes = read(path.join(gate.snapshot, source));
    files[source] = {sha256: hash, bytes: bytes.length, content: bytes.toString('utf8')};
    assert.equal(sha(files[source].content), hash, `UTF-8 escrow ${source}`);
  }
  generated(`${name}-frozen-source-inventory.json`, {sourceDigest: gate.sourceDigest, sourceHashes: gate.source, files},
    'Mechanical UTF-8 escrow of every gate-inventoried source/config/script, verified against the immutable execution snapshot.');
}

const manifest = {
  kind: 'DISPOSABLE_WITHDRAWAL_RETAINED_READ_CORRECTION',
  sourceCommit: 'd60318efbc6b3a71a0914ebb11b2ebeebab08893',
  sourceDigest: greenDigest,
  redSourceDigest: redDigest,
  priorCharacterizationCommit: '1fe8c4cd26f689f7905f66313d7a8ffc93359c6d',
  testSha256: testHash,
  oldConsumerSha256: oldConsumerHash,
  newConsumerSha256: newConsumerHash,
  tests: {red: {passed: 0, failed: 3, reason: 'E_PROFILE'}, green: {executionsPassed: 158, distinctNamedCases: 124, inheritedRepeats: 34, correctivePassed: 3, failures: 0, skipped: 0}, correctiveTestUnchanged: true},
  review: 'APPROVED_SPEC_COMPLIANT_QUALITY_APPROVED; NO_OPEN_CRITICAL_IMPORTANT_OR_ACTIONABLE_MINOR',
  behavior: 'RETAINED_VALID_SELECTED_DATA_READABLE_AT_ZERO_OCCURRENCES; BOB_REUSE_DOES_NOT_TOGGLE_ALICE_SELECTION; MAINTENANCE_SEPARATE',
  change: 'GUARD_ONLY: REMOVE_AGGREGATE_COUNT_PROFILE_CONDITION_AND_UNUSED_LOCAL; QUALIFICATION_COMMENT; NO_CORE_INDEX_PROFILE_OR_OTHER_TEST_CHANGES',
  sizes: {compiler: 'Solidity 0.8.30 viaIR optimizer200 Cancun', FilesJoinedConsumer: {runtimeBytes: 15865, compilerInitcodeBytes: 19976}, FilesParentIndex: {runtimeBytes: 5287, compilerInitcodeBytes: 8724}, Ledger: {runtimeBytes: 17280, compilerInitcodeBytes: 17670}, constructorArgumentsExcludedFromCompilerInitcode: true},
  gates: [red, full, size].map(g => ({label: g.label, startedAt: g.startedAt, finishedAt: g.finishedAt, sourceDigest: g.sourceDigest, exitCode: g.outcome.code, ownedProcessesStopped: g.ownedProcessesStopped, slotReleased: g.slotReleased})),
  limits: 'NO_NEW_PAID_COSTS; NO_CORE_LIFECYCLE_CHANGE; NO_PRODUCTION_API_OR_UNIVERSAL_DISPLAY_POLICY; NAMED_STATE_SUBSETS_NOT_EXHAUSTIVE_STATE_PROOFS; PRIOR_PAID_PACKET_PRICES_OLD_INPUT_ONLY',
  custody: 'Mechanical retention only, no test/chain/audit rerun. Frozen execution inputs used throughout; unrelated later Index repair excluded.',
  files: {},
};
assert(!fs.existsSync(dest), 'refuse existing retention packet');
fs.mkdirSync(dest);
for (const [name, item] of payloads) {
  const raw = item.bytes ?? read(item.file);
  const nameGz = name + '.gz';
  fs.writeFileSync(path.join(dest, nameGz), gzipSync(raw, {level: 9}), {flag: 'wx'});
  const gz = read(path.join(dest, nameGz));
  assert.deepEqual(gunzipSync(gz), raw, `byte roundtrip ${name}`);
  manifest.files[nameGz] = {rawBytes: raw.length, rawSha256: sha(raw), gzipBytes: gz.length, gzipSha256: sha(gz), roundtripVerified: true, description: item.description};
}
manifest.totals = Object.values(manifest.files).reduce((a, f) => ({files: a.files + 1, rawBytes: a.rawBytes + f.rawBytes, gzipBytes: a.gzipBytes + f.gzipBytes}), {files: 0, rawBytes: 0, gzipBytes: 0});
const encoded = encode(manifest);
fs.writeFileSync(path.join(dest, 'manifest.json'), encoded, {flag: 'wx'});
assert.deepEqual(json(path.join(dest, 'manifest.json')), manifest);
console.log(JSON.stringify({status: 'RETENTION_BYTE_ROUNDTRIP_PASS', dest, manifestSha256: sha(encoded), ...manifest.totals}, null, 2));
