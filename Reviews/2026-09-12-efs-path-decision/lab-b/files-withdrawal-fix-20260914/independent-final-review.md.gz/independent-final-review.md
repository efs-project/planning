# Retained Files withdrawal reader correction — independent review

**Final verdict: Approved. SpecCompliant and QualityApproved for the bounded
retained-read correction. No open Critical, Important or actionable Minor finding
in this review scope.** Actual compiling RED, unchanged corrective expectations,
guard-only GREEN, complete regression and normal-size evidence are linked below.

Scope: the September 14 approved `files-withdrawal-reader-fix-plan-20260914.md`,
the exact corrective test delta from retained characterization, and the narrow
consumer correction. The earlier read-policy advice is context, not proof of this
implementation. No code, git, Forge, compiler, Anvil, RPC, dependency, subagent,
paid-packet replay or historical benchmark changes were performed by this
reviewer. Only this review report is written.

## Corrective test and preserved controls

Read the full approved plan, full corrective `FilesWithdrawal.t.sol`, complete
diff against the immutable characterization snapshot, implementer task report,
original consumer, relevant real Core/Index and inherited fixture helpers, and
the retained characterization review. Root supplied base commit `1fe8c4c`;
comparison here is to its retained execution snapshot rather than a new git read.

The corrective test SHA256 is
`f191978d5881a9660ceb58b3424f90bb5361503230905f3cf9dae5c5b2b8e0d2`.
The RED consumer remains
`faf1e68e5dc92d56da6d39a7893ec0f7d4b06f13e04678ee04a62655c803005d`.
The complete characterization-vs-RED source manifests differ only at
`test/FilesWithdrawal.t.sol`.

A bounded read-only comparison confirms 13 helper bodies remain byte-for-byte
unchanged: `_countsBefore`, `_oneLifecycleAction`, `_postingWords`,
`_postingBefore`, `_releasedExactlyOnce`, `_headDigest`, `_allFixtureBindings`,
`_retainedPostingState`, `_completeCurrentFamilies`, `_assertZeroRetained`,
`_withdrawAliceSole`, `_publishNewChild`, and `_threeRootChildren`. The correction
does not obtain success by weakening withdrawal, indexing, native/signed evidence,
counter/nonce, retained-byte, parent-list or actual new-child controls.

### Exact retained values and provenance

`FilesWithdrawal.t.sol:132–172` adds exact assertions, not merely successful
calls. `_assertPoint` requires FOUND, the intended File, exact revision ID/Type,
parent/File identity, exact document and document hash through the unchanged
`FilesJoined.t.sol:329–337` helper. Each evaluated tag is checked for exact subject,
target, status, presence and evaluated flag. Fixture absence is the explicit
unbound state, not a general reinterpretation of UNKNOWN or revocation.

`_selectedAuthor` joins the real Lens-selected author/target/revision/admission to
the matching authored Core HEAD. `FilePoint` itself has no author field, so this
is a separate provenance control rather than a claim that a new public field was
introduced. `_assertCandidate` checks every existing Lens Entry field—position,
author, target, revision and admission—against the actual authored HEAD, and
checks both complete RA/RB revision values.

`_retainedReadControls` (`FilesWithdrawal.t.sol:188–209`) requires Alice-first
F@RA, File-project membership, selected-RA approval and a two-candidate conflict
with Alice RA then Bob RB. Bob controls (`174–186`) still require F@RB,
File-project membership and a COMPLETE-empty selected-revision-approved result.
No automatic fallthrough to another author or lost conflict candidate is accepted.

### Complete folder semantics and changing bases

The inherited `_folder` (`FilesJoined.t.sol:393–404`) is unchanged. Every call
requires COMPLETE, not mutated, exhausted Lens/raw indexes, and exact current
admission/generation/epoch/Core plus Lens and scope hashes. Corrective controls
also require selectedSoFar1 for this one-placement fixture and exact returned
values under both tag scopes. Bob's approved result is empty *after* a selected
placement, not an empty result standing in for insufficient coverage.

Data digests intentionally omit changing cursor basis fields: a withdrawal or
REUSE advances the ledger frontier. Each fresh call checks its own current basis
before the exact returned data is compared. This tests invariant selected data,
not falsely claiming that the complete chain or cursor state never changes.
These are bounded one-folder getter controls, not an independent raw-state
enumeration oracle or a scale experiment.

### Three non-vacuous lifecycle cases

1. `test_withdraw_selected_revision_retained_and_readable` (`211–222`) records
   complete selected values/conflicts before real signed withdrawal of sole RA,
   proves count0 retained bytes and unchanged authored bindings/index subsets,
   and requires identical returned values afterwards. It separately asserts
   Alice HEAD revision2 still selects RA.
2. `test_withdraw_parent_keeps_descendants_and_new_child_admissible` (`249–271`)
   preserves both zero-count parent branches. Retained withdrawn R0 still supports
   existing RA/RB and a genuinely new child; withdrawn RA still supports a newly
   published and selected grandchild, with exact parent membership and HEAD
   revision3. Both ancestors remain exact count0, withdrawn retained Records.
   This exercises actual mandatory admission, not just a rule predicate or REUSE.
3. `test_withdraw_other_author_reuse_does_not_toggle_selected_reads` (`273–298`)
   records readable exact data while RA has count0. Bob's real Actor then creates
   a native REUSE, restoring count1 without clearing Alice's withdrawal or moving
   any HEAD/path/tag binding. The full data digest must be identical afterwards.
   The corrected wording says one maintained occurrence, not one unique maintainer.

The unchanged raw helpers check exactly one lifecycle admission/publication,
actual-author-only nonce advancement, no new Record/Binding counts, retained
original first admission/body/Type/hash and withdrawn flag, exact named by-Type
and by-author live decrements, preserved packed ordinal words, and complete
current six-family coverage. Named HEAD/placement/tag and parent/history/scope/
backlink snapshots remain explicit subsets; this review does not recast them as
exhaustive state-diff evidence.

## Actual compiling RED

Read `files-withdraw-fix-red.json` and its complete log from the retained private
run directory. Source digest:
`20a9fdbe7e6f4f6caba836ce95717d2f4f78d9fc97d8bac4e787156befc18db9`.
Recomputed manifest SHA256 agrees; the frozen test and old consumer match the
pins above. The gate selected `FilesWithdrawalTest` and `test_withdraw_`, so the
three new cases are not an inflated count of inherited tests.

The Solidity compilation completed. All three named corrective cases failed
with `E_PROFILE()`: zero passed, three failed, zero skipped. The root gate ran
2026-09-14 12:13:50.673Z–12:14:09.406Z, exited1/signal null, recorded owned
processes stopped and released its slot. This is a meaningful behavioral RED,
not an import/compiler failure. Oversized inherited test-harness warnings are
not consumer deployment-size evidence.

At the RED stage there was no blocking corrective-test finding. Root subsequently
authorized only removal of the consumer occurrence-count integrity condition,
its unused local, and a small qualification comment. The focused expectations
remained frozen. Approval was withheld until that exact change and the actual
GREEN/regression/normal-size outputs were reviewed, as completed below.

## Authorized GREEN source review

Read the full two-hunk consumer diff against the immutable RED snapshot and
the implementer's complete phase-2 report. The frozen consumer SHA256 is
`0d45a6603f4fd055abe59307d93bcf651b4d66d98d89854a073265d0860713ae`.
Reconstructed the new source in memory from the old source using only the four
authorized textual edits: the two-line qualification comment, removal of the
occurrence local, omission of the tuple value, and deletion of the zero-count
condition. The result equals the entire frozen GREEN consumer byte-for-byte.

Rehashed every file in the RED source inventory against the frozen full-GREEN
source directory. Only `test/FilesJoinedConsumer.sol` changes, and the whole input
digest is `a03f75cdc3de9f8db1ccc3aa5fdc66dad5dede451756ac2498545dee17bc9c67`.
The corrective test remains exactly `f191978d...`; existing Files, paid-wrapper,
parent-budget and all other inventoried tests, Core, Index, profile, scripts and
configuration stay unchanged.

`_decode` still requires nonzero selected identity, exact Root/Child Type,
nonzero first admission at/before the requested current basis, bounded body,
matching content-addressed ID, matching original PUBLISH kind/Type/body hash,
minimum grammar prefix, matching existing File identity and bounded correct
parent relationship. `_guard`, mandatory profile pins, Lens-first selection,
conflict checks and folder completeness logic are untouched. The two-line comment
states the distinction without adding a public result field or policy fallback.

Existing tests still assert exact fail-closed behavior for malformed profiles,
insufficient budgets, stale admission/generation/epoch/Core, detached/wrong indexes,
PARTIAL scope coverage, masked/absent HEADs and wrong-target tags. The source
change corrects only the maintenance-versus-retained-profile conflation; it does
not broadly turn profile errors into successful data. No blocking GREEN-source
finding was identified. The actual final gates were then reviewed below.

## Actual GREEN, full regression and normal sizes

Read the complete `files-withdraw-fix-full.log`, its full gate report, the
`files-withdraw-fix-size.json` gate report, relevant complete size table and
unchanged Foundry configuration. Recomputed both source-manifest digests and
individually rehashed every inventoried source in each frozen snapshot. Both
match `a03f75cdc3de9f8db1ccc3aa5fdc66dad5dede451756ac2498545dee17bc9c67`,
the reviewed consumer `0d45a660...`, and unchanged corrective test `f191978d...`.
No expected assertion changed between the observed RED and GREEN.

The actual full suite passed **158 executions, zero failures, zero skipped**.
The three `test_withdraw_` cases each passed on the unchanged corrective test;
this full run provides their GREEN without needing a redundant focused rerun.
Read-only parsing of the complete pass list found **124 distinct named cases**:
the 17 existing Files tests run once in their base contract and repeat in each
of the paid and withdrawal derived contracts, accounting for **34 inherited
repeats**. They are not 158 independent scenarios. Existing malformed-profile,
parent rejection/rollback, stale/incomplete, mask/tag, conflict, actual Files
lifecycle/churn and paid-wrapper behavior tests all remain present and passed.

Full-regression gate: 2026-09-14 12:16:39.531Z–12:17:30.048Z, exit0/signal null.
Normal-size gate: 2026-09-14 12:18:26.511Z–12:19:17.307Z, exit0/signal null.
Both report no failure or stop reason, ownedProcessesStopped=true and
slotReleased=true. These are read-backs of root-owned execution evidence;
this reviewer did not launch another test, build, chain or benchmark.

The normal Solidity0.8.30/viaIR/optimizer200/Cancun size table reports:

| Component | Runtime bytes | Compiler initcode bytes |
| --- | ---: | ---: |
| FilesJoinedConsumer | 15,865 | 19,976 |
| FilesParentIndex | 5,287 | 8,724 |
| Ledger | 17,280 | 17,670 |

These runtime/compiled-initcode sizes are below 24,576/49,152 respectively;
the table is not a newly measured deployment transaction, and constructor
arguments are not silently counted as part of its compiler-initcode column.
The new consumer's seven fixed constructor words add224 bytes, still comfortably
within the initcode limit. Expected oversized *test harness* warnings do not
describe the three deployable components above or imply mainnet readiness.
Compiler warnings remain visible, not represented as a warning-free build.

The actual RED/GREEN transition plus preserved exact-value controls supports
the intended correction: reaching count0 no longer invalidates retained selected
Files or poisons these folder/conflict reads, and Bob REUSE cannot toggle Alice's
selected display. Core occurrence accounting/withdrawn evidence and authored
selection are retained. The implementation introduces no maintenance policy,
application revocation, fallthrough, new API enum, or production change. Approval
closes this narrow corrective task, not any remaining architectural or economic
gate.

## Claim boundaries retained

Occurrence withdrawal is not Record deletion, authored HEAD removal, application
revocation, availability, distinct-maintainer counting, or Lens fallthrough.
This correction should return retained, structurally valid selected data without
claiming current maintenance/application validity. Same-basis qualified Core
maintenance facts remain separate; no new unqualified result boolean or enum is
introduced. The pre-fix paid packet remains frozen and prices only its old input.
No new paid cost, production readiness, universal display policy, privacy claim,
or permanent Core lifecycle decision follows from these regression tests.
