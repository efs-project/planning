# Task 1 — retained Files reader correction

## Phase 1: REDREADY

Read the complete main plan and independent read-policy advice. Changed only `test/FilesWithdrawal.t.sol` in the B lab, plus this report. The consumer remains frozen pending root-observed behavioral RED. No compiler, Forge, Anvil, RPC, installation, git operation, or subagent was used by this implementer.

The three corrective tests now require successful exact retained reads after Alice's selected RA reaches zero maintained occurrences. They verify complete revision identity/type/parent/File/document/hash; both exact evaluated tag assessments; full conflict candidate bindings and revisions for Alice RA and Bob RB; selected author/revision/admission against the retained raw HEAD; and both complete folder-tag scopes with fresh exact cursor context. Bob-first still selects RB and its approved folder is complete-empty after one placement selection.

The selected-revision case compares all returned data before/after withdrawal. The parent case preserves zero-occurrence Root and Child parent branches and genuine new-child/grandchild admission, strengthening the newly selected grandchild's complete point and author checks. The other-author case captures readable data at zero occurrences and requires identical data after Bob's genuine native REUSE, while Alice's original occurrence remains withdrawn. Changing cursor basis fields are intentionally excluded from data digests and independently checked by `_folder` against current state on every call. Occurrence wording no longer claims a unique maintainer count.

Removed the obsolete expected-`E_PROFILE` helpers; no missing-data/profile errors are accepted as corrective success. With the unchanged consumer, each case should reach a post-withdrawal RA read and revert at its existing `occurrences == 0` guard. This is an expectation, not an observed RED or compilation claim. Root owns the exact three-case frozen gate before any consumer change.

## Source preservation / self-review

Compared these 13 raw/lifecycle/action helpers byte-for-byte against the immutable characterization source: `_countsBefore`, `_oneLifecycleAction`, `_postingWords`, `_postingBefore`, `_releasedExactlyOnce`, `_headDigest`, `_allFixtureBindings`, `_retainedPostingState`, `_completeCurrentFamilies`, `_assertZeroRetained`, `_withdrawAliceSole`, `_publishNewChild`, `_threeRootChildren`. All are unchanged. Signed withdrawal evidence, native REUSE evidence, counters/nonces, exact retained bytes/identity/withdrawal, unchanged bindings and parent/history/scope/backlink postings, occurrence-list release, family coverage, exact CAS, and parent-list membership assertions remain.

Read actual Ledger head/record, Lens resolve/conflict, consumer structures, fixture helpers and folder basis checks before using their signatures. Tag absence here is the explicit unbound fixture state, not a general equivalence between absence and invalidity. No fallback, Core/profile change, new result enum, unrelated test change, or old paid/oracle edit. No production, adoption, availability, replica-count, or new paid-cost claim.

## RED snapshot SHA-256

- `test/FilesWithdrawal.t.sol`: `f191978d5881a9660ceb58b3424f90bb5361503230905f3cf9dae5c5b2b8e0d2`
- `test/FilesJoinedConsumer.sol` (unchanged): `faf1e68e5dc92d56da6d39a7893ec0f7d4b06f13e04678ee04a62655c803005d`
- `test/FilesJoined.t.sol` (unchanged): `65d4dc7514cc026d7879aec158fd562953b63135161730af0290f3d25be00b18`
- `src/Ledger.sol` (unchanged): `7576874b52a81ebc0f7b64640332b345096e0c09000ed4f09811bdc21dd6c3d5`
- `src/IndexModule.sol` (unchanged): `43618a994095f3d73902f23521c055c8950cdc043f8d8ca74e9b83aef67f1592`
- `test/FilesJoinedProfile.sol` (unchanged): `c701bf700c122d0c1fd0c3f6b51630c3c0b9bdb6902e0975b8b6a3095cf43cdf`

No trailing whitespace found. Awaiting root's actual RED evidence and explicit GREEN-phase authority; consumer edits are not yet authorized.

## Phase 2: GREENREADY after observed RED

Root authorized the narrow consumer correction after its frozen actual gate. Read `/tmp/efs-b-archive-task1.OXPOfb/files-withdraw-fix-red.json` and the relevant log output: compilation succeeded; exactly 0 passed / 3 failed, each with `E_PROFILE()`; exit 1; owned processes stopped and slot released. The RED source digest was `20a9fdbe7e6f4f6caba836ce95717d2f4f78d9fc97d8bac4e787156befc18db9`, with the test and consumer hashes listed above. This was behavioral RED, not a compilation failure.

Applied only the authorized consumer delta: removed the unused `uint32 occurrences` local, omitted that tuple result, removed `|| occurrences == 0`, and added two API-comment lines stating that results describe retained selected data rather than current occurrence maintenance or application validity, and withdrawal does not change HEAD selection. Exact comparison against the immutable RED consumer confirms only those two diff hunks. All remaining type/body/hash/admission/File/parent/profile/basis/completeness checks are untouched.

- GREENREADY consumer SHA-256: `0d45a6603f4fd055abe59307d93bcf651b4d66d98d89854a073265d0860713ae`
- Corrective test SHA-256 remains exactly `f191978d5881a9660ceb58b3424f90bb5361503230905f3cf9dae5c5b2b8e0d2`; no assertions were changed after RED.

No execution or paid remeasurement by this implementer. GREENREADY means source frozen for root's focused GREEN, complete regression, normal-settings size gate, and independent review; it does not claim these pending gates passed. Prior paid measurements remain evidence only for their original frozen consumer.
