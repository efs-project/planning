# Task 1 report

## Stage 1: REDREADY (2026-09-14)

Base `c653f50`; tracked worktree clean before edits. Unrelated untracked `.codex-*-message` files preserved. Own source files only plus this assigned report. No compiler, Forge, solc, Anvil, RPC, dependency, commit, or subagent action performed.

- `FilesJoinedProfile.sol` SHA256 `5a8641d1dbbf6a709bdb0e4841d9886cbb3177dd58bb27511a3d4d057c9c1f8b`
- `FilesJoined.t.sol` SHA256 `cd6900c520143c8ca1e62ad364cb705157f7b4d22a1ee3a59616fe3e29914045`
- Ledger unchanged SHA256 `7576874b52a81ebc0f7b64640332b345096e0c09000ed4f09811bdc21dd6c3d5`

Stub stage: false Child acceptor; Root predicate real; raw-layout helper present; no Files-parent index yet, deliberately no assertions for that later stage. Focus behavioral RED: `test_revision_acceptance_history` in `FilesJoinedTest`; expect first Child's exact `E_REJECTED(0, childType)` after successful signed Root setup. Compilation remains root-owned and unverified by worker.

Other tests frozen: `test_root_requires_existing_nonzero_file_and_shape`, `test_missing_unrelated_and_wrong_file_parents_roll_back`, `test_cold_large_root_and_child_headers_accept`. Negatives follow genuine positive controls. Snapshots explicitly cover nonce, four counts, Alice's current head, Child-Type and Alice-author posting heads, plus separately absent candidate Record. No all-storage-equality claim.

The cold test is not a repeat merely for count: unlike the earlier diagnostic, the profile now validates a real Subject and accepts Child parents with File in word 1; both maximum-size Root and Child are cooled before their descendant call. This remains Foundry cold simulation, not paid separate-transaction evidence.

Evidence fixtures use real Alice executeSigned and Bob Actor.execute. Tags bind to existing F. Historical queries compare sealed frontier results with H_FOUND=2. Runtime mandatory hashes derive from actual deployed rule instances; no hardcoded hash guesses. Stage 2 will add exact-profile constructor pinning, replacement index and Lens together, and parent family declaration.

Concerns: no compilation claim until root returns evidence. Tests exercise a disposable profile only; do not imply full Files journey, production design adoption, generic raw-layout ABI, or portable native proof. Shared planning status publication is root-owned under scope split.

## Stage 1: observed RED, Child GREENREADY

Root reported actual `files-stage1-red`: solc 0.8.30 compiled successfully in 6.22 seconds; Root shape/existence test passed; all three positive Child/control paths failed exact `E_REJECTED(0, 0xd89fed021cf250e71ba5d4d225acf1fc20baca34ccf2ad1374c39dc6e9c72d4f)`. Root evidence: `/tmp/efs-b-archive-task1.OXPOfb/files-stage1-red.json` and `.log`; root source pin prefix `b45f055b`; owned process stopped and slot released. This is reported root evidence, not a worker run.

After that RED, replaced only the false Child method: minimum header, one exact checked parent, nonzero existing Subject, bounded parent metadata, Root word 0 / same incoming Child word 1, correct minimum length and admitted-parent guard. No entire parent-body getter. All four executable tests remain byte-identical to RED.

GREENREADY pins: Profile SHA256 `83356d17b987f2d3197d6775a847a1079fd49a01020d00c746c4256257b9dc22`; test unchanged `cd6900c520143c8ca1e62ad364cb705157f7b4d22a1ee3a59616fe3e29914045`. No index implemented or new assertions added. Await root's four-test GREEN gate.

Root's constructor ruling accepted for next stage: expected mandatory runtime codehashes are explicit constructor parameters independently pinned by the trusted fixture from actual reviewed Root/Child deployments, never inferred solely from the untrusted registry and never guessed constants. Constructor will check descriptors, exact shapes/vectors, runtime hashes, and Child Root configuration. This configured hash pair is an explicit trust boundary, not automatic semantics discovery; no duplicate rule deployments merely to obtain expected hashes.

## Stage 1: observed GREEN; Stage 2: REDREADY

Root reported `files-stage1-green.json`/`.log`: all four FilesJoinedTest cases passed, successful solc 0.8.30 compilation, source `1a5bdb2bb3c380d35ac646d754429284a8bccd4498b5189853085d51f8c5ac92`; cleanup/slot release true at 10:35:24 UTC. Test source stayed identical to stage 1 RED. Worker ran no heavy tooling.

Stage 2 now contains no-append FilesParentIndex (only calls inherited `super.onAdmission`). Its constructor validates exact Root/Child descriptors, shapes, ref vectors, independently configured rule hashes, deployed mandatory rule code and Child's immutable Root Type. Fixture expected hashes are derived from its reviewed deployed rule instances. No duplicate reference deployment. The inherited fixture `index` and a newly deployed Lens both refer to the new module before admission 1.

Added four tests, retaining the original four test bodies unchanged:

- `test_revision_acceptance_history_and_parent_backlinks`: original actual revision/history journey then exact R0->{RA,RB}, RA->{RR} parent sets. Counts/list exhaustion and first-admission resolution are checked, not head history as a substitute. PUBLISH admission rows retain body hash, so the test reconstructs Record identity using the admitted Type and body hash.
- `test_reuse_does_not_duplicate_parent_membership`: genuine REUSE and repeated PUBLISH create two more occurrences but must not grow retained parent set; inherited by-Type still grows.
- `test_required_parent_callback_failure_rolls_back`: immutable failure subclass runs full `super` before E_FORCED_CHILD. Root setup succeeds on a fresh correctly wired Ledger. Failed signed Child+HEAD batch checks exact E_INDEX wrapping, absent candidate, nonce/four counts/current head and tested inherited/parent posting heads and words plus progress counters. After append implementation the same unchanged test will exercise rollback after both halves wrote.
- `test_index_constructor_pins_exact_reviewed_profile`: real operational control, then zero/wrong hash, wrong Root shape, no Root rule, wrong Child shape/vector and wrong immutable Child Root configuration controls. These catch trusting registry labels/size/config instead of the configured reviewed profile.

Stage 2 pins: Profile SHA256 `6ad3e41d8243152cd54cf78be4f1e6c5f2e967e57f914962b493eebde2b24b28`; test `1043bddc8293fa0b0f5205e1a42ed17e5d7edc55bb8a5abfd715d0ff16ce2c13`. Focus RED is `test_revision_acceptance_history_and_parent_backlinks`, expected failure `exact parent backlink count`. Compilation remains unverified by worker; wait for root. `git diff --check` exited zero (untracked source files are not compilation or full diff verification).

Consumer-facing Task 1 interface: `FilesParentIndex(address ledger, bytes32 rootType, bytes32 childType, bytes32 expectedRootRuleHash, bytes32 expectedChildRuleHash)`; public immutable fields `rootType`, `childType`, `expectedRootRuleHash`, `expectedChildRuleHash`; inherited index API plus `FAMILY_FILES_PARENT()`. Fixture state/helpers named in the brief are internal and available to a derived Task 2 test. Generic coverage remains explicitly family-wide, not per-parent independently maintained coverage.

## Stage 2: observed RED; parent append GREENREADY

Root reported successful compilation and actual behavioral RED: eight tests, six passed, two failed with exact `exact parent backlink count` (backlink and reuse tests). Evidence `/tmp/efs-b-archive-task1.OXPOfb/files-stage2-red.json`/`.log`; root source `eb5ab5228e5eb128cde7b393fc2ea16ddf256f1bb152ed5ace74f421de811d35`; cleanup stop and slot release at 10:39:25 UTC. Constructor pinning and failure-after-super controls passed in that gate.

Only `FilesParentIndex.onAdmission` changed after that RED. After inherited maintenance, it filters exact Child PUBLISH/REUSE effects; reads bounded Record metadata; rejects wrong Type, short header or invalid first admission; skips non-first occurrences; reads only parent word 0; and appends first admission to `Keys.referenceList(childType,0,parent)` as retained audit membership. All eight test bodies remain byte-identical to the stage 2 RED. Masked first-admission extraction stays in FilesLayout.header.

GREENREADY pins: Profile SHA256 `c701bf700c122d0c1fd0c3f6b51630c3c0b9bdb6902e0975b8b6a3095cf43cdf`; test unchanged `1043bddc8293fa0b0f5205e1a42ed17e5d7edc55bb8a5abfd715d0ff16ce2c13`; Ledger unchanged `7576874b52a81ebc0f7b64640332b345096e0c09000ed4f09811bdc21dd6c3d5`. Root owns full-suite GREEN and size output. No worker heavy tools or broader edits.

Self-review: fresh first-admission append distinguishes retained members from occurrences; repeated PUBLISH/REUSE skips duplicate membership while inherited indexes still count occurrences. Required callback fault now runs after both index halves mutate, so its unchanged exact-error rollback test exercises the joined atomicity claim. The constructor hash parameters and test-only raw-layout coupling remain declared boundaries. No production/freeze/native-source-proof claim.

## Root completion addendum — September 14, 10:53 UTC

Root independently observed `files-task1-green.json`/`.log`: 110/110 full-suite PASS, including all eight Files tests, frozen source `c6967af16364a89e36559ede2d5fefb5f407b379debdcfba98a033d2a377e503`, with identical executable assertions to stage 2 RED. `files-task1-size.json`/`.log` used that same source and passed. Runtime/init sizes: Root 513/539; Child 1,284/1,402; FilesParentIndex 5,287/8,724; unchanged Ledger 17,280/17,670. Test-only orchestration harness initcode is 92,265; it is not a production deployment candidate. All owned processes stopped and the slot released at 10:47:47 UTC.

Root committed exactly the two task sources as `9fdee5e8976815a07d28097087d4ac2105a969ec`. Independent task review `/tmp/efs-b-files-joined-task1-review-20260914.md` is spec compliant and Approved, no Critical/Important issues. Minor test-harness warning and intentional masked-cast lint are disclosed and deferred rather than changing the measured source just for output hygiene. Current-basis consumer obligations belong to Task 2, now assigned to a fresh worker. Task 1 DONE_WITH_CONCERNS only for those documented prototype limits, not an unresolved correctness blocker.
