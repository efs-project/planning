# Joined FileRevision experiment implementation plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development. Root owns compilation, measurement, review and exact-path publication. This executes James's existing overnight disposable-prototype mandate, not a production API decision.

**Goal:** demonstrate real checked file parentage and head-first revision tags on compact B's existing kernel.

**Architecture:** Root and Child revision Types carry arbitrary document bytes and a stable File Subject. Mandatory rules enforce same-File parents through bounded reads. A separate required index retains exact parent backlinks; an unrelated consumer composes current Lens selection with explicitly qualified tag reads.

**Tech Stack:** Solidity 0.8.30, viaIR, optimizer 200, Cancun; installed Forge, no new dependencies. Existing isolated `planning-warroom-b-run`, lab path `Reviews/2026-09-12-efs-path-decision/lab-b/`.

**Spec:** [[files-next-joined-gate-20260914]] and [[files-journey]]. This plan implements only the real parentage/selection slice, not the entire Files journey. Source-only preflight found the existing APIs sufficient with the explicit qualifications below.

## Global constraints

- Disposable test profile only. No Ledger, Keys, Registry, IndexModule, LensReader, LabBase, archive, existing diagnostic, SDK, production repository, migration or protocol change.
- Existing Ledger SHA256 `7576874b52a81ebc0f7b64640332b345096e0c09000ed4f09811bdc21dd6c3d5`; body maximum 8,192 bytes and mandatory-rule gas 300,000 remain unchanged.
- Root body = File ID word 0 plus arbitrary bytes; Child = parent Record ID word 0, File ID word 1, arbitrary bytes. Root minimum 32, Child minimum 64. Both File IDs must be nonzero, existing Subjects. Child descriptor has exactly one checked reference `[bytes32(0)]`; the mandatory rule narrows parent Type to pinned Root or the incoming Child Type, and enforces same File.
- Storage-layout helper is test-only and coupled to the pinned Ledger: record mapping slot 2, meta at base+1; body-word mapping slot 3. `first = uint64(meta & ((uint256(1)<<48)-1))`; `length = uint32(meta >> 48)`. Never infer length from unmasked meta or read the entire parent to validate its header.
- Alice is `eoaA`/PK_A through genuine `executeSigned`; Bob is `address(bob)` through genuine `Actor.execute`. No forged contract signature or helper that substitutes its own authorship. Historical native source proof remains unsupported.
- Exact root/child shapes, descriptors, rule codehashes and Child's configured Root Type must be checked by the Files profile. A length check is not proof of a profile. Callbacks remain mandatory and atomic; retained membership is not current validity.
- COMPLETE parent-family coverage means the exact pinned module's declared family is gap-free, from admission 1 through the current basis, plus exhaustion of a parent's count-bounded list. Generic `coverage` ignores its scope argument; never claim independently maintained per-parent coverage.
- All point/tag/folder composition occurs at current state in one EVM call with supplied frontier, rule epoch, index generation and Core commitment checked. PARTIAL, UNKNOWN, stale basis and conflict do not become empty success.
- Root one-heavy-slot only, finite watchdog, installed/pinned toolchain, private caches; 50 GiB free reserve and 15 GiB aggregate scratch. No worker compiler, Anvil, RPC or subagent launch. Stop before September 14 14:00 UTC / 09:00 Chicago.
- Implementation tasks hand a compiling stub plus unchanged executable assertions to root for real behavioral RED before implementation. Compilation errors are not RED. Task3 characterizes already-existing behavior: a first-pass success is legitimate evidence, with the specified actual negative/positive control, not a reason to break working Core. Root commits only exact task files after GREEN and reviews; designs/reports stay on main. Previously passing measurements are not repeated without a source/semantic reason.

## File responsibilities and shared fixture

`test/FilesJoinedProfile.sol`: pinned raw header helper, mandatory Root/Child acceptors and exact Files-parent index. `test/FilesJoined.t.sol`: integration fixture and assertions, extending existing LabBase. Task 2 adds `test/FilesJoinedConsumer.sol` for unrelated qualified reads. Three files keep acceptance/indexing, test orchestration and consuming behavior separate.

Fixture: `R0=Root(F,"Meeting at 10:00.\n")`; `RA=Child(R0,F,"Meeting at 11:00.\n")`; `RB=Child(R0,F,"Meeting at 09:00.\n")`; `RR=Child(RA,F,"Meeting at 10:00.\n")`. Derive exact IDs with `Keys.recordFromHash(typeId,keccak256(fullBody))`. RR differs from R0 despite equal document bytes.


## Root handoff and operating contract

Task2 code at d54a1208b3e014f0eede9697992ce12e3620b638 has 118/118 full GREEN and normal size output. Worker dispatch waits for its independent approval; ask root if no verdict accompanies dispatch. Frozen consumer SHA256 faf1e68e5dc92d56da6d39a7893ec0f7d4b06f13e04678ee04a62655c803005d; existing test SHA256 b6ec66994aae4d577ec8ba2997e70b345c609127ea52cf07a0b758540b7319d5; profile c701bf700c122d0c1fd0c3f6b51630c3c0b9bdb6902e0975b8b6a3095cf43cdf; Core unchanged as above. The exact point reader intentionally does not require reverse-parent enumeration completeness; do not reintroduce that restriction.

Own ONLY additive tests/helpers in FilesJoined.t.sol and assigned task-3-report.md. No git mutations/commit/push, compiler/Forge/solc/Anvil/RPC, installs or subagents. Root runs frozen gates. No implementation changes to consumer/profile/index/Ledger/Lens/other tests. Read actual APIs and existing fixtures; do not invent a helper/counter signature. This is an existing-behavior integration characterization: produce genuine executable assertions and report TESTREADY; a first-pass result is valid, not a fabricated TDD RED. The expected stale-CAS failure must be paired with the valid expected2 control and precise tested rollback state. Do not start optional churn until root observes core lifecycle pass; hand core test first.

Existing File fixture batches seed tags for semantic testing. Never present that as separately priced user actions. Test gas is not receipt gas. Hashed name constants do not recover original names. This single joined micro-case does not imply full cold browser, historical paging or native portable proof.

### Task 3: Real Files move, reused path, whiteout and restore micro-case

**Files:** additive tests/helpers in `test/FilesJoined.t.sol` only. Start after
Task 2 is GREEN, independently accepted and committed; retain exact consumer,
profile and Core hashes. No implementation-source or existing-test changes.
This bounded extension comes from the existing Data Explorer J3–J5 fixture and
independent source-only lifecycle analysis, not a new architecture.

**Test:** `test_real_files_move_reuse_whiteout_restore`. Reuse the actual
`_createRoot`, `_publishBranches`, body/signing/Record/parent helpers and Task2
consumer. Define the second folder's local fixture identifier `PUBLISHED`;
name roles continue to be hashes, not secretly recovered filename text. Use
fresh current Basis at each checkpoint and no intervening graph writes among
reads at that checkpoint.

- [ ] Seed Root and RA/RB branches, but not RR yet. Alice HEAD(F) is revision2;
  Bob HEAD(F) revision1. Alice `/drafts/note.txt` is F at placement revision1.
- [ ] Rename as one signed action vector: UNBIND drafts/note expected1, BIND
  drafts/brief to F expected0. Move as a separate vector: UNBIND drafts/brief
  expected1, BIND published/brief to F expected0. Add Bob's lower-priority
  published/brief placement through genuine `bob.execute`, expected0. Exact
  File/revision identities and HEAD values must remain unchanged.
- [ ] Reuse the old note path with a real new File G and Root RG. The four
  actions are CREATE G, PUBLISH Root(G,"Replacement file.\n"), BIND HEAD(G)
  expected0, BIND drafts/note to G **expected2**. First submit the same shape
  with incorrect placement expected0 and require exact E_CAS(expected0,
  actual2), absent G/RG and unchanged tested nonce/count/head/posting state;
  then prove expected2 succeeds. Tombstones do not reset revision counters.
- [ ] At post-reuse basis, complete current listings with scan budget2 give
  exactly G in drafts and one F in published. No ghost drafts/brief or duplicate
  F. Verify complete/exhausted/full-context windows, direct path selection and
  exact decoded File/Revision data, not just array lengths. File `project_efs`
  matches published F under both Lenses and never G. Selected `approved`
  matches published F@RA under Alice-first only, never G or Bob's RB.
- [ ] Whiteout Alice published/brief with UNBIND expected1. Alice-first path
  is MASKED and complete plain/File-tag/revision-tag folder results omit F;
  Bob-first still sees F@RB and the File tag, without approved. Direct F remains
  readable with RA/RB and its evidence. This tests namespace masking separately
  from exact-File presence and tag assertions.
- [ ] Restore as one THREE-action signed vector: PUBLISH RR(parent RA,F,old
  10:00 document), BIND HEAD(F) expected2, BIND published/brief expected2.
  Do not use a helper that creates RR in a separate publication and pretend
  restore was atomic. Alice HEAD and placement become revision3; Bob's RB
  remains. File project tag survives; neither draft(R0) nor approved(RA)
  transfers to RR despite equal old document bytes. RR differs from R0, with
  equal document digest but different full Root/Child bodies. Verify exact
  retained R0->{RA,RB} and RA->{RR} memberships; G remains unrelated.
- [ ] Save sealed admission frontiers and query `historyByRole` as one as-of
  state each: note F/1 -> mask/2 -> G/3; drafts brief F/1 -> mask/2;
  published brief F/1 -> mask/2 -> F/3. H_FOUND carries live/target/revision;
  it is not a history array. Raw current heads/Records supplement the consumer
  but do not constitute a full independent raw-state oracle.
- [ ] Before G creation, the two retained draft names are masked. A raw
  budget1 page must be empty **and PARTIAL/non-final**; its same-state
  continuation ends COMPLETE empty. The one-window consumer must reject
  budget1. After G, budget1 may contain G but still be incomplete—do not
  falsify posting order to demand an empty first page. Full budget2 yields G.
- [ ] Only if the lifecycle passes with time remaining, a separate tiny-churn
  test adds then masks two fresh temporary names for F, retaining live set G.
  Budget2 becomes incomplete; budget4 exhausts four lifetime names and finds
  exactly G. Vary distinct lifetime names, not merely updates to one name.

**Verification and stop rule:** this is a new characterization of existing
behavior, so a first-pass test is valid new evidence; do not fabricate a RED by
breaking production code. The stale-CAS negative has a real successful control.
Root runs one focused frozen gate, then whole-suite/size checks for the final
source, under its existing finite resource protocol. On mismatch, retain the
counterexample and permit one scoped repair only if it preserves the specified
semantics within the morning window. Do not launch scale, browser or new
pagination implementation to turn this into a broader project. Stop before
September14 14:00 UTC.

## Completion and exclusions

Tasks 1/2 earn local checked revision chains, retained parent discovery,
signed/native authorship separation, competing current selection, explicit tag
tiers and one exhausted folder window. If Task 3 passes, it additionally earns
the named small real-Files rename/move/reused-path/whiteout/restore composition
and bounded same-state churn behavior. No task earns global tag discovery,
arbitrary churn/scale, cross-transaction historical pagination, native portable
proof, cold filename reconstruction, a working browser or production readiness.
Those broader journey gates stay open. Hashed-name lookup and fixture strings
are not cold reconstruction; locally observed contract authorship is not
portable historical source proof. Future pricing must keep the journey's
logical action boundaries, rather than relabel seeded batches as separately
priced tag actions.
