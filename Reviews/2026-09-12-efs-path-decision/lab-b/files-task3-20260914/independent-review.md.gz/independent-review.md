# Independent review — joined Files Task 3

Date: 2026-09-14. Reviewer: files_paid_runner, separately assigned to review the
lifecycle worker's change. I implemented the separate paid instrument, not these
lifecycle/churn tests. This review does **not** review or approve my paid files.

**SpecCompliant: yes. Quality: Approved.**

Critical: none. Important: none. Minor actionable findings: none.

## Reviewed scope and evidence

Read the complete approved joined implementation plan, Task3 brief/report and
the supplied `review-8cd4b82..c85e5ba.diff`. The package is one commit,
`c85e5ba`, adding366 lines to `test/FilesJoined.t.sol`; no implementation changes.
Read relevant existing fixture, raw-head/posting helpers, Ledger, Lens and
qualified-consumer APIs. The final reviewed file SHA256 is
`65d4dc7514cc026d7879aec158fd562953b63135161730af0290f3d25be00b18`.

Independent filesystem-only comparison removed exactly the contiguous Task3
block and compared all remaining bytes with the retained Task2 source snapshot.
They are identical: all15 original tests/helpers/text preserved;17 tests now.
Current consumer/profile/Ledger hashes match their unchanged reviewed pins:

- Consumer `faf1e68e5dc92d56da6d39a7893ec0f7d4b06f13e04678ee04a62655c803005d`
- Profile `c701bf700c122d0c1fd0c3f6b51630c3c0b9bdb6902e0975b8b6a3095cf43cdf`
- Ledger `7576874b52a81ebc0f7b64640332b345096e0c09000ed4f09811bdc21dd6c3d5`

Inspected actual retained root reports/logs, not just the worker's success text:

- `files-task3-lifecycle`: successful compile and1/1 focused pass at whole input
  `091f2473afc1d6190c93e5df099d60acf02625a5a7402d937aea649dddebfbaa`.
- `files-task3-full`: compiler rejects reserved local identifier `partial`;
  this is explicitly not a behavioral RED. Direct comparison with the corrected
  snapshot shows only that local variable/references renamed to `partialPage`.
- `files-task3-full-fixed`: retained log reports120/120, all17 Files tests
  included, at input
  `cf0e22d1ef77cd02446f4f1662df3d9b98d2d2a1f05a808c6e77d30cc939c8bb`.
- `files-task3-size`: same input, exit0, normal reader/index/Ledger runtime
  15,896/5,287/17,280 bytes; oversized orchestration belongs to the test harness.

All these root reports record owned processes stopped and slot released. I ran
no Forge, compiler, Anvil, RPC, Git, installs or subagents. This is review of
retained root execution evidence, not a claim of an additional independent run.

## Why the tests are meaningful

1. **Actual namespace mutations.** Rename and move are separate signed action
   vectors with literal expected revisions. A genuine Bob Actor adds the second
   placement. Exact original revision bytes and both complete HEAD tuples are
   compared before/after, so changing placement cannot silently rewrite content.

2. **A real stale-CAS negative and successful control.** The four-action G/RG
   vector attempts expected0 against the retained note tombstone at revision2.
   It requires the entire encoded E_CAS key/expected/actual error, then checks G
   absent, RG metadata/body absent, and the named state subset unchanged. The
   same vector with only placement expectation changed to2 succeeds and yields
   actual G/RG and placement revision3. This catches reset-on-tombstone semantics;
   the test does not get its result from a fake or self-written expected state.

3. **Accurately bounded rollback assertions.** The snapshot covers both nonces,
   four counts, processing markers, the listed F/G/path HEAD tuples, Root/Child
   by-Type and Alice by-author postings, relevant scopes/history, and R0/RA
   parent postings. `_postingDigest` includes head fields and packed words through
   the first exhausted word. It does not check every Core/index storage cell,
   and the report correctly makes only a tested-subset claim.

4. **Whiteout is distinct from exact-file existence.** At each write-free
   checkpoint, both Lens orders test exact hashed paths, complete plain listings,
   separately decoded G/RG and F/revision bytes, File tags and selected-revision
   tags. Alice-first masks published F after UNBIND rather than falling through;
   Bob-first retains F@RB and project(F), without approved(RA). Direct F reads
   remain valid and retained evidence is checked as local signed/native evidence.

5. **Restore is actually atomic in this fixture.** One literal three-action
   executeSigned publishes RR and CAS-updates both HEAD and placement. It does
   not call the prior two-action grandchild helper and relabel a later placement
   write as one restore. Exact documents, full bodies, distinct RR/R0 IDs,
   revision3 heads, unchanged Bob HEAD, File-tag persistence and no transferred
   draft/approval are checked. Exact exhausted parent membership sets remain
   separate from current HEAD history; G's Root is unrelated.

6. **History is a qualified as-of read.** Saved frontiers drive eight expected
   H_FOUND single-state results with live/target/revision and nonzero bounded
   admission. The tests do not misrepresent the API as an emitted history array.

7. **Completeness is not array length.** Before G, budget1 yields empty PARTIAL
   followed by a same-state COMPLETE empty continuation. After G, the test allows
   a partial page to contain G while still refusing finality. The one-window
   consumer rejects incomplete budgets. Full-window assertions separately check
   status, scans, raw totals, selected totals, complete context and exhaustion.

8. **The churn control varies distinct lifetime names.** It proves two temporary
   roles are initially absent and distinct, binds each then masks each, checks
   retained scope count2→4, and requires budget2 PARTIAL versus budget4 COMPLETE.
   The pre-churn single G placement is independently identified before later
   array equality checks; those equality checks therefore prove unchanged
   identity/provenance, not a tautological round trip. Both File HEADs and G's
   decoded point remain unchanged, and the complete tag filter returns no hits.

## Limits and handoff

Approval is for this small real-Files semantic characterization, not a scaling,
economics or production-readiness verdict. Four lifetime names expose retained-
name scan behavior; they do not prove its long-term acceptability. The fixture
still uses hashed folder/name coordinates and seeded semantic tag batches.
There is no cold filename recovery, nested-directory validation, browser,
cross-transaction historical pagination, global tag discovery, authenticated
raw-state oracle or portable native-source proof in this change. These remain
explicitly excluded in the plan/report and should stay excluded in summaries.

No source repair or additional heavy rerun is requested for this Task3 review.
