# Task 3 report: TESTREADY

## Root-observed final verification, 11:32 UTC

Main lifecycle first-pass characterization succeeded before optional churn.
Optional churn's first compiler attempt rejected reserved local identifier
`partial`; that is a compile failure, not behavioral RED. Worker renamed only
that variable/references to `partialPage`. Final test SHA256 is
`65d4dc7514cc026d7879aec158fd562953b63135161730af0290f3d25be00b18`.

Root then ran full suite **120/120, including all 17 Files tests**, and normal
sizes at identical whole input
`cf0e22d1ef77cd02446f4f1662df3d9b98d2d2a1f05a808c6e77d30cc939c8bb`.
Reports/logs: `files-task3-full-fixed` and `files-task3-size` under the existing
owned run root. Both exit0, no failures, owned processes stopped and slot freed.
Normal reader/index/Ledger runtime remains 15,896/5,287/17,280 bytes. Only the
test orchestrator exceeds deployment limits. Candidate sources are unchanged.
Independent Task3 review is pending; prior TESTREADY paragraphs below are the
preserved source-only handoff chronology, not the latest execution status.

Date: 2026-09-14. Worker: files_joined_lifecycle. Base: `d54a1208b3e014f0eede9697992ce12e3620b638`.

## Initial lifecycle handoff status and exact scope

TESTREADY, source-only. Root supplied Task 2 independent approval at dispatch. No compiler, Forge, solc, Anvil, RPC, install, git mutation, commit, push, or subagent was run. Compilation and all behavioral/whole-suite/normal-size verification remain root-owned and unobserved by this worker. First-pass success is legitimate characterization evidence, not a fabricated RED.

Only the additive Task 3 block in `Reviews/2026-09-12-efs-path-decision/lab-b/test/FilesJoined.t.sol` and this assigned report were written. No optional churn test was added. Root owns the write-session status bookkeeping outside this two-file worker ownership split.

## Implemented executable case

`test_real_files_move_reuse_whiteout_restore` reuses the actual Root/branch fixtures, signing, Record assertions, parent helpers and Task 2 consumer. The inherited `LabBase.PUBLISHED = keccak256("/published")` already exists; using it avoids a shadowing/redeclaration or forbidden LabBase edit. Names remain local role hashes.

- Alice signed rename and separate signed move use exact expected1/expected0 vectors. Bob supplies his lower-priority published placement using genuine Actor execution. Both full raw HEAD tuples and all original revision bytes are compared before/after these placement operations.
- Before G, the two masked lifetime draft names produce empty PARTIAL budget1 and same-state COMPLETE empty continuation. The one-window consumer rejects budget1 with E_INCOMPLETE.
- G and RG are real CREATE/Root publication, followed by HEAD(G) and the reused note binding. Incorrect placement expected0 requires the exact encoded E_CAS key, expected0, actual2. The unchanged four-action shape with only placement expectedRevision changed to2 is then genuinely executed and checked to yield placement revision3.
- The negative snapshots Alice nonce plus Bob nonce, all four Ledger counts, index processing markers, full relevant F/G/placement head tuples, Root/Child by-Type and Alice by-author postings, G-head and note-path history, G-head/drafts scopes, and R0/RA parent postings. Posting heads and packed body words are included. Failed G Subject and RG Record metadata/body are explicitly absent. This is a precise tested subset, not a claim that every storage slot was independently audited.
- Post-reuse budget1 is required to remain PARTIAL without demanding an empty page or changing retained posting order. Any item must be G's exact note placement; budget2 proves the complete set.
- Post-reuse, whiteout and restore each use one fresh Basis and write-free checkpoints across both ordered Lenses. Plain listings verify two scanned candidates, rawTotal2, exact live set, exhaustion, cursor context, selected totals and selected placement provenance. Direct hashed paths, decoded F/Revision and G/RG bytes, File tags and selected-revision tags are checked separately.
- Whiteout masks Alice-first published F without deleting exact F or its RA/RB and retained signed/native evidence. Bob-first retains one F@RB and the File project tag, never RA's approved tag.
- Restore is literally one signed three-action vector: PUBLISH RR, BIND HEAD(F) expected2, BIND published/brief expected2. It advances three admissions, Alice HEAD and placement to3, and leaves Bob HEAD at1. Original Root/branch bodies remain exact; RR differs from R0 and their full bodies differ while both document fixtures are exactly the old 10:00 bytes. RR receives neither draft(R0) nor approved(RA); project(F) survives.
- Exact exhausted retained R0->{RA,RB} and RA->{RR} lists are asserted with the existing gap-free family-qualified helper. RG has no Child memberships.
- Saved admission frontiers drive eight H_FOUND single-state history assertions: note F/1 -> mask/2 -> G/3; drafts brief F/1 -> mask/2; published brief F/1 -> mask/2 -> F/3.

## Source-only verification and preservation

`git diff --check` returned success. The tracked diff is exactly 296 additions and zero deletions in FilesJoined.t.sol; no implementation source diff exists.

A Ruby read-only preservation check read the base via `git show`, removed only the new contiguous block from the current text, and compared every remaining byte to the original. Result: exact equality; original 15 public tests retained; current total16. Reconstructed original SHA256 is `b6ec66994aae4d577ec8ba2997e70b345c609127ea52cf07a0b758540b7319d5`. Existing helpers and all non-test text outside the additive block are also unchanged.

Initial lifecycle handoff source SHA256 (superseded by the additive churn handoff below):

- FilesJoined.t.sol: `4a9c6fe99e4a7ed23d4a6ca50d75536ba2457cf352bc829f77473217e377e888`
- FilesJoinedConsumer.sol unchanged: `faf1e68e5dc92d56da6d39a7893ec0f7d4b06f13e04678ee04a62655c803005d`
- FilesJoinedProfile.sol unchanged: `c701bf700c122d0c1fd0c3f6b51630c3c0b9bdb6902e0975b8b6a3095cf43cdf`
- Ledger.sol unchanged: `7576874b52a81ebc0f7b64640332b345096e0c09000ed4f09811bdc21dd6c3d5`

## Self-review and handoff concerns

Reviewed actual Ledger signatures, counter semantics, Head tuple, E_CAS ordering, Lens listing/history behavior and consumer Basis/tag interfaces. Assertions would catch tombstone counter reset; failure rollback leakage in the enumerated subset; namespace whiteout fall-through; ghost/duplicate F placements; RG returning F's old content; revision tags inherited across distinct revisions; and an incomplete page misreported as final. No mock substitutes for the lifecycle's real mutations or reads.

No source-level semantic mismatch found. This is not a compilation or pass claim: root must run its one focused frozen gate and subsequent whole-suite/normal-size checks. The new test is a bounded, multi-stage existing-behavior integration characterization, with helper factoring confined to its additive block. Optional two-name churn remains gated on root-observed main lifecycle PASS and remaining time.

No paid-gas, receipt-gas, cold-browser/name recovery, historical paging, global tag discovery, scale, full independent raw-state oracle, portable native proof, or production-readiness claim is made. Seeded tag batches are not separately priced logical user actions.

## Optional bounded churn handoff: TESTREADY

Root subsequently ran the main lifecycle frozen gate and explicitly authorized this optional extension after PASS. I read its retained JSON and log: aggregate source digest `091f2473afc1d6190c93e5df099d60acf02625a5a7402d937aea649dddebfbaa`, FilesJoined.t.sol SHA256 `4a9c6fe99e4a7ed23d4a6ca50d75536ba2457cf352bc829f77473217e377e888`, exit0, 1 passed/0 failed, owned processes stopped and slot released. This is root's actual run, not a worker-run or an optional-test pass. The artifacts are `/tmp/efs-b-archive-task1.OXPOfb/files-task3-lifecycle.json` and the adjacent `.log`.

Added only the separate `test_real_files_two_name_churn_requires_four_scans`, 70 lines. It creates real F and G with the existing signed helpers, establishes the two retained draft names and exact sole live G placement, adds two distinct fresh hashed names for F with genuine signed BIND expected0, then masks both with genuine signed UNBIND expected1. Each temporary name is observed absent/0 -> F/1 -> mask/2.

The raw scope count is checked at2 before churn and4 after. A fresh post-churn Basis is shared by all post-churn reads. Budget2 retains the same exact G placement but must return PARTIAL, scanned2/rawTotal4 and a non-final cursor; the one-window consumer must reject that budget. Budget4 must return COMPLETE, scanned4/rawTotal4, full cursor context/exhaustion, and exactly the pre-churn G placement including unchanged provenance. Both File HEAD tuples and G's decoded point remain unchanged. Complete budget4 tag composition correctly yields no project-tag matches: F is masked in this folder and G is untagged. No broader scale or historical pagination work was added.

Self-review: the control catches accidentally budgeting by live names, dropping retained masked positions, leaking F through its two masked new names, returning a false COMPLETE at budget2, or mutating G while merely changing F's temporary placements. It varies two new names, not two updates to an existing name. The pre-churn raw live set is independently asserted with exact G identity and note role before the entry-array equality check. All mutations are genuine signed execution; there are no mocks or production-source edits.

Source-only verification: `git diff --check` succeeds. Total Task 3 diff versus the implementation base is366 additions/0 deletions. A read-only Ruby comparison removed only the optional contiguous block and compared the remainder to the root's frozen lifecycle snapshot: byte-for-byte equality, all16 prior tests and all helper/text bytes preserved, now17 tests. Reconstructed previous-file SHA256 remains `4a9c6fe99e4a7ed23d4a6ca50d75536ba2457cf352bc829f77473217e377e888`.

Current TESTREADY source SHA256: `704fd7336ac9bfa2be52fa9d2d048120cb2a096331de7a3f30de5896126c641b`. Consumer/profile/Ledger pins above remain unchanged. The worker again ran no compiler, Forge, solc, Anvil, RPC, install, git mutation or subagent. Optional test compilation and execution remain unverified and root-owned. No paid-workflow lane was read or modified.
