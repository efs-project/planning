// Node-only integration harness. Copies the gate to an owned fixture and replaces
// spawn at the import boundary; no path through these tests can execute Forge.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as fs from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const base = dirname(fileURLToPath(import.meta.url));
const node = '/opt/homebrew/Cellar/node/26.0.0/bin/node';
const realLab = '/Users/james/Code/EFS/planning-warroom-b-run/Reviews/2026-09-12-efs-path-decision/lab-b';
const fixture = await fs.mkdtemp('/tmp/efs-archive-gate-tests-');
const lab = `${fixture}/lab`;
await fs.mkdir(`${lab}/src`, { recursive:true });
await fs.mkdir(`${lab}/test`);
await fs.mkdir(`${lab}/script`);
await fs.writeFile(`${lab}/src/A.sol`, 'pragma solidity ^0.8.30; contract A {}\n');
await fs.copyFile(`${realLab}/foundry.toml`, `${lab}/foundry.toml`);
const original = await fs.readFile(`${base}/forge-gate.mjs`, 'utf8');
const safe = original.replaceAll('/tmp/efs-b-archive-task1.OXPOfb', fixture).replaceAll(base, fixture).replaceAll(realLab, lab)
  .replaceAll('/tmp/efs-b-archive-heavy-slot.lock', `${fixture}/slot.lock`)
  .replace(/import \{[^\n]+\} from 'node:child_process';/, "import { spawn, execFileSync } from './safe-spawn.mjs';");
await fs.writeFile(`${fixture}/gate.mjs`, safe);
await fs.writeFile(`${fixture}/safe-spawn.mjs`, `
import {spawn as nodeSpawn} from 'node:child_process';
export const execFileSync = () => {throw new Error('sync child forbidden')};
export function spawn(command, args, opts) {
  if (command === '/bin/ps') {
    return nodeSpawn(${JSON.stringify(node)}, ['-e', process.env.TEST_PS_HANG ? 'setInterval(()=>{},1000)' : ''], opts);
  }
  if (command !== '/Users/james/.foundry/bin/forge') throw new Error('unexpected child '+command);
  return nodeSpawn(${JSON.stringify(node)}, ['-e', "require('fs').writeFileSync('"+${JSON.stringify(fixture)}+"/child-started',String(process.pid)); process.on('SIGTERM',()=>{}); setInterval(()=>{},1000)"], opts);
}
`);
let seq = 0;
function launch(mode, env = {}) {
  const label = `case-${++seq}`;
  const child = spawn(node, [`${fixture}/gate.mjs`, label, mode], { env:{...process.env,
    EFS_ARCHIVE_LEASE_START:new Date(Date.now()-1000).toISOString(),
    EFS_ARCHIVE_LEASE_END:new Date(Date.now()+60_000).toISOString(), ...env }, stdio:['ignore','pipe','pipe'] });
  let output = '';
  child.stdout.on('data', x => output += x);
  child.stderr.on('data', x => output += x);
  const done = new Promise(resolve => child.on('close', (code, signal) => resolve({code,signal,output})));
  return {child, done, label};
}
async function result(p) { const exit = await p.done; return {...exit, report:JSON.parse(await fs.readFile(`${fixture}/${p.label}.json`,'utf8'))}; }
async function until(fn) { const end = Date.now()+15000; while(Date.now()<end) { if(await fn()) return; await new Promise(r=>setTimeout(r,20)); } throw new Error('condition timed out'); }
const exists = p => fs.access(p).then(()=>true,()=>false);
test('pin is no-child and records a full digest', async () => {
  const p = launch('pin'); const exit = await p.done;
  assert.equal(exit.code,0,exit.output);
  const report = JSON.parse(await fs.readFile(`${fixture}/${p.label}.json`,'utf8'));
  assert.match(report.sourceDigest,/^[a-f0-9]{64}$/);
  assert.equal(await exists(`${fixture}/child-started`),false);
  assert.equal(await exists(`${fixture}/slot.lock`),false);
});
export {fixture,launch,result,until,exists,lab};
test('occupied atomic slot refuses without stealing it', async () => {
  await fs.writeFile(`${fixture}/slot.lock`,'other-owner',{flag:'wx'});
  const r = await result(launch('pin'));
  assert.equal(r.code,1);
  assert.match(r.report.failure,/EEXIST/);
  assert.equal(await fs.readFile(`${fixture}/slot.lock`,'utf8'),'other-owner');
  await fs.unlink(`${fixture}/slot.lock`);
});
test('wrong expected source digest refuses before child spawn', async () => {
  const r = await result(launch('test',{EFS_ARCHIVE_EXPECTED_SOURCE_DIGEST:'0'.repeat(64)}));
  assert.equal(r.code,1); assert.match(r.report.failure,/digest/);
  assert.equal(await exists(`${fixture}/child-started`),false);
});
test('ordinary repeated pre-spawn signals cancel launch and release slot', async () => {
  const p = launch('test',{TEST_PS_HANG:'1',EFS_ARCHIVE_EXPECTED_SOURCE_DIGEST:'0'.repeat(64)});
  await until(()=>exists(`${fixture}/slot.lock`));
  p.child.kill('SIGHUP'); p.child.kill('SIGQUIT');
  const r = await result(p);
  assert.equal(r.code,1); assert.equal(r.signal,null);
  assert.equal(await exists(`${fixture}/child-started`),false);
  assert.equal(await exists(`${fixture}/slot.lock`),false);
});
test('hung process scan times out and cleans its owned group', async () => {
  const r = await result(launch('test',{TEST_PS_HANG:'1',EFS_ARCHIVE_EXPECTED_SOURCE_DIGEST:'0'.repeat(64)}));
  assert.equal(r.code,1); assert.match(r.report.failure,/timeout/);
  assert.equal(r.report.ownedProcessesStopped,true);
  assert.equal(await exists(`${fixture}/slot.lock`),false);
});
test('insufficient fresh cleanup headroom refuses before spawn', async () => {
  const r = await result(launch('test',{EFS_ARCHIVE_LEASE_END:new Date(Date.now()+3000).toISOString(),EFS_ARCHIVE_EXPECTED_SOURCE_DIGEST:'0'.repeat(64)}));
  assert.equal(r.code,1); assert.match(r.report.failure,/headroom|lease/);
  assert.equal(await exists(`${fixture}/child-started`),false);
});
test('new source files invalidate the handoff digest', async () => {
  const pin=await result(launch('pin'));
  await fs.writeFile(`${lab}/test/Added.sol`,'pragma solidity ^0.8.30; contract Added {}');
  const r=await result(launch('test',{EFS_ARCHIVE_EXPECTED_SOURCE_DIGEST:pin.report.sourceDigest}));
  assert.equal(r.code,1);assert.match(r.report.failure,/digest/);
  assert.equal(await exists(`${fixture}/child-started`),false);
  await fs.unlink(`${lab}/test/Added.sol`);
});
test('external imports and symlinks fail closed without a child', async () => {
  await fs.writeFile(`${lab}/test/External.sol`,'import "../../outside.sol";');
  const external=await result(launch('pin'));
  assert.equal(external.code,1);assert.match(external.report.failure,/outside snapshot/);
  await fs.unlink(`${lab}/test/External.sol`);
  await fs.symlink(`${lab}/src/A.sol`,`${lab}/test/Link.sol`);
  const linked=await result(launch('pin'));
  assert.equal(linked.code,1);assert.match(linked.report.failure,/symlink/);
  await fs.unlink(`${lab}/test/Link.sol`);
});
test('running fake child uses pinned read-only source and all ordinary signals clean up', async () => {
  for(const kind of ['SIGTERM','SIGINT','SIGHUP','SIGQUIT']) {
    const pin=await result(launch('pin'));
    const p=launch('test',{EFS_ARCHIVE_EXPECTED_SOURCE_DIGEST:pin.report.sourceDigest});
    await until(()=>exists(`${fixture}/child-started`));
    const pid=Number(await fs.readFile(`${fixture}/child-started`,'utf8'));
    const path=`${fixture}/${p.label}.source/src/A.sol`;
    const before=await fs.readFile(path,'utf8');
    await fs.writeFile(`${lab}/src/A.sol`,before+'// changed live\n');
    assert.equal(await fs.readFile(path,'utf8'),before);
    assert.equal((await fs.stat(path)).mode&0o222,0);
    const second=await result(launch('pin'));
    assert.equal(second.code,1);assert.match(second.report.failure,/EEXIST/);
    p.child.kill(kind);await new Promise(r=>setTimeout(r,20));p.child.kill(kind);
    const r=await result(p);
    assert.equal(r.code,1);assert.equal(r.signal,null);
    assert.equal(r.report.ownedProcessesStopped,true);
    assert.ok(r.report.signals.includes(kind));
    assert.equal(r.report.compiler.forge.sha256,'e729589084ca2f1479354353d1ec3d4789451b577f4cdee4e7dc57cae64a38fa');
    assert.equal(r.report.compiler.solc.sha256,'738dcdc6afddeb505ee4e4ef24f1c1fdba2b8c924e614cbbf5801a5b062dd683');
    assert.throws(()=>process.kill(-pid,0),e=>e.code==='ESRCH');
    assert.equal(await exists(`${fixture}/slot.lock`),false);
    await fs.writeFile(`${lab}/src/A.sol`,before);
    await fs.unlink(`${fixture}/child-started`);
  }
});
test('finite lease watchdog stops a TERM-ignoring fake child before lease expiry', async () => {
  const pin=await result(launch('pin'));
  const end=Date.now()+8000;
  const r=await result(launch('test',{EFS_ARCHIVE_EXPECTED_SOURCE_DIGEST:pin.report.sourceDigest,EFS_ARCHIVE_LEASE_END:new Date(end).toISOString()}));
  assert.equal(r.code,1);assert.match(r.report.failure,/watchdog/);
  assert.equal(r.report.ownedProcessesStopped,true);
  assert.ok(Date.now()<end);
  assert.equal(await exists(`${fixture}/slot.lock`),false);
  await fs.unlink(`${fixture}/child-started`);
});
