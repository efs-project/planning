# Independent Files Names gate review — 2026-09-14

Verdict: **Approved — SpecCompliant and QualityApproved for this bounded disposable gate.** No outstanding Critical or Important finding. The identified metadata defect was reproduced and corrected before approval. This is not approval of a cold browser, production profile, paid cost or permanent foundation freeze.

## Scope and evidence inspected

Reviewed the complete main `files-name-retention-gate-plan-20260914.md`, both new source files, their RED-to-GREEN diff, the full task report, the actual root-run focused RED/GREEN JSON reports and logs, and the relevant actual Ledger/FilesParentIndex integration. Reviewer did not author this Names implementation and did not run Forge, a compiler, Anvil, RPC, Git, or another agent. No existing sources were edited.

- Root plan: ordinary mandatory named Files profile, one explicit folder ID mounted as `/`, initially six standalone cases, no Core changes or browser/paid-performance claim. Root subsequently authorized a seventh case for the independently identified metadata gap; the original six assertions were not changed.
- Actual RED: `files-names-red.{json,log}`, source `77c1d6248d7d7bcd91ade828f835d818d926ea216e7580b8fdad0a7d22c0b37a`, compiled successfully, 1 PASS / 5 intended FAIL / 0 skipped, exit 1, finished 13:05:59 UTC. The passing case checks both real signed and direct-native missing-name rollback. The three callback failures, independent reader failure, and independent grammar failure are the intended behavior failures, not syntax/zero-selection artifacts.
- Actual focused GREEN: `files-names-green.{json,log}`, source `7ced9701e99217703456d1d80cb54a8b107ab5472dfc3687432be8abca051f51`, compiled successfully, 6 PASS / 0 FAIL / 0 skipped, exit 0, finished 13:13:38 UTC.
- Both reports show owned-process cleanup and slot release. Independently recomputed every one of the 49 source hashes in each frozen snapshot and the ordered JSON manifest digests. Only `test/FilesNamesProfile.sol` differs between these snapshots.
- RED profile SHA: `f841a9f499d0ab58f2669a143010c088a894ecaca93cd51e7a4fce6fcb9c6ed4`.
- Initial GREEN profile SHA: `68908993e22d36ada2928730fdbd74a2d351cabd5c0b039347f34ee1c3a10c06`.
- Original six-case tests SHA: `b6fb0aafa2b4cccb1eb5801d90626a9b6f612382fe1dfbc7d802c264ed51ce69`.
- Added seventh-case tests SHA: `7e89b47991e49a51344fd4ab00f202927133afa48fbffe4df2afd47658b0e616`.
- Actual metadata RED: `files-names-metadata-red.{json,log}`, source `036ba4ac1c02f6673674c0ce52aa9d55e49cdc0408d328099302e511db4d787c`, successful compile, 0 PASS / 1 intended FAIL / 0 skipped, exit 1, finished 13:20:33 UTC with owned cleanup/slot release. The exact failed assertion is `forged earlier metadata is invalid despite correct name bytes`.
- Actual final full regression: `files-names-final-test.{json,log}`, source `b0ba64c292576b615a7193c07728643a96d81f55cd1b8c831a38abaf12567140`, successful compile, 169 PASS / 0 FAIL / 0 skipped across 15 suites, exit 0, finished 13:22:38 UTC with owned cleanup/slot release. All seven Names cases are present and pass. Independently counted 135 distinct case names plus 34 inherited repeats (the 17 existing FilesJoined cases repeat in two derived test contracts); Names adds seven standalone cases and no inherited duplicates.
- Final profile SHA: `4201fd5908180c5f95d836563a8deae908d7208179b4fe3b211c73ff323ac48e`; final seven-case test SHA remains `7e89b47991e49a51344fd4ab00f202927133afa48fbffe4df2afd47658b0e616` from metadata RED. Independently rehashed all 49 files and complete manifest digests for metadata RED and final full snapshots. The corrective source diff is only the `FilesLayout` import and actual header comparison before FOUND; the seventh-case test is unchanged after its observed RED.
- Actual final normal-size gate: `files-names-final-size.{json,log}`, the identical `b0ba64c292576b615a7193c07728643a96d81f55cd1b8c831a38abaf12567140` input, successful compile/build, exit 0, finished 13:23:55 UTC with owned cleanup/slot release. Independently rehashed all 49 snapshot entries and its complete manifest, and compared them exactly with the final full-test manifest.

Source paths above are relative to `planning-warroom-b-run/Reviews/2026-09-12-efs-path-decision/lab-b/`; executed gate artifacts are under `/tmp/efs-b-archive-task1.OXPOfb/`. The reviewed task report is `.superpowers/sdd/files-name-retention-gate-plan-20260914/task-1-report.md` in that worktree. Its stage-specific pending language records chronology; the actual final gates above close those stages.

### Normal module sizes

| Module | Runtime bytes | Compiler initcode bytes |
| --- | ---: | ---: |
| FilesNamesIndex | 8,341 | 12,562 |
| FilesNameReader | 4,845 | 6,122 |
| FilesNameRule | 741 | 767 |
| FilesParentIndex | 5,339 | 9,325 |
| FilesJoinedConsumer | 15,865 | 19,976 |
| Ledger | 17,280 | 17,670 |

These are the actual build table's byte sizes, not deployment receipts or prices; compiler initcode excludes appended constructor arguments. The Names test-harness initcode warning (117,124 bytes) is separate from the deployable profile modules' sizes. Build output still contains warnings, not a clean-lint claim. The new divide-before-multiply warning is the intentional ceiling-to-32 ABI padding expression; the first-admission narrowing is guarded by the uint64 upper-bound check.

## Source and test assessment

No blocking source flaw remains in the reviewed correction; full regression and normal-size gates both close at the exact final source.

1. **Real mandatory admission, not an SDK convention.** `FilesNamesIndex.onAdmission` calls the existing parent callback first; inherited authorization and maintenance remain active. It checks each real FOLDER BIND position, binding key and scope key, then requires a retained Name of the exact constructor-pinned Type. The signed create test checks exact nested `E_INDEX(E_NAME_REQUIRED(...))`, nonce/count/retry-key/subject/record/head/position and nine posting families. A separate direct generic bind hits the same guard. This is a bounded rollback subset, not every possible raw slot.
2. **Correct atomic order.** `Ledger._endPublication` updates final counters and invokes the index after all actions. The callback bounds Name first admission by the final effect's admission, not the placement effect. The positive case truly places at admission 4 and publishes Name at 5 in one signed publication; later Child admission 6 and HEAD 7 verify existing parent maintenance and COMPLETE scope/parent coverage survive the derived callback.
3. **Names are attached to placement roles, not File IDs.** The helper derives `Keys.recordFromHash(nameType, role)`. The tests actually give one File two distinct named positions and then reuse one position for another File without republishing the retained name. Exact position/target/name results and both Files' contents are checked, not just successful calls.
4. **Withdrawal is not deletion.** The last Name occurrence is actually withdrawn, with count zero, withdrawal flag true and real nonce/admission changes. Retained name bytes, selected Alice placement, folder membership and File contents remain. A genuine lower-priority Bob placement is present, so unintended fallthrough would be observable. Occurrence count is ABI-checked but never used as a validity gate.
5. **Qualified name recovery is independent of membership.** The reader-isolation case installs a real base FilesParentIndex and matching Lens, so it reaches the healthy reader check even while the RED Names callback refuses. Response-only missing/revert/wrong-Type/wrong-bytes/future-first facades change no authoritative storage; the real COMPLETE membership page and bounded state snapshot remain equal. Future/past admission, wrong epoch/Core and wrong folder are rejected with precise errors.
6. **Explicit bounded grammar.** Nine invalid byte strings go through actual signed Name publication and exact mandatory-acceptor refusal, with no retained record or nonce/admission progress. Supported bytes and a 255-byte input are retained exactly. This is lowercase ASCII `[a-z0-9._-]` excluding `.`/`..`, not Unicode filename support or normalization.
7. **Correct bytes do not authenticate arbitrary metadata.** The added case runs under the actual NamesIndex, not the reader-isolation arm. It checks actual Core header first admission 5 and length 8, then demonstrates a facade supplies the same Type, occurrence and exact `note.txt` preimage but first admission 1. The expected INVALID result is genuinely RED on the original reader. The authorized correction compares source Type/first/length with `FilesLayout.header(ledger, recordId)` after byte checks and before FOUND. This reads real pinned-Core header slots; it does not trust a second facade response or add an occurrence gate. The test also preserves exact membership/state and rechecks healthy name/content fallback.

The fixed-output decoder in `FilesNameLayout.load` uses a 100,000-gas STATICCALL and a 416-byte output buffer. It checks total size, exact dynamic offset, first/occurrence integer widths, bounded length and corresponding padded return length before copying at most 255 bytes. Source reverts become UNAVAILABLE and malformed responses INVALID. The seven tests do not independently attack every malformed ABI offset/length/integer or a returndata bomb; source inspection is not a fuzz/security proof. The 100,000-gas cap is not an empirically established worst-case budget for all chains or maximum-sized publications.

## Required evidence-level boundary

The production-shaped positive fixture configures `source == address(ledger)`. With that source, the retained Type and first-admission metadata come from the actual pinned Core execution. The configurable facade response does **not** itself authenticate that metadata: the initial GREEN reader accepted any supplied nonzero first admission within the basis when the Type and preimage were correct. A correct preimage authenticates bytes/Record identity, not an arbitrary facade's admission history.

This was surfaced to root before final review and reproduced by the separately observed seventh-case RED. The corrected source now performs the real-Core header comparison, and the seventh case passes in the actual final full run. Returned metadata is therefore checked against the actual pinned Core execution, rather than the facade alone. That still is not an RPC/state proof, full source-authentication system, or evidence that every malformed-response class has been attacked.

Likewise MISSING means a missing response from the configured source, **not** ABSENT_PROVEN in Core: mode 1 deliberately returns MISSING while Core retains the Name. It never licenses removing the member or displaying an empty folder. Membership can be COMPLETE while some display names are unavailable/invalid.

## Explicit remaining gates

- This helper requires an independently verified placement at the supplied current execution basis. It does not select a Lens author, prove membership/coverage, authenticate a historical block, prove chain state or produce a full path.
- One explicit mounted folder is not recovered nested directory ancestry. No browser, SDK cold-guest path, sanitization/rendering, sorting or complete named-list integration has been executed.
- The raw-hash role and ordinary ASCII Name Type are a disposable profile, not adoption of the fuller hierarchical design's different domain-separated name-role formula or durable profile IDs.
- The required callback is effective while the configured reviewed Names index is attached. Existing testnet index replacement/configuration authority is not eliminated or globally frozen by this experiment.
- No new paid costs, storage economics, 1,000-entry behavior, maximum batch budget, MUD parity, state-proof claim or production readiness follows from Forge test-function gas or this bounded gate.
- Whole-suite and normal-size results are complete only for the exact pinned input above. They do not substitute for later cold SDK/browser integration, resource-bound testing or paid measurements of the named profile.
