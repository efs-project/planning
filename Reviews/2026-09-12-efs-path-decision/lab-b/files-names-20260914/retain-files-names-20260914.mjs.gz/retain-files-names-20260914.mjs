// Prepared file-only retention. No child process, compiler, tests, RPC, or Git.
// Configuration must be finalized by root after all named execution gates close.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { gzipSync, gunzipSync } from 'node:zlib';
import { fileURLToPath } from 'node:url';

const sha = value => createHash('sha256').update(value).digest('hex');
const encode = value => Buffer.from(JSON.stringify(value, null, 2) + '\n');
function read(file) {
  assert.equal(typeof file, 'string', 'closed exact input path required');
  const st = fs.lstatSync(file);
  assert(st.isFile() && !st.isSymbolicLink() && st.size <= 64 * 1024 * 1024, 'bounded regular input: ' + file);
  return fs.readFileSync(file);
}
const json = file => JSON.parse(read(file));
const configurationFile = process.argv[2];
const config = json(configurationFile);
assert.equal(config.schema, 'efs-files-names-retention-inputs-1');
assert.equal(config.runRoot, '/tmp/efs-b-archive-task1.OXPOfb');
assert.equal(config.worktree, '/Users/james/Code/EFS/planning-warroom-b-run');
assert.equal(config.destination, 'Reviews/2026-09-12-efs-path-decision/lab-b/files-names-20260914');
assert(Date.now() < Date.parse(config.notAfterUTC), 'retention cutoff');
assert(/^[a-f0-9]{40}$/.test(config.sourceCommit ?? ''), 'root-reported closed source commit required');
assert(Number.isSafeInteger(config.fullExpectedTests) && config.fullExpectedTests > 7, 'actual full count required');
assert.equal(config.artifacts.finalReview.verdict, 'SPEC_COMPLIANT_QUALITY_APPROVED', 'actual final review required');
const run = config.runRoot;
const destination = path.join(config.worktree, config.destination);
assert(!fs.existsSync(destination), 'new packet only; never overwrite');
const payloads = new Map();
function add(name, file, description, expected) {
  assert.equal(path.basename(name), name);
  assert(!payloads.has(name));
  const bytes = read(file);
  const digest = sha(bytes);
  if (expected) assert.equal(digest, expected, 'input pin: ' + name);
  payloads.set(name, { file, rawBytes: bytes.length, rawSha256: digest, description });
}
function generated(name, value, description) {
  assert(!payloads.has(name));
  const bytes = encode(value);
  payloads.set(name, { bytes, rawBytes: bytes.length, rawSha256: sha(bytes), description });
}
function regularSource(gate, name) {
  assert(!path.isAbsolute(name) && !name.split('/').includes('..'));
  assert(path.resolve(gate.snapshot).startsWith(path.resolve(run) + path.sep));
  return path.join(gate.snapshot, name);
}
function checkGate(label, pin = false) {
  assert(/^[a-z0-9-]+$/.test(label ?? ''), 'closed gate label required');
  const gate = json(path.join(run, label + '.json'));
  assert.equal(gate.label, label);
  assert(gate.finishedAt && gate.ownedProcessesStopped && gate.slotReleased, 'gate must be closed: ' + label);
  assert(!gate.failure && !gate.stopReason && gate.outcome && gate.outcome.signal === null, 'clean gate outcome: ' + label);
  assert.equal(sha(JSON.stringify(gate.source)), gate.sourceDigest);
  if (pin) {
    assert.equal(gate.mode, 'pin');
    assert.equal(gate.outcome.noChild, true);
    assert.equal(gate.outcome.code, 0);
    assert(!gate.pid, 'pin cannot be called execution');
  } else {
    assert.equal(gate.sourceDigest, gate.expectedSourceDigest);
    assert(Number.isSafeInteger(gate.pid) && !gate.outcome.noChild, 'actual child execution required');
  }
  for (const [name, digest] of Object.entries(gate.source)) assert.equal(sha(read(regularSource(gate, name))), digest, label + ': ' + name);
  for (const ext of ['json', 'log']) add(label + '.' + ext, path.join(run, label + '.' + ext),
    pin ? 'Original pin/no-child record; not compiler/test/size execution evidence.' : 'Complete original executed gate report or unabridged log.');
  return gate;
}
const gates = Object.fromEntries(Object.entries(config.labels).map(([role, label]) => [role, checkGate(label)]));
const pins = config.pinLabels.map(label => checkGate(label, true));
for (const [role, gate] of Object.entries(gates)) {
  assert.equal(gate.sourceDigest, config.sourceDigests[role === 'full' || role === 'size' ? 'final' : role]);
  assert.equal(gate.outcome.code, role === 'red' || role === 'metadataRed' ? 1 : 0);
}
assert.deepEqual(gates.full.source, gates.size.source, 'full/size must share exact final source');
const testFile = 'test/FilesNames.t.sol';
const profileFile = 'test/FilesNamesProfile.sol';
for (const role of ['red', 'green']) assert.equal(gates[role].source[testFile], config.sourcePins.originalTests);
for (const role of ['metadataRed', 'full', 'size']) assert.equal(gates[role].source[testFile], config.sourcePins.sevenTests);
assert.equal(gates.red.source[profileFile], config.sourcePins.redProfile);
for (const role of ['green', 'metadataRed']) assert.equal(gates[role].source[profileFile], config.sourcePins.greenProfile);
for (const role of ['full', 'size']) assert.equal(gates[role].source[profileFile], config.sourcePins.finalProfile);
function changed(a, b) {
  assert.deepEqual(Object.keys(a.source), Object.keys(b.source));
  return Object.keys(a.source).filter(name => a.source[name] !== b.source[name]);
}
assert.deepEqual(changed(gates.red, gates.green), [profileFile]);
assert.deepEqual(changed(gates.green, gates.metadataRed), [testFile]);
assert.deepEqual(changed(gates.metadataRed, gates.full), [profileFile]);
for (const pin of pins) assert(Object.values(config.sourceDigests).includes(pin.sourceDigest), 'pin source must match retained stage');

function logCounts(gate) {
  const log = read(path.join(run, gate.label + '.log')).toString();
  const primary = log.split('Failing tests:')[0];
  const passed = [...primary.matchAll(/^\[PASS\] (\S+) /gm)].map(m => m[1]);
  const failed = [...primary.matchAll(/^\[FAIL:[^\n]*?\] (\S+) /gm)].map(m => m[1]);
  assert.match(log, /0 skipped/);
  return { passed: passed.length, failed: failed.length, skipped: 0, names: [...passed, ...failed] };
}
const counts = Object.fromEntries(['red', 'green', 'metadataRed', 'full'].map(role => [role, logCounts(gates[role])]));
for (const [role, passed, failed] of [['red', 1, 5], ['green', 6, 0], ['metadataRed', 0, 1], ['full', config.fullExpectedTests, 0]]) {
  assert.equal(counts[role].passed, passed, role);
  assert.equal(counts[role].failed, failed, role);
}
const tests = file => new Map([...read(file).toString().matchAll(/^    function (test_[A-Za-z0-9_]+)\b[\s\S]*?^    }/gm)].map(m => [m[1] + '()', m[0]]));
const originalTests = tests(regularSource(gates.green, testFile));
const finalTests = tests(regularSource(gates.full, testFile));
assert.equal(originalTests.size, 6);
assert.equal(finalTests.size, 7);
for (const [name, body] of originalTests) assert.equal(finalTests.get(name), body, 'original test body preserved: ' + name);
const added = [...finalTests.keys()].filter(name => !originalTests.has(name));
assert.deepEqual(counts.metadataRed.names, added, 'focused metadata RED is the disclosed seventh falsifier');
for (const name of finalTests.keys()) assert(counts.full.names.includes(name), 'all seven appear in final full gate: ' + name);

const compilerRecords = [];
let finalSizeContracts;
for (const [role, gate] of Object.entries(gates)) {
  const directory = path.join(run, gate.label + '.state/build-info');
  const buildFiles = fs.readdirSync(directory).filter(name => name.endsWith('.json')).sort();
  assert(buildFiles.length > 0 && buildFiles.length <= 8, 'bounded complete build-info inventory');
  for (const [index, name] of buildFiles.entries()) {
    const file = path.join(directory, name);
    const build = json(file);
    assert(build.input?.sources && build.output?.contracts && build.output?.sources);
    assert.equal(build.solcVersion, '0.8.30');
    assert.equal(build.input.settings.viaIR, true);
    assert.equal(build.input.settings.optimizer.enabled, true);
    assert.equal(build.input.settings.optimizer.runs, 200);
    assert.equal(build.input.settings.evmVersion, 'cancun');
    for (const [source, data] of Object.entries(build.input.sources)) assert.equal(sha(data.content), gate.source[source], 'compiler source: ' + source);
    const retainedName = gate.label + '-compiler-' + index + '.json';
    add(retainedName, file, 'Complete original compiler input/output, source contents, settings, AST, ABI, metadata and bytecode; not a rebuild.');
    compilerRecords.push({ role, originalFile: name, retainedFile: retainedName + '.gz', sourceDigest: gate.sourceDigest });
    if (role === 'size') finalSizeContracts = { ...finalSizeContracts, ...build.output.contracts };
  }
  const files = {};
  for (const [source, digest] of Object.entries(gate.source)) {
    const bytes = read(regularSource(gate, source));
    files[source] = { bytes: bytes.length, sha256: digest, content: bytes.toString('utf8') };
    assert.equal(sha(files[source].content), digest, 'exact UTF-8 inventory');
  }
  generated(gate.label + '-source-inventory.json', { sourceDigest: gate.sourceDigest, sourceHashes: gate.source, files },
    'Complete gate-inventoried source/config/script contents, not only the two Names files.');
  for (const source of [testFile, profileFile]) add(gate.label + '-' + path.basename(source), regularSource(gate, source),
    'Exact Names source at this historical stage; original six versus review-driven seventh test history is retained.');
}
const sizes = {};
for (const source of [profileFile, testFile]) for (const [name, artifact] of Object.entries(finalSizeContracts[source] ?? {})) {
  const evm = artifact.evm;
  if (!evm?.bytecode?.object || !evm?.deployedBytecode?.object) continue;
  sizes[name] = { source, runtimeBytes: evm.deployedBytecode.object.replace(/^0x/, '').length / 2,
    compilerInitcodeBytes: evm.bytecode.object.replace(/^0x/, '').length / 2 };
}
assert(Object.keys(sizes).length > 0, 'normal-size compiler output required');
for (const [role, artifact] of Object.entries(config.artifacts)) {
  assert(/^[a-f0-9]{64}$/.test(artifact.sha256 ?? ''), 'closed artifact hash required: ' + role);
  add(({ preflight: 'cold-name-preflight.md', plan: 'approved-plan.md', taskReport: 'task-report.md', finalReview: 'independent-final-review.md' })[role],
    artifact.path, 'Complete original ' + role + '; exact root-pinned artifact.', artifact.sha256);
}
add('outer-forge-gate-at-retention.mjs', path.join(run, 'forge-gate.mjs'), 'Root gate at retention; not misrepresented as exact historical harness bytes for every attempt.');
add('outer-forge-gate-at-retention.test.mjs', path.join(run, 'forge-gate.test.mjs'), 'Root gate test source at retention; not executed by packager.');
add('frozen-foundry.toml', regularSource(gates.size, 'foundry.toml'), 'Exact normal-settings configuration.');
add('retention-inputs.json', configurationFile, 'Root-finalized exact retention inputs and expected outcomes.');
add('retain-files-names-20260914.mjs', fileURLToPath(import.meta.url), 'This mechanical packager; no execution replay.');
assert([...payloads.values()].reduce((n, item) => n + item.rawBytes, 0) <= 384 * 1024 * 1024, 'packet raw-byte cap');
assert(Date.now() < Date.parse(config.notAfterUTC), 'all preflight must finish before cutoff');

const manifest = { kind: 'DISPOSABLE_REQUIRED_RETAINED_FILES_NAMES', sourceCommit: config.sourceCommit,
  sourceCommitAuthority: 'ROOT_REPORTED_NO_WORKER_GIT', sourceDigests: config.sourceDigests,
  history: { originalSixRed: counts.red, originalSixGreen: counts.green, reviewDrivenSeventhRed: counts.metadataRed,
    finalFull: { ...counts.full, distinctNamedCases: new Set(counts.full.names).size },
    originalSixTestBodiesPreserved: true, sevenTestsFrozenFromMetadataRedThroughFinal: true },
  stages: Object.entries(gates).map(([role, g]) => ({ role, label: g.label, evidence: 'ACTUAL_CHILD_EXECUTION',
    startedAt: g.startedAt, finishedAt: g.finishedAt, sourceDigest: g.sourceDigest, outcome: g.outcome,
    ownedProcessesStopped: g.ownedProcessesStopped, slotReleased: g.slotReleased })),
  pins: pins.map(g => ({ label: g.label, evidence: 'PIN_NO_CHILD_NOT_TEST_EXECUTION', sourceDigest: g.sourceDigest, outcome: g.outcome })),
  compilerRecords, sizes, compilerInitcodeExcludesConstructorArguments: true,
  review: config.artifacts.finalReview,
  limits: 'ASCII_SUBSET_RAW_HASH_ROLE_ONLY; NAME_RECOVERY_IS_NOT_LENS_MEMBERSHIP_OR_HEADER_STATE_PROOF; METADATA_CHECK_IS_LEDGER_CONSISTENCY; NO_COLD_BROWSER_SDK_PATH_OR_COMPLETE_ANCESTRY; NO_PAID_GAS_OR_PRODUCTION_CLAIM',
  files: {} };
fs.mkdirSync(destination);
for (const [name, item] of payloads) {
  const bytes = item.bytes ?? read(item.file);
  assert.equal(bytes.length, item.rawBytes);
  assert.equal(sha(bytes), item.rawSha256, 'input changed after preflight: ' + name);
  const compressed = gzipSync(bytes, { level: 9 });
  assert.deepEqual(gunzipSync(compressed), bytes, 'compression roundtrip: ' + name);
  const filename = name + '.gz';
  fs.writeFileSync(path.join(destination, filename), compressed, { flag: 'wx' });
  assert.equal(sha(read(path.join(destination, filename))), sha(compressed), 'written gzip: ' + name);
  manifest.files[filename] = { rawBytes: bytes.length, rawSha256: sha(bytes), gzipBytes: compressed.length,
    gzipSha256: sha(compressed), roundtripVerified: true, description: item.description };
}
manifest.totals = Object.values(manifest.files).reduce((n, f) => ({ files: n.files + 1, rawBytes: n.rawBytes + f.rawBytes,
  gzipBytes: n.gzipBytes + f.gzipBytes }), { files: 0, rawBytes: 0, gzipBytes: 0 });
const encoded = encode(manifest);
fs.writeFileSync(path.join(destination, 'manifest.json'), encoded, { flag: 'wx' });
assert.deepEqual(json(path.join(destination, 'manifest.json')), manifest);
const readme = `# Required retained Files Names — closed evidence\n\nOriginal six-case RED: 1 pass / 5 fail. Original six-case GREEN: 6 pass / 0 fail. Independent review added one disclosed metadata falsifier: its original-helper RED is 0 pass / 1 fail. Final full regression: ${counts.full.passed} executions, ${new Set(counts.full.names).size} distinct named cases, 0 failures/skips; all seven Names tests occur. Normal-size gate shares the exact final source.\n\nSource commit ${config.sourceCommit} is root-reported. Final review is SpecCompliant / QualityApproved. The manifest separates four pin/no-child records from actual execution and retains original reports/logs, complete compiler inputs/outputs, all-source inventories, each stage's exact Names files, plan, preflight, task report, final review and root harness at retention. ${manifest.totals.files} compressed payloads: ${manifest.totals.rawBytes} raw bytes to ${manifest.totals.gzipBytes} gzip bytes, each byte-roundtrip verified.\n\nThe original six test bodies are unchanged; the seventh test is disclosed rather than retroactively counted as original RED. Name metadata is checked against the real Ledger; this is onchain consistency, not a header/state-root proof. A recovered name does not prove placement membership, Lens selection, full ancestry or authoritative absence. This ASCII/raw-role subset does not close cold browser/SDK integration or promise paid costs, production readiness, Unicode support or historical portability. Constructor arguments are excluded from compiler initcode lengths; test harness sizes are not deployable component claims.\n\nRetention is mechanical only: no new compiler/test/Anvil/RPC/Git or paid execution. Original paths/deadlines in preserved evidence are provenance, not instructions to rerun.\n`;
fs.writeFileSync(path.join(destination, 'README.md'), readme, { flag: 'wx' });
console.log(JSON.stringify({ status: 'RETENTION_BYTE_ROUNDTRIP_PASS', destination, manifestSHA256: sha(encoded),
  readmeSHA256: sha(readme), ...manifest.totals, executionStages: 5, pinOnlyRecords: pins.length }, null, 2));
