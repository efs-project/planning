// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;

import {Ledger} from "../src/Ledger.sol";
import {Keys} from "../src/Keys.sol";
import {TypeRegistry} from "../src/TypeRegistry.sol";
import {IAcceptor} from "../src/Interfaces.sol";
import {FilesParentIndex} from "./FilesJoinedProfile.sol";

/// Disposable raw-hash ASCII names profile, not Unicode FilesName or hierarchical DirectoryEntry.
library FilesNameLayout {
    bytes32 internal constant SHAPE = keccak256("lab/type/files-name-raw-ascii/1");
    bytes32 internal constant FOLDER = keccak256("efs2/purpose/folder/1");
    error E_NAME_PROFILE();

    function pin(Ledger core, bytes32 nameType, bytes32 expectedRuleHash) internal view {
        TypeRegistry types = TypeRegistry(address(core.registry()));
        (bytes32 shape, bytes32 ruleHash, address rule, uint8 count,,) = types.descriptor(nameType);
        bytes32[] memory refs = types.refTypes(nameType);
        if (nameType == 0 || expectedRuleHash == 0 || shape != SHAPE || count != 0 || refs.length != 0
            || rule.code.length == 0 || ruleHash != expectedRuleHash || rule.codehash != expectedRuleHash
            || Keys.typeId(shape, refs, ruleHash) != nameType) revert E_NAME_PROFILE();
    }
}

contract FilesNameRule is IAcceptor {
    // RED stub: deliberately permissive so genuine invalid-name publications expose the missing rule.
    function accept(bytes32, bytes calldata, bytes32[] calldata) external pure returns (bool) {
        return true;
    }
}

contract FilesNamesIndex is FilesParentIndex {
    bytes32 public immutable nameType;
    bytes32 public immutable expectedNameRuleHash;
    error E_NAME_REQUIRED(bytes32 position, bytes32 nameRecord);

    constructor(address core, bytes32 rt, bytes32 ct, bytes32 rh, bytes32 ch, bytes32 nt, bytes32 nh)
        FilesParentIndex(core, rt, ct, rh, ch)
    {
        FilesNameLayout.pin(Ledger(core), nt, nh);
        nameType = nt;
        expectedNameRuleHash = nh;
    }

    function onAdmission(uint64 publication, Effect[] calldata effects) public override {
        super.onAdmission(publication, effects);
        Ledger core = Ledger(ledger);
        for (uint256 i; i < effects.length; ++i) {
            if (effects[i].kind != 3) continue;
            bytes32 position = core.bindingPosition(effects[i].bindingOrdinal);
            (bytes32 purpose,, bytes32 role) = core.positionCell(position);
            if (purpose != FilesNameLayout.FOLDER) continue;
            // RED stub: refuses even a valid retained Name; inherited maintenance must roll back.
            revert E_NAME_REQUIRED(position, Keys.recordFromHash(nameType, role));
        }
    }
}

interface IFilesNameSource {
    function record(bytes32 id) external view returns (bytes32, uint64, uint32, bytes memory);
}

/// Caller supplies an independently verified placement; this helper DOES NOT establish
/// membership, author selection, block authenticity, full paths, or named-list completeness.
contract FilesNameReader {
    uint8 public constant UNAVAILABLE = 0;
    uint8 public constant FOUND = 1;
    uint8 public constant MISSING = 2;
    uint8 public constant INVALID = 3;
    struct Basis { uint64 admission; uint64 epoch; bytes32 core; }
    struct Name { uint8 status; bytes32 recordId; uint64 firstAdmission; bytes value; }
    Ledger public immutable ledger;
    bytes32 public immutable coreCodehash;
    IFilesNameSource public immutable source;
    bytes32 public immutable nameType;
    bytes32 public immutable expectedNameRuleHash;
    error E_BASIS();
    error E_POSITION();

    constructor(Ledger core, address source_, bytes32 nt, bytes32 nh) {
        FilesNameLayout.pin(core, nt, nh);
        ledger = core;
        coreCodehash = address(core).codehash;
        source = IFilesNameSource(source_);
        nameType = nt;
        expectedNameRuleHash = nh;
    }

    function readName(bytes32, bytes32, bytes32 role, Basis calldata) external view returns (Name memory result) {
        // RED stub: a commitment without recovered bytes is not a successful name read.
        result.recordId = Keys.recordFromHash(nameType, role);
        result.status = UNAVAILABLE;
    }
}
