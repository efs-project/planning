# Files Name-retention gate — Task 1

## REDREADY, 2026-09-14

Full approved main `Reviews/2026-09-12-efs-path-decision/files-name-retention-gate-plan-20260914.md` and complete `/tmp/efs-b-cold-name-vertical-preflight-20260914.md` read. Implemented only the two authorized new test files. Existing Core, Index, Files modules/tests and paid/query/archive evidence remain unchanged. Standalone `FilesNamesTest is LabBase` adds exactly six test cases; it does not inherit FilesJoinedTest executions. No Forge/compiler/RPC/Anvil/Git/subagents or new runner used by worker.

Used TDD. Per root's explicit clarification, the new Name acceptor is deliberately permissive at RED; callback refuses every relevant FOLDER BIND after full inherited maintenance; read helper returns UNAVAILABLE and no bytes. No ASCII grammar implementation or positive Name retention/read semantics is implemented yet. Constructor profile validation uses actual deployed Name rule runtime hash, exact Type descriptor/ref-vector/derived identity; Type IDs intentionally change when the rule implementation changes at GREEN. No fabricated unchanged hash or Type pin.

### Exact source pins

- `lab-b/test/FilesNamesProfile.sol`: `f841a9f499d0ab58f2669a143010c088a894ecaca93cd51e7a4fce6fcb9c6ed4`
- `lab-b/test/FilesNames.t.sol`: `b6fb0aafa2b4cccb1eb5801d90626a9b6f612382fe1dfbc7d802c264ed51ce69`

Protected pins read back unchanged: IndexModule `2072d1b796af5143c3341363778bfd3b875c19da9dd3970c26b4cfac790a82a9`; FilesJoined `f162b2bc4feec913b9b2d92f90d76abcd7dde8613f02471b695946321cddc4e4`; FilesJoinedConsumer `0d45a6603f4fd055abe59307d93bcf651b4d66d98d89854a073265d0860713ae`; FilesWithdrawal `f191978d5881a9660ceb58b3424f90bb5361503230905f3cf9dae5c5b2b8e0d2`.

### Six cases and expected RED pattern (not execution evidence)

1. `test_names_missing_signed_and_generic_ingress_roll_back` — expected PASS under refusing callback. Genuine signed CREATE/Root/HEAD/placement with absent Name returns exact nested `Ledger.E_INDEX(FilesNamesIndex.E_NAME_REQUIRED(position, derivedNameRecord))`. Snapshot checks counts, nonce, creation, exact record responses, heads, position/binding positions, processed/publication state and nine actual posting families/words after super-maintenance rollback; retry publication identity remains absent. A separate real successful generic CREATE precedes a direct generic `Ledger.bind` refusal, with only that bind rolled back.
2. `test_names_signed_name_after_bind_and_parent_maintenance` — expected FAIL at required callback stub. Name action is ordinal 5, after placement ordinal 4 in the same actual signed publication. Positive assertions recover exact `note.txt`, verify real position/HEAD/Root/evidence, and then admit a Child at 6 plus HEAD at 7, checking inherited first-admission parent posting and COMPLETE scope/parent coverage. GREEN must bound Name first admission by final publication admission, not the BIND ordinal.
3. `test_names_multiple_positions_and_reused_name_without_republication` — expected FAIL at callback stub. Actual `note.txt` placement and second `brief.txt` placement select one File before another File reuses the old note position. Independent position/name/File checks; omitted existing Name stays at one occurrence; only two Name publication postings; both original File contents/HEADs remain correct.
4. `test_names_last_occurrence_withdrawal_preserves_name_membership_and_contents` — expected FAIL at callback stub. Actual lower-priority Bob native CREATE/placement supplies a fallthrough trap. Alice withdraws her sole Name admission 5; retained bytes/first stay exact at count 0, original admission withdrawn flag is true, real nonce/admission advance, live by-Type count falls, but selected placement/scope/names/contents remain unchanged. The test never compares all state unchanged across a valid withdrawal.
5. `test_names_response_faults_preserve_membership_and_reject_mixed_basis` — expected independent FAIL at read-helper stub's verified-name assertion. Root explicitly approved reader isolation: a fresh real FilesParentIndex and matching Lens admit the named fixture, so it reaches the reader independently of the Name callback stub. Healthy actual name recovery precedes response-only facades for successful missing response, source revert, wrong Type, wrong bytes, and future first admission. Each unavailable/missing/invalid result emits no display bytes; genuine Core/index state and COMPLETE membership remain byte-identical. Verified same-basis fallback, future/past admission, wrong epoch/Core, and wrong-folder position controls are included. No authoritative storage corruption or fake membership.
6. `test_names_ascii_grammar_refuses_unsupported_bytes_without_normalizing` — expected independent FAIL at permissive acceptor on the first empty-name publication. Nine genuine invalid Name publications must refuse exact `E_REJECTED(0, nameType)` without retained records/nonce/admissions: empty, slash, control, dot, dotdot, 256 ASCII bytes, uppercase, rich UTF-8, leading space. Exact `a-0_note.txt` and 255 ASCII bytes are positive controls. Unrelated BINARY Type reader construction must refuse exact profile error.

Expected aggregate: **6 selected, 1 PASS control, 5 intended FAILs**; three failures at callback, one reader qualification assertion, one grammar assertion. A compile error, zero tests, or different failure is not valid behavior RED. Compilation/execution remains UNKNOWN until root's gate. Do not alter test assertions after observed RED without disclosing the correction.

### Boundaries and next stage

Profile shape is explicitly `lab/type/files-name-raw-ascii/1`; roles are raw `keccak256(nameBytes)`, not the fuller design's domain-separated name-role formula. Folder `keccak256("lab/files-names/mounted-folder/1")` is mounted explicitly as `/`; no `/drafts` ancestry or nested path is claimed. The reader takes position/folder/role plus exact current admission/epoch/Core basis and returns actual bytes with FOUND/MISSING/UNAVAILABLE/INVALID qualification. It does not prove placement membership, selection, block authenticity, complete named listings or cold browser/SDK behavior. Source facades are deliberately untrusted response sources, not authoritative Name records.

After actual RED and explicit root authorization, implement only the Name grammar, relevant FOLDER retention validation after existing super maintenance, and qualified reader. No positive-occurrence check. No generic SDK, global dictionary, Core/index schema change, backfill, paid price, browser completeness, deployment cost extrapolation or production policy claim. Source cutoff remains 13:25 UTC.

## Actual RED observed by root → GREENREADY

Root read complete `files-names-red.{json,log}` and reported successful Solidity 0.8.30 compilation at source digest `77c1d6248d7d7bcd91ade828f835d818d926ea216e7580b8fdad0a7d22c0b37a`: exactly six selected cases, one PASS and five intended FAILs, zero skips. Exact callback, reader and grammar failures matched the declared stages. Cleanup/slot release true; independent RED fixture reviewer found no blocker. This is root-reported executed evidence, not a worker rerun. Original RED snapshot is preserved by root's gate.

After explicit GREEN authorization, verified both RED pins and changed only `FilesNamesProfile.sol`:

- `valid` plus the actual acceptor implement the 1–255 byte ASCII subset and dot/dotdot exclusions; no normalization.
- Shared bounded record loader performs a 100,000-gas STATICCALL with a fixed 416-byte return buffer. It never copies all arbitrary return data: checks return size, exact dynamic offset/length and integer ABI widths before copying at most 255 bytes. Revert/unavailable is separate from malformed response; occurrence integer is ABI-checked but zero is never a validity failure. This bounds the source interaction, not a measured worst-case profile budget or universal transport proof.
- Required callback retains full `super.onAdmission`, pins the Name profile, recovers real retained positions and cross-checks position/binding/scope derivations. Relevant FOLDER BINDs require exact Name Type, nonzero first admission within final publication admission, valid body and exact role/Record hashes. This intentionally accepts Name after BIND in the same atomic batch. Missing/invalid Name refuses the exact existing nested error.
- Reader checks current admission/epoch, constructor-pinned/current Core code identity, Name descriptor/rule identity, retained purpose/folder/role and position derivation. It derives the Name ID from the raw role and returns actual bytes only after exact Type/body/hash/first-admission checks. Empty absent response is MISSING, source failure UNAVAILABLE, malformed/wrong/future record evidence INVALID. It never invents membership or changes placement selection.

GREENREADY `FilesNamesProfile.sol` SHA-256: `68908993e22d36ada2928730fdbd74a2d351cabd5c0b039347f34ee1c3a10c06`.
Unchanged `FilesNames.t.sol`: `b6fb0aafa2b4cccb1eb5801d90626a9b6f612382fe1dfbc7d802c264ed51ce69`.

No test assertions or any existing source changed after RED; no compiler/Forge/RPC/Git execution by worker. Root's actual GREEN/full/size gates and final independent review remain pending. No cold browser/SDK/name-sort completeness, paid price, historical block authenticity or production claim.

## Explicit post-review metadata falsifier — new RED stage

Independent source review identified a distinct source-metadata gap: exact name preimage with forged first admission 1 passes the initial reader when actual Core first admission is 5. The existing bound checked only nonzero/within-basis, not agreement with the authoritative Core header. Root authorized a separate seventh regression, preserving the original six-case chronology rather than relabeling it.

Prepared the test outside live sources while root's original six-case GREEN gate held its freeze. Root then explicitly released installation at 13:19 UTC. Verified live test/profile baseline hashes and installed only facade mode 6, `test_names_forged_earlier_metadata_refuses_without_membership_change`, and six-to-seven count comment. Original six test method bodies/assertions are unchanged. The new test uses the actual mandatory NamesIndex fixture, checks Core header Type/first5/length8, genuine membership and healthy exact-name recovery, then substitutes only first=1 with unchanged name bytes/Type/occurrence. It requires INVALID/no bytes, unchanged real membership/Core snapshot, and healthy fallback.

Metadata REDREADY test SHA-256: `7e89b47991e49a51344fd4ab00f202927133afa48fbffe4df2afd47658b0e616`.
Profile remains unchanged at `68908993e22d36ada2928730fdbd74a2d351cabd5c0b039347f34ee1c3a10c06`.
Await root's actual focused seventh-test RED before any header-comparison repair. No helper change, compiler/test/RPC/Git execution by worker. MISSING denotes a source-response absence, not proven Core absence or authenticated historical evidence.

## Metadata RED observed → final GREENREADY at 13:21 UTC

Read the retained gate summaries for the original chronology: `files-names-red` at `77c1d6248d7d7bcd91ade828f835d818d926ea216e7580b8fdad0a7d22c0b37a` ran 1 PASS/5 FAIL, 13:05:49.490–13:05:59.884 UTC; `files-names-green` at `7ced9701e99217703456d1d80cb54a8b107ab5472dfc3687432be8abca051f51` ran all original six PASS, 13:13:27.645–13:13:38.243 UTC. Both record cleanup/slot release true. This six-case success did not prove the subsequently identified metadata guarantee.

Root then observed and authorized repair after `files-names-metadata-red.{json,log}` at input `036ba4ac1c02f6673674c0ce52aa9d55e49cdc0408d328099302e511db4d787c`, 13:20:22.591–13:20:33.592 UTC. Read its gate summary and actual failure tail: exactly one selected failure, `forged earlier metadata is invalid despite correct name bytes`, zero passes/skips; no compile/selector failure; cleanup and slot release true.

Only final helper delta: import existing `FilesLayout`, read the real Ledger Name header after response validity checks, and require returned Type, first admission and byte length equal that header before FOUND. No Core getter or other module changes. MISSING/UNAVAILABLE branches stay unchanged and remain source-response qualifications. This cross-checks the configured current Core; it is not an authenticated historical state proof.

Final frozen profile SHA-256: `4201fd5908180c5f95d836563a8deae908d7208179b4fe3b211c73ff323ac48e`.
All seven tests unchanged from metadata RED: `7e89b47991e49a51344fd4ab00f202927133afa48fbffe4df2afd47658b0e616`.
Source work stopped at 13:21:02 UTC, before the 13:25 cutoff. Root final full/size gates and final independent review remain pending. Worker executed no tests/compiler/RPC/Git; historical source snapshots remain separate and unmodified.

## Final root-read gates — implementation handoff closed

Root reports actual `files-names-final-test` at frozen source digest `b0ba64c292576b615a7193c07728643a96d81f55cd1b8c831a38abaf12567140`: **169 PASS, 0 FAIL, 0 SKIP**, including all seven FilesNames cases. The same-input normal `files-names-final-size` gate exited 0. Both gates record owned-process stop and slot release true. These results are root-read executed evidence, not a worker rerun.

Root-read compiled sizes (runtime / compiler initcode bytes): FilesNamesIndex **8,341 / 12,562**; FilesNameReader **4,845 / 6,122**; FilesNameRule **741 / 767**; unchanged Ledger **17,280 / 17,670**. Compiler initcode excludes appended constructor arguments. These are not new paid deployment/read/write receipt prices or a warning-free-build claim.

Final source remains frozen at profile `4201fd5908180c5f95d836563a8deae908d7208179b4fe3b211c73ff323ac48e` and seven-test file `7e89b47991e49a51344fd4ab00f202927133afa48fbffe4df2afd47658b0e616`. No source, tests, Git, compiler or RPC changed/run by worker during this closure. Independent reviewer `/root/files_paid_runner` is finalizing separately; this report does not preempt that verdict.

Worker status: DONE_WITH_CONCERNS / awaiting independent review and root publication. Required retention, exact byte recovery and current-Core metadata qualification are bounded prototype results. Membership remains independently Lens-qualified; MISSING remains a source response, not proven Core absence. Cold browser/SDK integration, full Unicode names, nested hierarchy, COMPLETE-at-write policy, authenticated historical evidence, comprehensive hostile-return testing and new paid economics remain outside this gate. Original six-case RED/GREEN and seventh metadata RED/final-GREEN chronology stay separately attributable.
