# Task 2 implementation report

## REDREADY checkpoint

Source-only worker, 2026-09-14. No compilation, Forge, solc, Anvil, RPC, dependency installation, git mutation, commits, pushes, or subagents were used. Root owns actual RED/GREEN and size evidence. Status is **REDREADY**, not a claim of successful compilation or a completed implementation.

### Files changed

- `Reviews/2026-09-12-efs-path-decision/lab-b/test/FilesJoinedConsumer.sol`: new typed consumer interface and deliberately incomplete behavioral stub.
- `Reviews/2026-09-12-efs-path-decision/lab-b/test/FilesJoined.t.sol`: one additive import and 207 additive lines after the eight unchanged Task 1 tests.
- This report only. Root-owned files and shared source/profile/index implementations were not changed.

### Real failing behavior to observe

Run `test_point_selection_applies_revision_tag_after_head` first. The stub genuinely calls the existing Lens for HEAD, decodes RA, then erroneously queries `TAG(File F, approved)`. The fixture really signed `TAG(RA, approved) -> F`. Thus `a.revisionTag.present` should fail with **approved belongs to selected RA, not File F**. This is a wrong-subject behavioral failure, not a hardcoded false, empty return, or compiler error. Do not change the assertions to accommodate it.

The stub also leaves supplied basis unchecked and consumes incomplete folder pages without rejecting. Those are explicit not-yet-implemented paths covered by the tests, not claimed-safe consumer behavior. Correct current-basis guards, exact descriptor/Record/parent/File validation and complete-window qualification will be implemented only after root reports meaningful actual RED.

### Test inventory and intended breaks

1. `test_point_selection_applies_revision_tag_after_head`: selected RA approval versus RB absence, persistent File project tag under both lenses, and no inherited RA approval after RR.
2. `test_conflict_preserves_both_exact_revisions`: no-tiebreak conflict retains both exact decoded revisions and binding provenance; reverse lens retains both.
3. `test_complete_one_page_folder_tag_join_is_not_point_evidence`: independently qualified complete/exhausted context, both File-project results, Alice-only selected approval, and post-RR absence without losing project membership.
4. `test_partial_stale_and_wrong_index_reads_fail_closed`: zero-budget nonempty folder, stale admission, generation, epoch, Core, detached index and replaced index.
5. `test_reader_rechecks_parent_and_scope_coverage`: real admin metadata downgrades produce E_INCOMPLETE without assuming a generation/admission change.
6. `test_absent_masked_and_wrong_target_tags_remain_qualified`: root decoding, absent/masked HEAD has no evaluated selected-revision tag, exact wrong-target FOUND is not positive, masked revision tag keeps MASKED.
7. `test_reader_rejects_nonprofile_and_wrong_file_selected_records`: a selected unrelated Type or another File's valid Root cannot become this File's result.

All fixture actions use the existing genuine Alice signed path or Bob contract Actor. No new mock is used. The result shape exposes `TagScope.File` / `TagScope.SelectedRevision`, exact tag subject/target, raw Lens status, evaluated flag and positive predicate. Conflict has candidate-specific Revision objects but deliberately no overall selected revision/tag. Folder results retain status, mutation flag and next cursor, besides joined File points.

### Checks actually performed

- Read actual Ledger, LensReader, FilesParentIndex, IndexModule, TypeRegistry and LabBase APIs.
- `git diff --check`: exit 0, no output.
- `git diff --stat`: existing test file +208 lines, no deletions (new untracked consumer is not counted by git diff).
- Profile and Ledger SHA256 still match frozen required values below.
- No actual RED or GREEN yet; root must supply both. Source plausibility review is not compilation evidence.

### Source hashes at REDREADY

| File | SHA256 |
|---|---|
| FilesJoinedConsumer.sol | bc9063f950f96d4797cb94e579d67cd1edad026ff7c265240caee257de1f4c78 |
| FilesJoined.t.sol | f51fd9aaccd9edbf4d4d48e03e53a73826bed5b7036efbf182f75c5b3117a547 |
| FilesJoinedProfile.sol, unchanged | c701bf700c122d0c1fd0c3f6b51630c3c0b9bdb6902e0975b8b6a3095cf43cdf |
| Ledger.sol, unchanged | 7576874b52a81ebc0f7b64640332b345096e0c09000ed4f09811bdc21dd6c3d5 |

### Concerns / scope

- This is intentionally unsafe RED-stage source. Do not publish it as completed behavior before GREEN.
- Seven additive tests make 15 FilesJoined tests total; test contract init/runtime size is a root gate, not estimated here.
- Parent query is not added: Task 1 owns count-bounded parent membership checks; zero out-of-range default must never be interpreted as a child.
- Current full document reads are distinct from the Task 1 bounded header validator; no gas optimization claim.
- No browser, global tag discovery, arbitrary churn, historical native portable source proof, multi-page cross-transaction coherence, filename reconstruction, move/reused-path/whiteout integration, production API or full current application-policy validity is earned by this slice.
- Daily status and any publication metadata remain controller-owned under the explicit exact-file ownership split.

## Actual root RED and GREENREADY implementation

Root unlocked implementation after successful solc 0.8.30 compilation and actual behavioral RED. I read the retained root JSON/log (read-only; no compiler rerun). Run began 2026-09-14 10:58:51 UTC, with frozen source digest `dba60770e41ca872d7b6679b3b009db0d61da6cbf84639f564489b25a0c12eb2`; root reported cleanup/slot release at 10:59:00 UTC. Evidence paths:

- `/tmp/efs-b-archive-task1.OXPOfb/files-task2-red.json`
- `/tmp/efs-b-archive-task1.OXPOfb/files-task2-red.log`
- `/tmp/efs-b-archive-task1.OXPOfb/files-task2-red.source/test/FilesJoined.t.sol`

Root's recorded command was `/Users/james/.foundry/bin/forge test --use '/Users/james/Library/Application Support/svm/0.8.30/solc-0.8.30' --offline --root /tmp/efs-b-archive-task1.OXPOfb/files-task2-red.source --config-path /tmp/efs-b-archive-task1.OXPOfb/files-task2-red.source/foundry.toml --build-info --build-info-path /tmp/efs-b-archive-task1.OXPOfb/files-task2-red.state/build-info -vv --match-contract FilesJoinedTest`.

Actual RED: 15 cases, 9 PASS / 6 FAIL; all eight Task 1 tests and the conflict control passed. The point test failed **approved belongs to selected RA, not File F**. Folder approval and root draft also failed, plus three fail-closed tests. This confirms a behavioral wrong-subject failure after valid compilation. Compiler output also carried existing Keys shadowing warnings and a large test-orchestrator initcode warning; root separately owns normal component runtime/init sizes.

### Deliberate requirement/test correction before GREEN

Root amended the task brief after an independent lifecycle review: exact HEAD/Record/parent-by-ID reads do **not** consume reverse-parent enumeration, so the consumer must not require parent-family COMPLETE to answer an exact point/conflict query. Scope-family COMPLETE still gates folder enumeration. Parent completeness gates Task 1's parent-discovery helper, not a new public query added just for testing.

I read the amended Worker operating contract and changed only the parent-downgrade portion (and its explanatory comment) of `test_reader_rechecks_parent_and_scope_coverage`. The revised test preserves the folder-rejection assertion, establishes a real approved RA point control, downgrades parent-family metadata, checks coverage is honestly PARTIAL, then verifies the entire exact point result remains unchanged. The other six Task 2 tests and eight Task 1 tests remain unchanged versus root's frozen RED snapshot. A direct `diff -u` against that snapshot confirms this one localized correction. Therefore **the whole test file is deliberately not byte-identical to RED**; this is an authorized evidence-consumption correction, not an assertion changed to make the wrong-subject implementation pass.

### Implemented consumer behavior

- Constructor pins Ledger, Lens, index, deployed runtime hashes, Root/Child Type IDs and reviewed mandatory rule hashes; verifies immutable Core/Lens/index agreement and exact profile descriptors, ref cardinality/zero wildcard, recomputed Type IDs, runtime rule codehashes and Child rule's immutable Root configuration.
- Every public read checks active module binding, unchanged pinned runtimes, current admission frontier, index generation, registry epoch and Core commitment. Profile checks run again at read time. No historical point request is silently accepted.
- HEAD is resolved before decoding and tag reads. Only FOUND selects/decodes a revision; absent/masked/conflict preserve point status and leave revision-tag evaluation unset. File tags always retain their exact subject and raw status. Positive tag means FOUND and exact target == File; selected-revision tags query the selected Record, not File F.
- Exact selected Record reads check admitted Type, nonzero/count-bounded first admission, retained occurrence count, full-body-derived ID, first publication's hash/Type, profile prefix length/body maximum, exact existing File Subject and parent word. Child parents are checked with the frozen bounded header adapter (masked first admission, exact Root/Child Type, appropriate File word, minimum length, earlier admission). This does not fetch/revalidate the full ancestor chain or imply current mutable-policy validity.
- No-tiebreak preserves every returned candidate, exact decoded revision and binding provenance; there is no fabricated overall selected revision/tag.
- Folder reads use an all-zero fresh cursor, require scope-family COMPLETE from 1 through current admission, then verify page COMPLETE, !mutated, exhaustion, exact cursor context and matching fresh-page totals. Each selected entry is checked as a real Folder binding targeting an existing File Subject, then its HEAD is selected/validated before the requested tag tier is applied. Defects are not silently skipped. Proven absent/masked HEAD cannot become a verified selected File merely from a File tag; conflict rejects E_INCOMPLETE.

### GREENREADY self-review and verification status

- No compiler/Forge/solc/Anvil/RPC or git writes were run by this worker.
- `git diff --check`: exit 0, no output.
- Read the full resulting consumer source; corrected an unnecessary second-word read on a minimal Root so the memory-safe assembly never reads beyond its validated header.
- Frozen profile and Ledger source hashes remain unchanged.
- GREEN is **not yet observed by this worker**. Root owns the next targeted/full-suite/size gates. Status is GREENREADY, not DONE.
- Root's review base is `eda7a0c`, excluding independently owned packet/diagnostic commits that landed during this task.

### Source hashes at GREENREADY

| File | SHA256 |
|---|---|
| FilesJoinedConsumer.sol | faf1e68e5dc92d56da6d39a7893ec0f7d4b06f13e04678ee04a62655c803005d |
| FilesJoined.t.sol, one authorized test correction from RED | b6ec66994aae4d577ec8ba2997e70b345c609127ea52cf07a0b758540b7319d5 |
| FilesJoinedProfile.sol, unchanged | c701bf700c122d0c1fd0c3f6b51630c3c0b9bdb6902e0975b8b6a3095cf43cdf |
| Ledger.sol, unchanged | 7576874b52a81ebc0f7b64640332b345096e0c09000ed4f09811bdc21dd6c3d5 |

Remaining limits are unchanged: no browser/full Files journey, no global tag discovery, no cross-transaction/multipage consistency, no historical native source proof, no move/reused-path/whiteout integration, no production adoption and no paid gas claim. Normal consumer sizes and actual GREEN are controller gates still pending.

## Root observed GREEN addendum

Root read the actual `files-task2-green.json` and `.log`: full suite 118/118,
all 15 Files tests PASS, no failures or skips. Source digest
`fa835e9bd780d3ab627d57fdc86d375d3b70adcda8fad09f4fce8c7234cbbc11` matches
the frozen GREENREADY files; Core/profile unchanged. The root wrapper stopped
all owned processes and released the slot at 11:06:48 UTC. Normal size gate
is now running at the same input; review/publication remain root-owned.

Root observed normal size PASS at that same source digest, cleanup/slot release
11:08:06 UTC. FilesJoinedConsumer runtime/initcode: 15,896/20,007 bytes;
FilesParentIndex 5,287/8,724; unchanged Ledger 17,280/17,670. The test harness
is not deployable under normal initcode limits; these named actual components
are within normal limits. No paid transaction or general read-cost claim.

Root committed exactly the consumer and additive tests at
`d54a1208b3e014f0eede9697992ce12e3620b638`. Independent review
`/tmp/efs-b-files-joined-task2-review-20260914.md` is spec compliant and Approved,
no Critical/Important findings. It specifically agrees with the point-versus-
enumeration correction. Task 1 dependencies retain their own reviewed evidence;
Task 3 and broader journey are not asserted complete. Minor compiler/lint and
test-only harness warnings remain disclosed. Task 2 is complete for its scope.
