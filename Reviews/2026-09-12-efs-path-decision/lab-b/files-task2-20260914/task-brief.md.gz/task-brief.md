# Joined FileRevision experiment implementation plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development. Root owns compilation, measurement, review and exact-path publication. This executes James's existing overnight disposable-prototype mandate, not a production API decision.

**Goal:** demonstrate real checked file parentage and head-first revision tags on compact B's existing kernel.

**Architecture:** Root and Child revision Types carry arbitrary document bytes and a stable File Subject. Mandatory rules enforce same-File parents through bounded reads. A separate required index retains exact parent backlinks; an unrelated consumer composes current Lens selection with explicitly qualified tag reads.

**Tech Stack:** Solidity 0.8.30, viaIR, optimizer 200, Cancun; installed Forge, no new dependencies. Existing isolated `planning-warroom-b-run`, lab path `Reviews/2026-09-12-efs-path-decision/lab-b/`.

**Spec:** [[files-next-joined-gate-20260914]] and [[files-journey]]. This plan implements only the real parentage/selection slice, not the entire Files journey. Source-only preflight found the existing APIs sufficient with the explicit qualifications below.

## Global constraints

- Disposable test profile only. No Ledger, Keys, Registry, IndexModule, LensReader, LabBase, archive, existing diagnostic, SDK, production repository, migration or protocol change.
- Existing Ledger SHA256 `7576874b52a81ebc0f7b64640332b345096e0c09000ed4f09811bdc21dd6c3d5`; body maximum 8,192 bytes and mandatory-rule gas 300,000 remain unchanged.
- Root body = File ID word 0 plus arbitrary bytes; Child = parent Record ID word 0, File ID word 1, arbitrary bytes. Root minimum 32, Child minimum 64. Both File IDs must be nonzero, existing Subjects. Child descriptor has exactly one checked reference `[bytes32(0)]`; the mandatory rule narrows parent Type to pinned Root or the incoming Child Type, and enforces same File.
- Storage-layout helper is test-only and coupled to the pinned Ledger: record mapping slot 2, meta at base+1; body-word mapping slot 3. `first = uint64(meta & ((uint256(1)<<48)-1))`; `length = uint32(meta >> 48)`. Never infer length from unmasked meta or read the entire parent to validate its header.
- Alice is `eoaA`/PK_A through genuine `executeSigned`; Bob is `address(bob)` through genuine `Actor.execute`. No forged contract signature or helper that substitutes its own authorship. Historical native source proof remains unsupported.
- Exact root/child shapes, descriptors, rule codehashes and Child's configured Root Type must be checked by the Files profile. A length check is not proof of a profile. Callbacks remain mandatory and atomic; retained membership is not current validity.
- COMPLETE parent-family coverage means the exact pinned module's declared family is gap-free, from admission 1 through the current basis, plus exhaustion of a parent's count-bounded list. Generic `coverage` ignores its scope argument; never claim independently maintained per-parent coverage.
- All point/tag/folder composition occurs at current state in one EVM call with supplied frontier, rule epoch, index generation and Core commitment checked. PARTIAL, UNKNOWN, stale basis and conflict do not become empty success.
- Root one-heavy-slot only, finite watchdog, installed/pinned toolchain, private caches; 50 GiB free reserve and 15 GiB aggregate scratch. No worker compiler, Anvil, RPC or subagent launch. Stop before September 14 14:00 UTC / 09:00 Chicago.
- Each task hands a compiling stub plus unchanged executable assertions to root for real behavioral RED before implementation. Compilation errors are not RED. Root commits only exact task files after GREEN and reviews; designs/reports stay on main. Previously passing measurements are not repeated without a source/semantic reason.

## File responsibilities and shared fixture

`test/FilesJoinedProfile.sol`: pinned raw header helper, mandatory Root/Child acceptors and exact Files-parent index. `test/FilesJoined.t.sol`: integration fixture and assertions, extending existing LabBase. Task 2 adds `test/FilesJoinedConsumer.sol` for unrelated qualified reads. Three files keep acceptance/indexing, test orchestration and consuming behavior separate.

Fixture: `R0=Root(F,"Meeting at 10:00.\n")`; `RA=Child(R0,F,"Meeting at 11:00.\n")`; `RB=Child(R0,F,"Meeting at 09:00.\n")`; `RR=Child(RA,F,"Meeting at 10:00.\n")`. Derive exact IDs with `Keys.recordFromHash(typeId,keccak256(fullBody))`. RR differs from R0 despite equal document bytes.


## Task 1 handoff (reviewed, frozen)

Task 1 base af5764a..9fdee5e is independently approved. Core unchanged. All 8 Task 1 tests passed in root's 110-test full suite; do not alter their executable assertions. FilesParentIndex exposes rootType, childType, expectedRootRuleHash, expectedChildRuleHash and FAMILY_FILES_PARENT. The test fixture's helpers/state are internal. Exact profile SHA256 c701bf700c122d0c1fd0c3f6b51630c3c0b9bdb6902e0975b8b6a3095cf43cdf. FilesJoined.t.sol before Task2 SHA256 1043bddc8293fa0b0f5205e1a42ed17e5d7edc55bb8a5abfd715d0ff16ce2c13.

Separate IndexConfigExpectation.t.sol is root-owned and not part of this task; do not modify it. Its characterization shows admin metadata downgrade may not invalidate pending signatures. Your consumer must check coverage and binding at read time; do not repair index/Core inside Task2.

## Worker operating contract

### Root correction before GREEN: qualify only the evidence actually consumed

Source-only independent lifecycle analysis agreed with root: exact current
HEAD/Record/parent-by-ID reads do not consume reverse-parent enumeration and
must not require FAMILY_FILES_PARENT COMPLETE. Keep active module/profile/Basis
pins and direct parent validation. Require scope COMPLETE for the folder list;
require parent COMPLETE only when enumerating parents (Task1's checked helper).
Change only the overly strict parent part of
`test_reader_rechecks_parent_and_scope_coverage`: prove a parent-family metadata
downgrade leaves the exact point result unchanged, while reverse-parent coverage
is honestly PARTIAL. Scope downgrade must still reject folder enumeration.
Do not add a public parent-query API just for this correction; a test asserting
PARTIAL does not claim an executed consumer denial. All other executable tests
stay unchanged. Explicitly disclose this deliberate requirement/test correction
in the report; do not call all seven tests byte-identical to original RED.

This is an availability/cost and semantic-scope correction, independently
reasoned from the actual read path, not an assertion changed to accommodate a
broken implementation. Root already observed the meaningful wrong-subject RED;
correct that consumer ordering and retain its original tests unchanged.

You own ONLY FilesJoinedConsumer.sol, additive changes to FilesJoined.t.sol and the assigned task-2-report.md. No git writes/commit/push, compiler/Forge/solc/Anvil/RPC, dependency installs or subagents. Root owns finite frozen runs and publication. Read actual APIs before inventing signatures. Produce a compiling behavioral stub + real tests, then stop REDREADY for root; root must observe meaningful RED before corrected implementation. Address compile errors as compile errors, not TDD results. Parent membership checks may live in tests already; do not add a public query merely because a generic guard is mentioned. Exact result qualification matters more than convenience.

### Task 2: Qualified head-first revision tags and one folder window

**Files:** create `test/FilesJoinedConsumer.sol`; modify `test/FilesJoined.t.sol` only. Consume Task1 profile/fixture without changing its validation/index semantics.

**Interfaces:** `FilesJoinedConsumer` constructor pins `Ledger`, `LensReader`, `FilesParentIndex`, Root/Child Types and profile hashes. `Basis` contains `uint64 admission`, `uint64 generation`, `uint64 epoch`, `bytes32 core`. `readFilePoint(bytes32 file,address[] lens,bytes32 concept,Basis basis)` returns a typed result containing point status, selected Record/Type/parent, File ID, document bytes/hash and separate File-tag/revision-tag assessments. Each assessment carries its exact subject and an explicit evaluated/status field; a missing selected revision must not be encoded as an evaluated false tag. `readFileConflict` uses `resolveNoTiebreak` and decodes every returned candidate without inventing an overall selected-revision tag. `TagScope` is an enum with `File` and `SelectedRevision`, not a boolean. `readFolderTaggedOnce(bytes32 folder,address[] lens,bytes32 concept,TagScope scope,uint256 budget,Basis basis)` returns selected verified file results only after complete/end/context checks. It never returns an unqualified empty array for an incomplete source. Use `E_BASIS`, `E_INCOMPLETE` and `E_PROFILE` rather than silently skipping defects.

- [ ] Add compiling consumer stub and behavioral tests. First demonstrate a failing expected result from applying `approved` to File F instead of the selected revision; root observes RED before the corrected read order. Tests require L-A `[eoaA,address(bob)]` selects RA with File tag yes and approved yes, L-B reversed selects RB with File tag yes and approved no; no-tiebreak yields CONFLICT with both exact candidates retained. After RR, Alice-first keeps the File tag but no longer inherits approved(RA).
- [ ] Implement current-basis guard and exact Record/body/Type/ID/File/parent decoding, then tag resolution **after** HEAD selection. Required order:

```solidity
(uint8 status, bytes32 selected,,,) = lensReader.resolve(authors, HEAD, file, bytes32(0));
// Preserve ABSENT/MASKED/CONFLICT, and decode only a FOUND exact profile Record.
(uint8 fileTag, bytes32 fileTarget,,,) = lensReader.resolve(authors, TAG, file, concept);
(uint8 revisionTag, bytes32 revisionTarget,,,) = lensReader.resolve(authors, TAG, selected, concept);
// A positive hit requires FOUND and target == file, never mere nonzero state.
```

Use constants matching LabBase's HEAD/FOLDER/TAG domains. Point `resolve` has no historical parameter: reject any supplied admission not equal to current counts. Require exact active index, immutable Lens/index agreement, epoch, generation and Core commitment. Current inline byte reads may cost more than bounded validators; do not label this as a gas optimization.

SDK PM's September14 bounded review prompted the explicit scope/status refinement
before Task2 implementation. The eventual SDK should expose named `onFile` and
`onSelectedRevision` operations and generated checked bounded-read adapters;
no public raw-slot API or production result enum is adopted by this test plan.

- [ ] Implement the separate one-window folder join using an all-zero fresh cursor. Require COMPLETE, !mutated, `next.lensIndex==authors.length`, `next.rawIndex==0`, exact next basis/generation/epoch/Core/lensHash/scopeKey, and scope-family coverage from1 through current admission. `scopeKey=keccak256(abi.encode(FOLDER,folder))`. Resolve each selected File HEAD before applying the requested tag tier. In the one-entry fixture, project_efs returns F under both ordered lenses; approved returns F only under Alice-first before RR. A zero-budget nonempty folder is PARTIAL and must fail `E_INCOMPLETE`, not appear empty. A stale basis and detached/replaced index fail closed. Parent lookup requires ordinal<count and nonzero valid admission; zero default posting is not a child.
- [ ] Root observes targeted GREEN, complete B suite and normal runtime/init sizes. Retain source hashes, full logs, semantic limits and any newly actionable failures. Review and publish exact paths. Paid read/write pricing is a separately bounded follow-up only if it can compare useful work at an explicit source pin; Forge test gas is not an ordinary transaction receipt.

Minimum tests: `test_point_selection_applies_revision_tag_after_head`, `test_conflict_preserves_both_exact_revisions`, `test_complete_one_page_folder_tag_join_is_not_point_evidence`, `test_partial_stale_and_wrong_index_reads_fail_closed`. Existing Task1 tests must remain passing without changing their executable assertions to accommodate the reader.

## Completion and exclusions

This earns local checked revision chains, retained parent discovery, signed/native authorship separation, competing current selection, explicit tag tiers and one exhausted folder window. It does not earn global tag discovery, arbitrary churn, multi-page cross-transaction coherence, native portable proof, cold filename reconstruction, move/reused-path/whiteout integration, a working browser, or production readiness. Those broader existing journey gates stay open, with their next discriminating test named rather than silently waived.
