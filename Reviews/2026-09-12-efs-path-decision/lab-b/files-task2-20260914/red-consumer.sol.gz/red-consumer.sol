// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;

import {Ledger} from "../src/Ledger.sol";
import {LensReader} from "../src/LensReader.sol";
import {FilesParentIndex} from "./FilesJoinedProfile.sol";

/// Disposable unrelated Files consumer. RED-stage behavioral stub, not production code.
contract FilesJoinedConsumer {
    bytes32 private constant HEAD = keccak256("efs2/purpose/head/1");
    bytes32 private constant FOLDER = keccak256("efs2/purpose/folder/1");
    bytes32 private constant TAG = keccak256("efs2/purpose/tag/1");

    enum TagScope { File, SelectedRevision }
    struct Basis { uint64 admission; uint64 generation; uint64 epoch; bytes32 core; }
    struct TagAssessment { bytes32 subject; bytes32 target; uint8 status; bool evaluated; bool present; }
    struct Revision {
        bytes32 recordId;
        bytes32 typeId;
        bytes32 parent;
        bytes32 file;
        bytes document;
        bytes32 documentHash;
    }
    struct FilePoint {
        uint8 status;
        bytes32 file;
        Revision revision;
        TagAssessment fileTag;
        TagAssessment revisionTag;
    }
    struct ConflictCandidate { LensReader.Entry binding; Revision revision; }
    // Deliberately no overall selected revision or overall revision-tag assessment.
    struct ConflictResult { uint8 status; bytes32 file; TagAssessment fileTag; ConflictCandidate[] candidates; }
    struct FolderResult { uint8 status; bool mutated; LensReader.Cursor next; FilePoint[] files; }

    Ledger public immutable ledger;
    LensReader public immutable lensReader;
    FilesParentIndex public immutable filesIndex;
    bytes32 public immutable rootType;
    bytes32 public immutable childType;
    bytes32 public immutable expectedRootRuleHash;
    bytes32 public immutable expectedChildRuleHash;

    error E_BASIS();
    error E_INCOMPLETE();
    error E_PROFILE();

    constructor(Ledger ledger_, LensReader lens_, FilesParentIndex index_, bytes32 rootType_, bytes32 childType_,
        bytes32 rootHash_, bytes32 childHash_)
    {
        ledger = ledger_;
        lensReader = lens_;
        filesIndex = index_;
        rootType = rootType_;
        childType = childType_;
        expectedRootRuleHash = rootHash_;
        expectedChildRuleHash = childHash_;
    }

    function readFilePoint(bytes32 file, address[] calldata authors, bytes32 concept, Basis calldata)
        external view returns (FilePoint memory)
    {
        return _point(file, authors, concept);
    }

    function _point(bytes32 file, address[] calldata authors, bytes32 concept) private view returns (FilePoint memory result) {
        result.file = file;
        bytes32 selected;
        (result.status, selected,,,) = lensReader.resolve(authors, HEAD, file, bytes32(0));
        result.fileTag = _tag(authors, file, concept, file);
        if (result.status == 1) {
            result.revision = _decode(selected);
            // Intentional RED footgun: real wrong-subject query, not a hardcoded answer.
            result.revisionTag = _tag(authors, file, concept, file);
        }
    }

    function _tag(address[] calldata authors, bytes32 subject, bytes32 concept, bytes32 file)
        private view returns (TagAssessment memory result)
    {
        result.subject = subject;
        result.evaluated = true;
        (result.status, result.target,,,) = lensReader.resolve(authors, TAG, subject, concept);
        result.present = result.status == 1 && result.target == file;
    }

    function _decode(bytes32 selected) private view returns (Revision memory result) {
        bytes memory body;
        result.recordId = selected;
        (result.typeId,,, body) = ledger.record(selected);
        uint256 prefix = result.typeId == rootType ? 32 : 64;
        if (body.length < prefix) revert E_PROFILE();
        bytes32 first;
        bytes32 second;
        assembly ("memory-safe") { first := mload(add(body, 32)) second := mload(add(body, 64)) }
        result.file = prefix == 32 ? first : second;
        result.parent = prefix == 32 ? bytes32(0) : first;
        result.document = new bytes(body.length - prefix);
        for (uint256 i; i < result.document.length; ++i) result.document[i] = body[prefix + i];
        result.documentHash = keccak256(result.document);
    }

    function readFileConflict(bytes32 file, address[] calldata authors, bytes32 concept, Basis calldata)
        external view returns (ConflictResult memory result)
    {
        result.file = file;
        LensReader.Entry[] memory candidates;
        (result.status, candidates) = lensReader.resolveNoTiebreak(authors, HEAD, file, bytes32(0));
        result.fileTag = _tag(authors, file, concept, file);
        result.candidates = new ConflictCandidate[](candidates.length);
        for (uint256 i; i < candidates.length; ++i) result.candidates[i] = ConflictCandidate(candidates[i], _decode(candidates[i].target));
    }

    function readFolderTaggedOnce(bytes32 folder, address[] calldata authors, bytes32 concept, TagScope scope,
        uint256 budget, Basis calldata) external view returns (FolderResult memory result)
    {
        LensReader.Cursor memory fresh;
        LensReader.Page memory page = lensReader.list(authors, FOLDER, folder, fresh, budget);
        result.status = page.status;
        result.mutated = page.mutated;
        result.next = page.next;
        result.files = new FilePoint[](page.items.length);
        uint256 count;
        for (uint256 i; i < page.items.length; ++i) {
            FilePoint memory point = _point(page.items[i].target, authors, concept);
            bool present = scope == TagScope.File ? point.fileTag.present : point.revisionTag.present;
            if (point.status == 1 && present) result.files[count++] = point;
        }
        FilePoint[] memory selectedFiles = result.files;
        assembly ("memory-safe") { mstore(selectedFiles, count) }
    }
}
