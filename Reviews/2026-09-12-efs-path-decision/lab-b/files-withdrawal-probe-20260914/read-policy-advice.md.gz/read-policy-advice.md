# Files withdrawal read policy — bounded design advice

2026-09-14. Source/design review only. No Core, consumer, SDK, test, measurement,
Git or process changes. The three actual withdrawal characterizations are a
separate worker's task; this report does not claim their execution results.

## Recommendation

**Choose B for the ordinary retained Files reader:** return the exact selected,
well-formed, retained revision. Treat occurrence maintenance as a separate,
basis-qualified fact, not part of the Type/profile-integrity predicate and not
an automatic reason to select another author's HEAD.

Removing the `occurrences == 0` branch from this prototype's E_PROFILE guard is
a small correction toward the existing intended retained-read semantics. It
does not need a James requirements waiver: it drops no current-count obligation,
changes no Core WITHDRAW meaning, grants no authority and weakens no exact
Type/body/parent verification. It still needs an explicitly scoped corrective
regression, review and truthful API description after the characterizations.
This recommendation is not permission to freeze a production API or silently
decide that every application must display withdrawn content.

The minimum correction can keep the present result shape: the function promises
selected retained data, not current publication maintenance. If maintenance is
exposed or used to decide display, keep that fact bound to the exact Record,
Realm, observation basis and, where applicable, particular author/Occurrence.
It must not be fetched later and silently combined with a value at another
basis. No new public enum or whole-SDK redesign is needed to demonstrate this.

## Current source and authority

Code references below resolve under
`/Users/james/Code/EFS/planning-warroom-b-run/Reviews/2026-09-12-efs-path-decision/lab-b/`.
Design references resolve under `/Users/james/Code/EFS/planning/`.

- `src/Ledger.sol:691–718`: WITHDRAW targets the author's own PUBLISH/REUSE,
  sets that occurrence's withdrawn bit and decrements the aggregate counter.
  Bytes and other authors' occurrences are untouched; HEAD is not tombstoned.
  `:557–574` increments that counter for subsequent PUBLISH/REUSE. The number is
  **active occurrences, not distinct maintainers, replicas or trusted authors**.
- `test/FilesJoinedConsumer.sol:131–143,155–165`: HEAD selection precedes decode
  and tag assessment. The decoder currently treats zero aggregate occurrences
  as E_PROFILE alongside wrong Type, hash or shape. `:196–208` applies the same
  decoder to every conflict candidate; `:212–242` applies it before filtering
  each complete folder placement. Hence this condition can fail an entire
  conflict/folder response, not merely annotate one File.
- `src/Ledger.sol:512–545,604–609` and
  `test/FilesJoinedProfile.sol:44–54`: retained Record existence, reuse, checked
  references and the same-File parent predicate are not positive-occurrence
  predicates. `test/FilesJoinedConsumer.sol:186–193` follows that retained-parent
  interpretation. The selected-record guard is the inconsistent extra coupling.
- `Designs/efsv2/core-architecture-candidate.md:275–277` defines withdrawal as
  ceasing to maintain an authored Occurrence, not Record deletion, another
  issuer's retraction or Binding rewind. Its header is **draft, buildable
  comparison target, not frozen protocol**, and explicitly says prototype
  shortcuts do not define the candidate.
- `Designs/efsv2/hierarchical-files-and-folders.md:108–123` carries that boundary
  into Files: Withdrawal is carriage/authorship lifecycle, not application
  deletion. Its status is **review / converged semantic proposal**, with exact
  bytes and measured limits evidence-gated; it is explicitly not an owner ruling.
- `Designs/efsv2/programmable-type-acceptance.md:178–190,191–206` separates
  application-effective actions from graph references and carriage withdrawal.
  Reading distinguishes decoding, historical acceptance, current effectiveness
  and consumer trust. It is a **draft recommended comparison target**, not an
  adopted permanent ABI. Ordinary reads inspect retained acceptance evidence;
  they do not re-run arbitrary developer policy.
- `Designs/efsv2/system-constitution.md:162–170` preserves append-only history,
  prior bytes and no unexpected resurrection. It is a **draft synthesis of
  owner-ratified direction**, subordinate to attributed owner rulings.
- `Designs/efsv2/owner-rulings.md:169–205` is the adopted August12 greenfield
  boundary: current counts and full state-readable bodies/exact-ID reads both
  remain obligations. It does **not** rule that zero aggregate occurrences makes
  retained data malformed. Keeping the count while removing the read-integrity
  gate preserves both obligations.
- `Designs/efsv2/owner-decision-inbox.md:10–22` directs engineering to prototype
  and return only choices evidence cannot settle, without asking for permanent
  Type, carrier or scope decisions merely to run a reversible experiment.

The newer `files-withdrawal-probe-plan-20260914.md` freezes three existing-behavior
characterizations and expressly excludes a fix. This advice is the proposed
next corrective policy, not an amendment to those tests while they are running.

## A / B / C comparison

| Option | What it says | Consequence |
| --- | --- | --- |
| A — current E_PROFILE | At least one active occurrence is necessary for a selected Record to count as a valid Files profile. | Misclassifies well-formed retained data. One zero-count candidate can fail a whole folder/conflict. An unrelated author's REUSE can restore Alice's display without restoring her withdrawn occurrence. Not recommended. |
| B — retained selected bytes; maintenance separate | Identity, retained acceptance and HEAD selection remain readable. Current maintenance is another fact when relevant. | Smallest coherent default; agrees with parent/reference semantics and stable history. Does not certify current endorsement, availability or application effectiveness. Recommended. |
| C — explicit not-maintained variant | A named read policy treats maintenance as an additional requirement, with a distinct qualified outcome. | Can be useful for an explicitly maintenance-filtered product view. If it still returns the exact bytes plus a maintenance fact, it is essentially B with presentation. If it withholds bytes based on the global count, Bob's REUSE still toggles Alice's result and the policy remains unsuitable as selected-author authority. |

C should not become a new mandatory universal state merely because A uses the
wrong error. Before a product intentionally hides content, name whose claim
must be maintained, for which purpose and at what basis. The global aggregate
count cannot answer “does Alice still stand behind this?” or “is this award
still valid?” A specific issuer revocation/renewal policy can answer those
application questions; generic carriage withdrawal cannot replace it.

## Footguns the minimal policy must avoid

1. **Do not call a count “maintainers.”** One author may contribute multiple
   active occurrences; an untrusted party can also publish/reuse. Count1 proves
   neither one independent custodian nor one trusted endorsement. Zero describes
   no active counted occurrences on this Realm at this basis; it does not mean
   bytes are physically unavailable, erased, false or malformed.
2. **Bob cannot undo Alice's withdrawal.** Bob's REUSE creates Bob's live
   occurrence and increases the aggregate. Alice's withdrawn bit stays set;
   Alice's unchanged HEAD remains a separate authored Binding. Under B the exact
   selected file is readable before and after Bob acts, so neither apparent
   disappearance nor resurrection is attributed to him. A lifecycle/authority
   inspector must retain the distinction between Alice and Bob.
3. **No silent fallback.** Removing the zero-count profile guard does not change
   Lens order, masks, conflicts or unknown-data behavior. If Alice's placement
   is tombstoned, Bob's lower-priority placement remains masked. If bytes are
   actually unavailable or corrupt, do not substitute another revision merely
   because it is readable. Properly qualified failure still matters.
4. **Reduce only this false folder failure.** B stops a well-formed zero-count
   entry from poisoning the folder or conflict inspection. It does not justify
   skipping genuinely malformed/unsupported entries and claiming COMPLETE.
   A future per-entry diagnostic folder API may be useful, but that is outside
   this smallest correction and must preserve coverage and candidate evidence.
5. **Do not upgrade reading into authority.** A retained accepted outfit can be
   inspected after withdrawal; that does not authorize a fresh equip action.
   A retained contract config can be read; that alone does not prove an
   application's required current issuer/lifecycle policy. Keep “accepted under
   the named historical rule” narrower than “effective and trusted now.”

## Two ordinary-user examples

**A meeting note.** Alice's `meeting.txt` selects the11:00 revision. She later
withdraws that revision's publication occurrence but does not change the file's
HEAD or folder placement. The bytes still say11:00 and still pass the exact
profile. Ordinary Files should keep opening that selected revision, with the
withdrawn-publication fact available where relevant. It should not break the
whole folder. Bob retaining/reusing those same bytes must not make the note
magically disappear and reappear for Alice. If Alice wants the note removed
from her folder, the ordinary remove/mask operation is the relevant action.

**A photo in two albums.** A retained beach photo is placed in “Vacation” and
“Family.” Its uploader stops maintaining their publication; that does not make
the photo's image bytes malformed or delete both album entries. Those entries
and any exact-image tags remain facts that can be inspected. If Alice instead
removes the photo from her Vacation overlay, her placement mask still hides it
there—even if Bob republishes the image or keeps his own album entry. Another
album can continue referencing the same exact image without rewriting history.

## What requires James, and what does not

No immediate James decision is needed to correct a reversible retained-data
reader so zero active occurrences no longer means E_PROFILE. The surrounding
drafts already distinguish the facts, and the adopted boundary preserves both
readable bodies and accurate current counts. Report the correction and its
evidence; do not characterize it as sacrificing validation or revocation.

A genuine product choice remains if the proposed default is instead “hide
otherwise-selected retained bytes whenever a chosen author stops maintaining
a particular claim,” or if withdrawal is to rewind/remove placement bindings.
That changes what users mean by withdrawal/removal and which authority controls
their view. `Designs/efsv2/testnet-files-mvp-plan.md:167–178` proposes an advanced
placement-claim withdrawal allowing fallthrough, separately from Trash/masking;
compact B kind6 rejects BIND targets and does not implement it. Do not smuggle
that different operation into the zero-count reader correction. Keep it as a
named, evidence-led product/design discussion rather than ask James to decide
the present error-code bug.

For the next scoped implementation: retain the old characterization packet,
write a corrective regression expecting exact retained point/conflict/folder
results at count0, keep actual masks and malformed-profile failures unchanged,
and prove Bob's REUSE changes maintenance facts but not the selected bytes or
Alice's withdrawn status. Only then remove the aggregate-count condition from
the profile guard. No Core mutation, count removal, public SDK enum, global
fallback rule or production freeze follows from this advice.
