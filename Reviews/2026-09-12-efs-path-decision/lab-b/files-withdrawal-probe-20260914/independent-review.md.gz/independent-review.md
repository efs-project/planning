# Files withdrawal probe: independent review

Final execution-linked verdict: **Approved**. Root's focused frozen gate passed all three new cases. No Critical or Important findings in the bounded assigned scope; one nonblocking wording note is recorded below.

Reviewed the full withdrawal-probe plan, full new test file, full implementation report, and relevant actual Ledger, IndexModule, Files profile/consumer, Actor and inherited fixture helpers. No unrelated design expansion, compiler, Forge, Anvil, RPC, git mutation or subagent. Only this review report was written.

## Exact reviewed inputs and preservation

New FilesWithdrawal.t.sol SHA256: `c37a3c81a5a77801310d627987dbbc9cb3126f14ce4002a6767b8f0eab12be6f`.

Read-back confirmed the unchanged implementation/support pins:

- Ledger: `7576874b52a81ebc0f7b64640332b345096e0c09000ed4f09811bdc21dd6c3d5`
- IndexModule: `43618a994095f3d73902f23521c055c8950cdc043f8d8ca74e9b83aef67f1592`
- FilesJoinedProfile: `c701bf700c122d0c1fd0c3f6b51630c3c0b9bdb6902e0975b8b6a3095cf43cdf`
- FilesJoinedConsumer: `faf1e68e5dc92d56da6d39a7893ec0f7d4b06f13e04678ee04a62655c803005d`
- Existing FilesJoined tests: `65d4dc7514cc026d7879aec158fd562953b63135161730af0290f3d25be00b18`

The review itself changed no repository file. The new contract inherits FilesJoinedTest for real fixtures/support, including its existing test entrypoints; the intended gate must match FilesWithdrawalTest plus `test_withdraw_` so exactly three new cases are counted. Inherited cases are not additional evidence from this probe.

## Actual semantic basis

Ledger._applyWithdraw (Ledger.sol:693-721) permits only the author's prior PUBLISH/REUSE admission, marks that admission withdrawn, subtracts one occurrence and emits a new WITHDRAW admission. It leaves Record Type/body/first admission and all HEAD/path/tag bindings intact. The normal publication machinery still advances publication/admission counters and the actual author's nonce; claiming complete state stasis would be wrong.

IndexModule.onAdmission (IndexModule.sol:95-121) releases only the affected by-Type and by-author occurrence-list live counts for WITHDRAW. Packed retained ordinals and list count/last/flags persist. History/scope/backlink bindings are unaffected. FilesParentIndex handles first publication of Child records, skips subsequent reuse memberships, and does not delete its retained parent lists on WITHDRAW. Coverage is family-wide, not independently maintained per parent.

Core checked references require retained Record Type presence (Ledger.sol:527-546), and FilesChildRule checks retained parent headers and matching File words without consulting occurrence counts. The unrelated FilesJoinedConsumer instead rejects a selected Record whose occurrence count is zero (FilesJoinedConsumer.sol:155-178), while its parent-header branch has no positive-occurrence condition (lines185-194). This source difference is the behavior the probe characterizes, not a fabricated defect stub or an adopted policy.

## Case-by-case assertion review

### 1. Selected RA withdrawn, retained but reader rejects

Test entrypoint: FilesWithdrawal.t.sol:175. Positive controls call the actual unrelated consumer before withdrawal: Alice/Bob points, File-tag folders, selected-revision-tag folders and conflict. The fixture provides real Root and independently authored RA/RB.

`_withdrawAliceSole` (line108) proves a sole maintained occurrence before genuine Alice-signed WITHDRAW. `_oneLifecycleAction` (line36) checks exactly one new admission/publication, unchanged Record/Binding counts, and only Alice's nonce advancement. `_assertZeroRetained` (line98) checks exact original Type/first admission/body-derived identity, count0, PUBLISH kind, withdrawn flag, original body hash and admitted Type. `_releasedExactlyOnce` (line53) checks each named by-Type and Alice-by-author live decrement while preserving count/last/flags/packed words.

All six fixture binding getters are snapshotted (line67), as are the named parent/history/scope/backlink postings (line76). Complete-current checks cover all six mandatory families with from1/through-current semantics (line89); parent membership is independently exhausted using the existing exact helper. The test separately confirms Alice HEAD remains live revision2 targeting RA.

Each of point, conflict, File-tag folder and revision-tag folder must fail with the complete exact E_PROFILE revert payload, not just any failure (lines158-173). They use a fresh current Basis. Bob-first still decodes exact RB, sees the File project tag and has a COMPLETE/exhausted empty approved result with selectedSoFar1. The failure is not explained away by stale basis, masked namespace or invalid bytes.

### 2. Zero-occurrence parents still support existing and new descendants

Test entrypoint: line214. Root withdrawal is followed by re-running real valid RA/RB point/folder/conflict controls, showing live children decode the retained zero-count Root header.

`_publishNewChild` (line189) derives a distinct child ID from a new document, requires it absent, then actually executes signed PUBLISH; this is neither fake storage nor a disguised REUSE. The new child of withdrawn R0 is added as the exact third first-admission parent member, with list count/live3 and exhaustion at index3 (line203).

The test then withdraws sole RA and observes the exact selected-read failure before publishing/selecting a new distinct grandchild of RA with unchanged HEAD CAS expected2. This exercises the Child-as-parent header branch as well as Root-as-parent. The selected grandchild is decoded with exact File/parent/document and File project tag, its retained parent membership is checked, and both original ancestors remain at count0 with exact original bytes/first admissions/withdrawn PUBLISH rows. Complete families and Bob-first reads remain valid. Existing missing/wrong-parent rejection tests are unchanged rather than replaced.

### 3. Bob REUSE restores aggregate maintenance without changing HEAD

Test entrypoint: line238. Alice withdraws RA and the exact read failures are observed before Bob acts, so the success control cannot pass without traversing zero maintenance.

Bob calls genuine Actor.execute, which forwards ledger.execute under the contract's own nonce (LabHarness.sol:75), not a substituted signer. The test checks native evidence author/category, real REUSE admission kind/target/non-withdrawn state, count1 with the original first admission, unchanged Alice-withdrawn flag, one admission/publication increment and Bob-only nonce advancement. Exact fixture binding and retained-posting snapshots prove no HEAD, placement, tag or parent membership changes. The full valid controls then succeed again, including Alice-first RA despite Alice's original occurrence remaining withdrawn.

This is evidence for aggregate occurrence maintenance affecting the present reader, not selected-author consent being restored or an explicit revocation being overridden.

## Non-vacuity and claim boundaries

The assertions would fail for deletion of Record bytes/identity, silent HEAD clearing, incorrect occurrence-list release, missing counter/nonce advancement, removal of retained parents, stale-basis errors, automatic Lens fallthrough, rejecting an existing zero-count parent, or creating/rebinding a different revision instead of Bob REUSE. Positive and negative controls operate on real signed/native actions and current state. The snapshots are explicitly named subsets, not an exhaustive independent raw-state oracle.

A first-pass success is legitimate characterization of existing behavior; no behavioral RED or production fix is required by this probe. The selected-zero-count E_PROFILE error is explicitly labeled undesirable characterization, not an assertion that this is the desired reader contract. No reader policy change, automatic fallback, SDK enum, privacy claim, Core semantics adoption or production implementation occurs here.

The paid packet remains a separate already-frozen experiment with no withdrawals. Nothing in this probe changes its source evidence, costs or claims. These tests provide no new paid receipt economics, storage-growth measurement or authenticated state proof.

## Actual frozen gate evidence and final disposition

Read the actual `/tmp/efs-b-archive-task1.OXPOfb/files-withdraw-characterize.json` and `.log`. Root's run selected `--match-contract FilesWithdrawalTest --match-test test_withdraw_` and reported exactly three PASS results, zero failures, zero skipped. No inherited entrypoint was included in that count. The test source SHA256 in the manifest and current read-back is exactly the reviewed `c37a3c81a5a77801310d627987dbbc9cb3126f14ce4002a6767b8f0eab12be6f`.

Source digest: `e2b63fd09ed5acf0f9581f58b32497f4ea7f913197c18f9b4fdf19983ba5a407`. Root gate ran2026-09-14 12:03:29.594Z through12:03:47.883Z, exit0/signal null, no failure or stop reason, ownedProcessesStopped=true and slotReleased=true. It used the retained offline Solidity0.8.30 compiler and source snapshot plus full build-info output. The matching old implementation/support pins remain unchanged.

The log includes expected oversized *test harness* initcode warnings for the inherited fixture classes. This run does not establish test-harness mainnet deployability, nor is its test gas a paid-operation price. No production implementation changed, so prior paid instrument/runtime-size evidence is neither invalidated nor rerun here.

One Minor wording note: the final REUSE assertion says “one aggregate maintainer” although the getter counts occurrences, not distinct maintainers. Its executable check is correctly `occurrences == 1`; the plan/report interpret it as an occurrence count. Preserve this frozen characterization source; use “one maintained occurrence” when a later separately authorized corrective regression legitimately edits that line. This does not block the current evidence.

Source review plus the actual frozen three-case PASS support the plan's stated characterization. Recommended separate next reader-policy work: retained, well-formed selected bytes should not become a profile-integrity error solely because aggregate maintenance is zero; keep maintenance, selected HEAD and explicit application revocation separate. That recommendation is not a fix authorization, adopted public API, automatic Lens fallback policy or Core semantics change. No implementation was made by this review.
