# Final integration review — three-task joined Files plan

Date: 2026-09-14. Reviewer: files_paid_runner, independent of the Task1/2/3
implementers. This review excludes the separate paid wrapper/runner I authored
and excludes its measurements, oracle and latest commit `de56345`.

**Verdict: Approved for the completed, bounded three-task plan.**

No Critical or Important defect was found against that plan's stated scope.
There is one newly explicit withdrawal/read-policy gate below; approval is not a
claim that every File lifecycle, production integration or durability property
has been validated.

## Evidence and independence

Read the complete current plan, retained Task1 and Task2 independent reviews,
Task3 brief/report/review, and all three current source files. This pass focuses
on cross-task assumptions, not re-counting each prior review finding. The source
commits under review are `9fdee5e`, `d54a120` and `c85e5ba`.

Fresh filesystem hash checks show the actual three files exactly match the
retained pre-paid full-suite and normal-size input
`cf0e22d1ef77cd02446f4f1662df3d9b98d2d2a1f05a808c6e77d30cc939c8bb`:

- Profile `c701bf700c122d0c1fd0c3f6b51630c3c0b9bdb6902e0975b8b6a3095cf43cdf`
- Consumer `faf1e68e5dc92d56da6d39a7893ec0f7d4b06f13e04678ee04a62655c803005d`
- Tests `65d4dc7514cc026d7879aec158fd562953b63135161730af0290f3d25be00b18`

Previously inspected root logs record120/120, including17 Files tests, and normal
component runtime/initcode sizes. This review performs no new compiler, Forge,
Anvil, RPC, Git or subagent work, and changes no source. Only this report is
written. Retained execution evidence is not relabeled as an independent rerun.

## Integration seams

- **Identity and acceptance agree.** Root's existing nonzero File word and
  Child's exact parent/File header mean the same thing in validation, the index
  and the consumer. Both consumers of the profile check exact shapes, ordered
  references, mandatory rule hashes and Child's configured Root Type. The
  wildcard checked reference is narrowed by the mandatory rule; it is not an
  unqualified application parent. Runtime hashes supplied by the deployer remain
  a reviewed-configuration trust boundary, not a proof that arbitrary rule code
  chosen by a caller is the approved rule.
- **Bounded acceptance and full reads are not conflated.** The validator and
  immediate-parent recheck use pinned Ledger metadata/one File word; the field
  masking agrees with the actual layout. Cold maximum-body tests cover Root and
  Child parents. The reader separately loads and hashes the selected full body,
  so its read cost and copied document size are not the validator's bounded cost.
- **Mandatory atomicity and retained indexing agree.** Both fixture index and
  immutable Lens are installed together before admission1. The Files module
  calls inherited maintenance and adds only first-admission Child memberships;
  reuse/republication does not create duplicate retained parent entries. The
  fault callback executes after both halves and rolls back the named tested
  state. Retained parent membership is distinct from author HEAD history and
  current selection; it does not mean an occurrence remains live forever.
- **Exact reads and enumeration have different prerequisites.** A current exact
  HEAD/Record/parent check does not consume reverse-parent postings and therefore
  survives their metadata-only downgrade. Folder enumeration requires the
  scope family's actual from1/current COMPLETE coverage and an exhausted,
  unmutated, fully context-bound page. The corrected Task2 expectation does not
  waive any required write callback or authorize incomplete-as-empty output.
- **Tag subjects remain explicit across all tasks.** HEAD is selected before
  a revision tag is evaluated. File and selected-revision scopes carry exact
  subjects, raw status, target and evaluated/present distinctions. A positive
  binding must target the expected File. Missing/masked HEAD has no evaluated
  revision tag; no-tiebreak conflict retains candidates without inventing an
  overall selected revision. The folder API is a selected-File graph filter,
  not a universal search of every tagged Subject, including those without a
  usable HEAD.
- **The lifecycle composes these same primitives.** Rename/move change namespace
  bindings without rewriting revision bytes or HEADs. Reusing the old path
  creates G rather than transferring F's identity/tags; tombstone CAS continues
  through revision2. Whiteout masks lower-priority placement without deleting
  exact F. Restore is one real three-action publication with a new Child RR,
  preserving old bytes while not inheriting tags from another exact revision.
  Parent memberships and sealed as-of binding history stay distinct.
- **The scan claim is honestly small.** Empty PARTIAL is rejected, same-state
  continuation can finish empty, and two added/masked distinct names increase
  the raw inventory from2 to4 while the live set stays G. This demonstrates the
  lifetime-name liability; it does not solve or price arbitrary lifetime churn.

## Remaining explicit gates

1. **Last-occurrence withdrawal versus retained reads — newly explicit.**
   `src/Ledger.sol:691` documents and `:694–716` implements decrementing the
   occurrence count without deleting bytes or tombstoning HEAD.
   `test/FilesJoinedConsumer.sol:155–163` currently rejects a selected
   Record when that count reaches zero with E_PROFILE. Immediate-parent checks,
   however, deliberately depend on retained identity/header, not live occurrence
   count (`test/FilesJoinedProfile.sol:44–54` and
   `test/FilesJoinedConsumer.sol:186–192`). The Core reference check is also
   type/existence-based, not positive-occurrence-based (`src/Ledger.sol:526–546`).
   Consequently a last-occurrence withdrawal can leave an unchanged HEAD
   and retained bytes while making the selected File (and its whole folder join)
   error. Those reference/parent predicates do not reject a zero-occurrence
   retained parent, but actual subsequent Child admission has not been executed
   in this review. This is a source-derived untested seam, not an executed new
   counterexample. Task3's
   removal is namespace UNBIND, not carriage WITHDRAW. Before claiming complete
   File lifecycle support, characterize withdrawal/republish under exact and
   folder reads and decide whether liveness qualifies the value, affects
   selection, or should be a distinct result instead of E_PROFILE. Do not silently
   treat withdrawal as semantic revocation or erase retained evidence.

   Narrow next probe: in a fresh existing F/R0 fixture, withdraw R0's sole
   publication through the real signed API. Assert count0, retained exact body,
   unchanged HEAD, and exact current point/folder result or error. While count
   remains0, attempt one valid same-File Child publication without changing HEAD
   and retain the actual success/error and parent index state. Finally republish
   exact R0, observe count1 and re-read the unchanged HEAD/folder. This can
   distinguish retained identity, occurrence liveness and current selection
   without changing the consumer, redefining withdrawal, or adding a scale run.
2. **Index configuration commitment.** The existing admin metadata downgrade can
   change coverage without changing the signed module-address/codehash
   obligation or generation. The query consumer detects actual PARTIAL coverage,
   but that does not fix publication expectation/configuration pinning. The
   separately reported configuration/epoch design gate remains open.
3. **Cold names, folder profile and browser.** Hashed roles do not reconstruct
   filename bytes, and two folder hashes are not a nested-directory/cycle/parent
   semantics proof. Cold reconstruction, real navigation and the browser/SDK
   write-reconcile journey remain separate joined gates.
4. **Scale, economic overhead and broader queries.** These tests do not establish
   general live-set enumeration, large Lens joins, multi-window concurrency,
   historical paging or global tag discovery. Their Forge gas is not a user
   action receipt. The separate paid pass must stand on its own reviewed raw
   transaction/state evidence and retain actual workload boundaries.
5. **Durability, privacy and evolution.** No authenticated state proof, portable
   historical native-author proof, key recovery/delegation profile, encrypted
   opaque read path, production upgrade plan or successor-Type compatibility
   bridge is earned by these three tasks. Exact identity alone does not supply
   those properties. Keep broader design claims and prototype evidence distinct.

The prior reviews' minor oversized-test-harness/lint qualifications still apply;
normal profile/reader contracts are not the test orchestrator. No rewrite or
repeat heavy validation of the approved three-task slice is requested. Record
the withdrawal seam and continue through concrete remaining gates rather than
reopening already supported behavior without a new question.
