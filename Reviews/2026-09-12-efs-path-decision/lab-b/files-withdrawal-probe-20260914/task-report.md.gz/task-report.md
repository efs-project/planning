# Task 1 — withdrawal characterization source handoff

**TESTREADY, 2026-09-14.** Parent supplied base `f7b69090d270aefb96e474b44025ce5bc59e05db`. This worker did not run Git, Forge, solc, Anvil, RPC, installs, or subagents. No compile/test success is claimed. Root owns the focused execution and review gate. Current behavior can legitimately pass first time; no false RED stub was manufactured.

Only new source: `Reviews/2026-09-12-efs-path-decision/lab-b/test/FilesWithdrawal.t.sol`, SHA256 `c37a3c81a5a77801310d627987dbbc9cb3126f14ce4002a6767b8f0eab12be6f`. This assigned report is the only other write.

## Exactly three new focused tests

Run with `--match-contract FilesWithdrawalTest --match-test test_withdraw_`. The class inherits the real joined fixture and its existing tests; inherited cases must not be counted as new evidence or unnecessarily rerun.

1. `test_withdraw_selected_revision_retained_but_reads_reject`: genuine positive Alice/Bob point/folder/conflict controls; Alice signs withdrawal of sole RA; exact Record bytes/ID/Type/first admission retained with count0 and original PUBLISH withdrawn bit; all six fixture HEAD/placement/tag bindings unchanged; both named by-Type and Alice-author occurrence list live counts decrement exactly once while count/last/flags/packed words remain; parent/history/scope/backlink lists unchanged; six current mandatory families COMPLETE. Fresh-basis Alice point/conflict/both tagged-folder scopes must return exact full `E_PROFILE()` revert data, while Bob-first reads and complete empty approved folder remain valid.
2. `test_withdraw_parent_keeps_descendants_and_new_child_admissible`: withdraw R0, repeat actual live-child read controls, genuinely sign publication of a distinct Child of count0 R0 and verify exact three-member retained Root list. Withdraw RA, observe the selected zero-count failure, then genuinely publish/select a distinct grandchild of count0 RA using the unchanged Alice HEAD CAS expected2. Verify exact grandchild bytes and File tag, its required parent posting, both original ancestor bytes/IDs/first admissions and count0, complete families and Bob's unaffected reads.
3. `test_withdraw_other_author_reuse_restores_read_without_head_change`: observe RA-withdraw failure, then native Bob Actor executes REUSE of RA. Check actual native evidence author/category, REUSE admission, count1 and original first admission, Alice original withdrawn bit still true, unchanged HEAD/placement/tag and retained-index snapshots, exact parent set and all previous read controls restored. This characterizes aggregate maintenance, not selected-author revocation policy.

## Source-only self-review

- All mutations use inherited genuine Alice `executeSigned` or Bob `Actor.execute` helpers; there is no fake storage, mocked lifecycle, forged contract signature, or direct acceptor shortcut.
- `_oneLifecycleAction` explicitly checks admissions +1, publications +1, Records/Bindings unchanged, and only the actual author's nonce +1. Successful withdrawals are never called all-state-unchanged.
- `_withdrawAliceSole` requires a real maintained sole occurrence before the action, compares exact retained data afterward, and checks named occurrence-index release separately from unchanged retained families.
- Every reader call uses `_basis()` after the preceding mutation; exact 4-byte E_PROFILE comparison cannot accidentally accept E_BASIS or a unrelated revert payload.
- Original R0/RA/RB parent membership is verified independently from HEAD history. New Root child and Child-parent grandchild exercise both bounded parent-header branches. The new Child is asserted absent before actual publication, so this is not disguised REUSE.
- Existing invalid/missing/wrong-File tests remain untouched; unauthorized and double-withdraw generic tests were not duplicated.
- The file states that `E_PROFILE` is characterization of an undesirable conflation, not a desired product specification. No fix, result enum, automatic Lens fallback or Core semantic change is made.

## Preserved pins

- Ledger `7576874b52a81ebc0f7b64640332b345096e0c09000ed4f09811bdc21dd6c3d5`
- IndexModule `43618a994095f3d73902f23521c055c8950cdc043f8d8ca74e9b83aef67f1592`
- FilesJoinedProfile `c701bf700c122d0c1fd0c3f6b51630c3c0b9bdb6902e0975b8b6a3095cf43cdf`
- FilesJoinedConsumer `faf1e68e5dc92d56da6d39a7893ec0f7d4b06f13e04678ee04a62655c803005d`
- Existing FilesJoined tests `65d4dc7514cc026d7879aec158fd562953b63135161730af0290f3d25be00b18`
- Original frozen paid oracle `fd6b0212b6dc8f1d2294e5ce9b42b3a30141038b593666bdc4e2565e9cb3097e`

These hashes were read before and after creation of the new test and did not change. Root's post-run normalization fork was not touched or inspected as part of this test task. If the focused run disagrees semantically, stop and explain the mismatch; do not silently rewrite characterization expectations.
