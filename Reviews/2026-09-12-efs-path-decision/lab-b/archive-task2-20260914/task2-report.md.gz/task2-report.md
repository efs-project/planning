# Task 2 implementer report

**Current status: DONE — implementation and root-run semantic/size/paid gates
complete; KEEP PACKED under the predeclared rule. Independent task review and
publication remain controller-owned.** See the final checkpoint below; earlier
RED/GREEN/UNMEASURED entries are the chronological handoff record.

## RED READY — 2026-09-14

Status: frozen for root-run compiling behavioral RED. Task 2 is not complete.

Source baseline: Task 1 code `02c34a94f62f76df981237f6973bda6867063b3b`.
Actual HEAD at freeze: `0d28b0f6b9ccd92a9139cbe2f3635ff4b1a46b0f`
(root's artifact-only descendant).

Changed source inventory and SHA-256:

- `Reviews/2026-09-12-efs-path-decision/lab-b/src/SignedClaimArchive.sol`: `e709ffa32f6c1dd720432c2eaebb9c33157fda1e8c73a2afb8811bebaebafe52`
- `Reviews/2026-09-12-efs-path-decision/lab-b/test/SignedClaimArchive.t.sol`: `1bc6c7ff6414de28f44fb126dbf7db972d2424d1a037e1890f59724f8b80cc7c`

No new source files yet. Consumer and paid runner remain unimplemented. Existing
untracked `.codex-*` message files are untouched. No Git mutation, compiler,
chain, RPC, dependency installation or agent dispatch performed.

### Changes

- Preserved all 14 Task 1 test bodies; added two representation tests and their
  test-only helpers.
- Rich vectors of 1, 2 and 64 alternate PUBLISH and REUSE for paired Record IDs,
  with nonzero purpose/subject/role/target/salt and high-bit revisions. They
  assert every returned Action field and rebuilt whole-vector hash; exact signed
  header, importer/time, signatures and proof; postings; absent versus attached
  empty bodies; and all coverage bits after attachment.
- Event-derived carrier checks require exactly one neutral first-retention
  event per archive, packed location zero, exact STOP-plus-ABI bytes and sizes.
- Retry test checks no writes, no new retention event, stable archive creation
  nonce (no CREATE), original event-derived codehash, header, actions and posting
  count.
- Codeblob is an ABI-compatible no-op retention / zero-Action stub. Neutral
  event declaration exists, but is not emitted yet. Packed alias unchanged.

### TDD evidence

RED command/result: pending root. No Forge/solc invocation is authorized here.
Expected behavioral failures: `all nine action fields round trip` in the
equivalence test; `one neutral event per first retention` in the retry test.
The first failure specifically catches the unimplemented new representation,
before event observations are evaluated. Compilation is not claimed.

GREEN: not attempted; codeblob deployment/decoding and location seam deliberately
unimplemented pending root's RED observation and authorization.

Read-only static check: `git diff --check` exits 0 with no output. Inspection
confirms 16 test functions (14 unchanged plus two new). This is not semantic
test evidence. Self-review found no unrelated source edits or validation
duplication.

### Remaining gates

Root observes real compiling RED, then authorizes minimal semantics. Root runs
GREEN and reviews bounded runner preparation before any chain launch. All paid
gas and representation-choice claims remain UNMEASURED; final alias is packed.

## GREEN READY — after root RED observed 09:39:49 UTC

Root-run RED evidence: `/tmp/efs-b-archive-task1.OXPOfb/task2-red-1.log`.
Solc 0.8.30 compiled successfully; full suite: 93 passed, 2 failed, 0 skipped.
The two new tests failed exactly at `all nine action fields round trip` and
`one neutral event per first retention`. All 14 original archive tests passed.
Root reported joined-run source digest
`5e35cda0a210a62e9f366c066ff8b37a91b4114a45010f00d1d6fa5b7e3858e3`,
exit code 1, signal null, stopped/released true. Implementer read the log tail
and confirmed both failure messages and suite counts; no tests rerun here.

Root explicitly authorized semantics after that failure. Added the specified
plain CREATE carrier, STOP plus ABI vector, exactly 288-byte EXTCODECOPY at
`65 + 288 * leaf`, and ABI decoding. The smallest new `_vectorLocation` seam
defaults to zero for packed and returns the private mapping address for codeblob.
Common first-retention branch emits the neutral event only after storing vector
and postings. No duplicated validation, public getter, retry deployment, callable
carrier surface or proof state was introduced. Packed alias unchanged.

GREEN-ready source SHA-256:

- `src/SignedClaimArchive.sol`: `6e7e419c30b0cc49327b5e2ca1436a44df1a00079bd518341e66c5cb613a4d4d`
- `test/SignedClaimArchive.t.sol`: `1bc6c7ff6414de28f44fb126dbf7db972d2424d1a037e1890f59724f8b80cc7c` (unchanged since RED)

`git diff --check` exits 0. No compiler, chain, RPC, or Git mutation performed.
Consumer/runner remain unimplemented to keep this exact semantic GREEN gate
separate. Frozen now for root-run GREEN; no passing claim yet.

## RUNNER READY — source frozen for root preflight

Status: implementation prepared, full final semantic/size/paid gates pending.
Packed alias remains selected. No paid observation or alias-choice claim.
Actual HEAD at handoff: `441f3cda2263c1bb7c7b0034dbae9e0d9bf2271a`
(root's independent diagnostic/evidence commit; no Task 2 path committed here).

### Root-observed semantic evidence

- Representation GREEN: `/tmp/efs-b-archive-task1.OXPOfb/task2-green-1.{json,log}`;
  root reports 95/95 full tests, 16 archive tests, no failures/skips, successful
  compilation and stopped owned process. Input digest
  `62a2b28e0552bb49b21719b6570f942172b22fe2bf1110991fecc00ea3d8bc8c`.
- Consumer test plus no-op ABI stub were added before implementation. Root
  observed compiling RED: `one paid action observation`, 0 passed / 1 failed;
  `/tmp/efs-b-archive-task1.OXPOfb/consumer-red-1.{json,log}`. Root then authorized
  the three-line actionAt/hash/event implementation.
- Consumer GREEN: root reports 1/1 passing, unchanged test, successful compile
  and process stopped; `/tmp/efs-b-archive-task1.OXPOfb/consumer-green-1.{json,log}`.
  Its test exercises both real representations, leaves 0 and 63, all-tuple hash
  in the exact event, zero consumer/archive storage writes and propagated bounds
  error. No existing 16 archive tests were changed.

### Four source pins (SHA-256)

- `src/SignedClaimArchive.sol`: `6e7e419c30b0cc49327b5e2ca1436a44df1a00079bd518341e66c5cb613a4d4d`
- `test/SignedClaimArchive.t.sol`: `7f8cafa47e1d2606aeab969b81217f179381aeadd07612431d0944c8452dca94`
- NEW `test/ArchiveReadConsumer.sol`: `6e61288df68a5a9669183e92f2d7874d35018d25c12788fee7689226e6acc345`
- NEW `script/measure-portable-archive.mjs`: `a2ca8e4297dfcd2bed61952a64dd442a8b2f82ed53f9385a9c97795cc2ef3f1e`

All paths are under `Reviews/2026-09-12-efs-path-decision/lab-b/`. Root-owned
`test/FilesParentBudget.t.sol`, diagnostics/evidence and preexisting `.codex-*`
files were not edited. No Git mutation, compiler, chain, RPC, dependency
installation or subagent dispatch was performed by this implementer.

### Runner implementation and exact operational requirements

Only `--anvil --out <absolute temporary path>` is accepted. The output's existing
real parent must be within the specific run-owned `EFS_LAB_SCRATCH`; existing
summary/sidecar paths are refused. `FOUNDRY_OUT` must resolve beneath that scratch.
Required environments: `EFS_ETHERS_PATH`, `FOUNDRY_OUT`, `EFS_LAB_SCRATCH`,
`EFS_ARCHIVE_COMPILER_INPUT`. The latter accepts the complete Forge build-info
envelope or exact standard-JSON input, preserving `.input` without reconstructing
missing settings. With build-info, artifact creation/runtime bytes must match
its compiler output. Compiler input contents must match actual local files;
artifact metadata source hashes and 0.8.30/viaIR/200/Cancun settings are checked.

Installed runtimes verified read-only / Node-only:

- `/opt/homebrew/bin/node`: `v26.0.0`.
- `/Users/james/Code/EFS/planning-efs21/Reviews/2026-09-04-mvp-rehearsal/node_modules/ethers`: `6.15.0`.

Root must pin the actual installed Anvil binary via its controlled PATH and use
the external heavy-slot/lease/aggregate-scratch/process-group gate. Runner spawns
one Anvil with loopback-only dynamically selected port, Cancun, chain ID 31337,
30M block gas, two disposable test accounts, genesis timestamp 1800000000,
`--prune-history 128`, unique run-owned cache path, no CORS, and quiet logging.
Five-minute watchdog plus signal handling and finally kill only that child.
No fallback flag removal, external RPC, compile, install or alternate fixtures.
Resource checks enforce 50 GiB free and 15 GiB within its supplied scratch;
root remains responsible for aggregate experiment scratch across other runs.

All 1/2/64 no-body synthetic fixtures and EOA signatures are built before any
measurement transaction or chain start. Author is PK_A 0xA11CE; independent
importer is standard disposable mnemonic account 1; deployer account 0. Six
branches reset to the identical post-three-deployment snapshot. Each retention
pins timestamp 1800000100; paid reads pin +1 and +2. Size 1 has two separately
signed nonce-distinct paid transactions for leaf 0. All observations happen
before branch reversion, using block-hash-qualified EIP-1898 calls/code reads.

### Raw evidence layout for root's independent audit

Summary filename is the requested output. Raw sidecar is `<output>.raw.json`,
bounded at 64 MiB, saved with failure details on runtime error and referenced by
SHA-256 from the summary. Complete compiler input appears once, not per cell;
large full compiler output is not copied. Full raw RPC request/response pairs
retain unique global JSON-RPC IDs, with branch labels; failures are retained too.

- `source`: actual commit, diff hash, dirty/new inventory and every actual
  Solidity/MJS/config file's SHA-256/length, including new files.
- `build`: full input/settings, compiler input file hash and version, source
  content hashes, three artifact file hashes, ABI, creation/runtime bytes,
  immutable references and compiler metadata. Artifact archive runtime is
  checked after exact domain-separator immutable substitution.
- `fixtures[]`: N, exact Intent/Action vector/encoding/hash/digest, original
  signature, empty body input vector and common caller.
- `transactions[]`: 21 entries, branch + label, signed raw envelope, derived
  hash, expected from/to/nonce/data/value/chainId, full transaction object,
  complete receipt/logs and matching block header. Three deployment, six
  retention and twelve read inventory items are mandatory and hash-unique.
- `branches[]`: incoming branch id, snapshot/revert ids, pinned timestamp,
  restored baseline header, retention hash/basis, neutral-event vector address,
  all three contract codes at that basis, exact blob code, every raw `claim`,
  `actionAt`, count/posting and selected-Record call, and both paid read refs.
- `rpc[]`: literal globally indexed request/response envelopes, including
  branch-attributed snapshot controls and basis-qualified code/call reads.

Raw tuple bytes are compared to the fixed fixture, header to the original
signature/importer/time/coverage, every posting to its independently derived
Record ID, blob to STOP plus full ABI vector, and paid event to intended
consumer/claim/leaf/hash. `checks` booleans in the summary are only candidate
self-checks, not root's independent verdict. No body retention, three-action
joined recovery, source admission or destination acceptance is priced here.
Candidate recommendation uses the exact predeclared strict size-2 and size-64
retention rule and discloses size-1 and both paid reads. It never edits the alias.

### Node-only test evidence

Control tests were written first against compiling exported no-op stubs.
`/opt/homebrew/bin/node --test /tmp/efs-archive-runner-control.test.mjs` initially
reported 7 expected behavioral failures / 1 pass: argument restriction,
six-branch sequencing, revert/snapshot failure refusal, stop after observation
failure, strict choice rule, fixed fixture and raw transaction joins.
After implementation all 8 passed. A separate attribution regression test then
failed with twelve undefined branch labels before the incoming-branch override
was implemented. Final control result: **9/9 passing, 0 failed/skipped**.

`/opt/homebrew/bin/node --experimental-vm-modules --test /tmp/efs-archive-runner-lifecycle.test.mjs`
reports **2/2 passing, 0 failed/skipped**. These are offline characterization
tests of the actual main control flow, with network, child-process, port, and
output-write boundaries substituted in an isolated VM. They check a nonce-RPC
failure and watchdog expiry both stop only the owned child, save raw failure,
leave zero sent transactions and keep status/choice UNMEASURED and alias packed.
No real socket, child process chain or chain RPC was run. Node prints the
expected ExperimentalWarning for VM Modules; output is otherwise clean.

Test helper pins (outside maintained source, explicitly allowed under /tmp):

- `/tmp/efs-archive-runner-control.test.mjs`: `82ea421bc25bd07aa7a9187bde33f1551957143d18010d7b687814f8df3602e2`
- `/tmp/efs-archive-runner-lifecycle.test.mjs`: `2aa29bdc29aaf7d04b7c6800cb8c33ba7eaaab5bd23f436535d625e4a84852e6`

`node --check` and `git diff --check` both exit 0. Root's external reviewer is
reading this frozen runner. No current claim that final full suite, sizes, paid
run or independent raw audit has passed. Final alias still packed; Task 2 gas
comparison/choice is UNMEASURED until all root gates finish.

## Adjacent paid operational gate — READY (explicit root-added /tmp ownership)

Created `/tmp/efs-b-archive-task1.OXPOfb/paid-gate.mjs` by adapting, not editing,
root-reviewed `forge-gate.mjs`. The original still hashes
`291d8b0d357062f4f1e4ac861a2e0da8f34ebb3eaa6b8e47009453bd161f08a5`.
All four Task 2 source hashes remain exactly as in RUNNER READY above.

Paid gate SHA-256: `2290b8af5a5a21646517a3e994e1f33c81bb58066b679b27f4bc9c6e3e788fc9`.
Focused test SHA-256 (`paid-gate.test.mjs`):
`5042b43a274c9d196aff9ffd9f819699524f6037337f49b323bfea14b9a753be`.

Exact gate invocation contract (root only, not executed here):

`/opt/homebrew/Cellar/node/26.0.0/bin/node /tmp/efs-b-archive-task1.OXPOfb/paid-gate.mjs <unique-label> paid`

Required environment: `EFS_ARCHIVE_LEASE_START`, `EFS_ARCHIVE_LEASE_END`,
`EFS_ARCHIVE_EXPECTED_SOURCE_DIGEST`, and `EFS_ARCHIVE_BUILD_REPORT` pointing to
the successful final size report `<runroot>/<size-label>.json`. Lease must be
current, at most 30 minutes, end no later than 14:00 UTC September 14, and leave
cleanup headroom. Alternative `<unique-label> pin` snapshots/hashes with no
subprocess, retaining the existing atomic-slot protocol; this was not run here.

The paid mode requires size-mode report success (code 0, null signal, no failure
or stop reason), exact full source manifest digest, stopped process group and
released build slot. It derives that report's `.state`, requires exactly one
complete `build-info/*.json` with input/output/Solc version, verifies input
contents/settings against the live-source manifest, and joins all three artifact
ABIs and creation/runtime byte strings to compiler output. Report, build-info,
full input object and artifact files/creation/runtime bytes are hashed. The
provenance is re-read and compared immediately before launch; mismatches refuse.

Inherited safeguards remain: atomic `wx` slot with inode/token-checked release;
read-only private source snapshot plus live source verification; asynchronous
bounded preflight and source/import/file limits; aggregate scratch roots from
the existing pins plus this run root; 15 GiB aggregate budget and 50 GiB free
reserve checked every five seconds; bounded `/bin/ps` occupancy check; detached
owned process group; ordinary signal handlers and repeated-signal KILL escalation;
TERM/KILL cleanup and verified group death/reaping before slot release. The paid
watchdog is five minutes or shorter lease headroom, followed by bounded cleanup.
Post-run success also requires an unchanged live source manifest.

It hashes and executes absolute Node
`/opt/homebrew/Cellar/node/26.0.0/bin/node`; hashes Anvil
`/Users/james/.foundry/bin/anvil`; records exact ethers 6.15.0/package hash; supplies
`PATH=/Users/james/.foundry/bin:/usr/bin:/bin`; launches the LIVE B runner once,
with `--anvil --out <runroot>/<label>.measurement.json`, live B cwd, matching
size-state `FOUNDRY_OUT`, `EFS_ARCHIVE_COMPILER_INPUT` and the common run root as
`EFS_LAB_SCRATCH`. Gate reports/logs use `<label>.json`/`.log`; source snapshot and
temporary directory are label-owned. All output names must be new.

Tests: wrote pure build-report/input/artifact admission tests against no-op
validation stubs; observed three behavioral failures (missing required refusal).
After implementation, `/opt/homebrew/Cellar/node/26.0.0/bin/node --test
/tmp/efs-b-archive-task1.OXPOfb/paid-gate.test.mjs` reports 3/3 passing with no
failure/skip. `node --check paid-gate.mjs` exits 0. Imports are side-effect free.
No gate invocation, slot acquisition, real subprocess test, Forge, Anvil or RPC
was performed. Process-group mechanics were inherited and diff-reviewed, not
re-exercised here; root must audit before any actual launch.

## Final checkpoint — DONE, 2026-09-14 10:10:33 UTC paid completion

Root completed the single paid run, with no retry. Root reports its independent
raw audit PASS using `/tmp/efs-b-archive-task1.OXPOfb/audit-paid.mjs`: all 21
transactions and six branches matched, including signed envelopes, full
receipt/log/block joins, source/compiler input/output/artifact provenance,
all raw getters, signatures, exact blob bytes and first/last paid-read events.
The implementer did not rerun the audit, compiler, tests or chain. For this report
checkpoint, the implementer read the retained summary/gate outcomes and final
test/size logs and independently recomputed the raw file's SHA-256 only.

Actual evidence:

- Paid operational report: `/tmp/efs-b-archive-task1.OXPOfb/paid-1.json`.
- Candidate cost index: `/tmp/efs-b-archive-task1.OXPOfb/paid-1.measurement.json`.
- Raw observations: `/tmp/efs-b-archive-task1.OXPOfb/paid-1.measurement.json.raw.json`.
- Raw SHA-256: `87e0c642e9d2a923f01c9e2bbc57e28b4a553822c046bdbd98d6457a5c8a3177`.
- Final semantic gate: `/tmp/efs-b-archive-task1.OXPOfb/final-green-1.{json,log}`:
  102/102 full B tests, 17 archive tests, 0 failures/skips.
- Final size gate: `/tmp/efs-b-archive-task1.OXPOfb/final-size-1.{json,log}`,
  with complete matching build-info in its `.state/build-info`.

All three gates share exact full source digest
`2b9373560bd428de43f63c8190552752896b323f90a7415261321b5b29c35e62`.
All report code 0, null signal, owned processes stopped and slot released.
Paid gate finished `2026-09-14T10:10:33.145Z`. This source includes root-owned
Files diagnostic work; all four Task 2 file hashes are unchanged from the frozen
handoff. The summary's `CANDIDATE_CHECKED_AWAITING_INDEPENDENT_REVIEW` is retained
unaltered as the runner's original self-check status; root's later independent
audit PASS is separate evidence, not a rewrite of the raw packet.

### Matched paid figures (gas, no subtraction of consumer overhead)

| Vector leaves | Packed retain | Codeblob retain | Packed paid first / last | Codeblob paid first / last |
|---|---:|---:|---:|---:|
| 1 | 429,833 | 456,481 | 50,726 / 50,726 | 36,787 / 36,787 |
| 2 | 578,709 | 585,046 | 50,726 / 50,738 | 36,787 / 36,799 |
| 64 | 9,817,718 | 8,571,876 | 50,726 / 50,738 | 36,787 / 36,799 |

The two size-1 reads are distinct paid receipts even though both request leaf 0.
Archive deployment costs are separate: packed 1,387,764 gas, codeblob 1,423,208
gas; stateless consumer 195,652 gas. Packed runtime/init bytes are 6,160/6,361;
codeblob 6,324/6,525; consumer 658/684. Blob runtime bytes are exactly 353, 641
and 18,497, including the leading STOP and entire encoded vector, below EIP-170.

### Reversible selection and scope

**KEEP PACKED.** Codeblob costs 6,337 more retention gas at size 2, although it
saves 1,245,842 at size 64 and lowers both paid-read receipts. The predeclared
rule requires strictly lower retention at BOTH size 2 and size 64, so it fails.
The small-vector tradeoff is explicit: codeblob also costs 26,648 more at size 1,
adds 35,444 deployment gas and 164 archive runtime bytes. These figures are not
averaged, amortized, extrapolated or described as a universal gas win. No alias
edit was necessary: `SignedClaimArchive is SignedClaimArchivePacked` already
matches the selected result. No rebuild was run merely to repeat successful
exact-source gates.

This completes a disposable bounded EOA **signed-claim archive** and its physical
vector comparison. `AUTHOR_SIGNATURE_VERIFIED` establishes the retained EOA
signature over the exact Intent/Action vector; it does not establish historical
source admission, accepted typed membership, present validity or destination
authority/binding. Native/contract historical archival remains explicitly
UNSUPPORTED. Arbitrary signed source contexts remain claims, not a source Ledger
assertion. Claim-local selected-body recovery and append-only signed posting
discovery do not replace ordinary Files operations. Destination publication, if
attempted separately, remains an ordinary current operation authored by its
actual caller and subject to its own checks. This no-body synthetic fixture
does not price body retention, the three-action joined recovery, Files workflows,
destination admission, production deployment, SDK/API adoption, permanent
representation selection or protocol affordability.

Final self-review: required representation/event/retry/consumer tests preserved;
all original Task 1 tests preserved; no common validation duplication or new
authority proof label; exact-source gates and paid evidence have a consistent
source pin; selected alias already correct. No source changes or reruns in this
checkpoint. Only this report was edited. Task review and evidence retention/
publication remain root-owned; no additional work or authority was inferred.

## Mechanical post-measurement comment whitespace correction

At root's explicit request, removed only one trailing space from each of usage
comment lines 3 and 4 in `script/measure-portable-archive.mjs`, using apply_patch.
Root had committed the initial Task 2 paths in local commit
`2e0358859321daf23311fa2e52553d8bfab70591` before noticing those spaces; this
implementer did not commit or publish the correction.

- Measured runner SHA-256 BEFORE:
  `a2ca8e4297dfcd2bed61952a64dd442a8b2f82ed53f9385a9c97795cc2ef3f1e`.
- Current runner SHA-256 AFTER:
  `cc2b1ca745a041b854be76510cbaa7ae1a59a8cd5d4acc0e1b331fa314e60bbb`.

This is a **comment-only post-measurement change**, not the exact source hash
that was measured. The original measured source is preserved in `paid-1.source`
and the raw evidence. No executable token, Solidity source, fixture, signature,
gas rule or alias changed; no compiler, test-suite, chain or measurement rerun.
The prior source/digest and paid results remain attributed to their original
measured bytes. Earlier `git diff --check` invocations did not inspect the then
untracked runner, so their clean result did not cover these two comment lines.

Verified as separate commands, each exit 0 with no output:

- `/opt/homebrew/Cellar/node/26.0.0/bin/node --check Reviews/2026-09-12-efs-path-decision/lab-b/script/measure-portable-archive.mjs`
- `git diff --check -- Reviews/2026-09-12-efs-path-decision/lab-b/script/measure-portable-archive.mjs`

Reviewed exact file diff: only the two requested trailing spaces removed.
Ready for root's correction commit and whole Task 2 review package.
