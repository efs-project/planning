// Root-owned disposable compiler gate. LABEL pin never starts a subprocess.
// Compiler authority is an explicit finite root lease plus expected handoff digest.
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import * as fs from 'node:fs/promises';
import { constants } from 'node:fs';
import { createHash, randomUUID } from 'node:crypto';
import { posix } from 'node:path';

const run = '/tmp/efs-b-archive-task1.OXPOfb';
const lab = '/Users/james/Code/EFS/planning-warroom-b-run/Reviews/2026-09-12-efs-path-decision/lab-b';
const slot = '/tmp/efs-b-archive-heavy-slot.lock';
const forge = '/Users/james/.foundry/bin/forge';
const solc = '/Users/james/Library/Application Support/svm/0.8.30/solc-0.8.30';
const configHash = '6ea7c7198bc697f74b6286ec830edbefc20e7c549eafda2343c863702055bf2c';
const [label, mode, ...extra] = process.argv.slice(2);
assert(/^[a-z][a-z0-9-]{0,35}$/.test(label ?? ''), 'unique bounded label required');
assert(['pin','red','test','size','cold','consumer'].includes(mode) && !extra.length, 'pin/red/test/size/cold/consumer only');
assert.equal(process.version, 'v26.0.0');
const start = Date.parse(process.env.EFS_ARCHIVE_LEASE_START ?? '');
const end = Date.parse(process.env.EFS_ARCHIVE_LEASE_END ?? '');
const expected = process.env.EFS_ARCHIVE_EXPECTED_SOURCE_DIGEST;
const hardEnd = Date.parse('2026-09-14T14:00:00Z');
const cleanupMs = 5000;
const preflightEnd = Date.now()+30_000;
const hash = b => createHash('sha256').update(b).digest('hex');
const sleep = ms => new Promise(r=>setTimeout(r,ms));
const record = {startedAt:new Date().toISOString(),label,mode,lease:{start,end},expectedSourceDigest:expected,signals:[]};
const reportPath = `${run}/${label}.json`, logPath = `${run}/${label}.log`;
let lease, report, log, child, childDone, childClosed = true, cancelled, kills, watchdog, budgetTimer;
let budgetWork, snapshot;
const owner = {pid:process.pid,token:randomUUID(),label,mode,startedAt:record.startedAt};
function groupAlive() {
  if (!child?.pid) return false;
  try {process.kill(-child.pid,0);return true;} catch(e) {
    if(e.code==='ESRCH')return false;
    if(e.code==='EPERM')return true; // Darwin can report this while a group is reaping; never infer death.
    throw e;
  }
}
function signalGroup(kind) {
  if (!child?.pid) return;
  try {process.kill(-child.pid,kind);} catch(e) {if(e.code!=='ESRCH')(record.killErrors ??=[]).push(e.message);}
}
function stop(reason, repeated = false) {
  cancelled ??= reason;
  signalGroup(repeated ? 'SIGKILL' : 'SIGTERM');
  if (!kills) kills=setTimeout(()=>signalGroup('SIGKILL'),1000);
}
const handlers = Object.fromEntries(['SIGTERM','SIGINT','SIGHUP','SIGQUIT'].map(kind=>[kind,()=>{
  record.signals.push(kind); stop(kind,record.signals.length>1);
}]));
for(const [kind,fn] of Object.entries(handlers))process.on(kind,fn);
function check(deadline=preflightEnd) {
  assert(!cancelled,`cancelled: ${cancelled}`);
  assert(Date.now()<deadline,'preflight/resource timeout');
}
async function bounded(work, ms, name) {
  let timer;
  try {return await Promise.race([work, new Promise((_,reject)=>{
    timer=setTimeout(()=>{stop(`${name} timeout`);reject(new Error(`${name} timeout`));},ms);
  })]);} finally {clearTimeout(timer);}
}
function checkLease() {
  assert(Number.isSafeInteger(start) && Number.isSafeInteger(end) && start<=Date.now() &&
    end-start<=30*60_000 && end<=hardEnd && Date.now()+cleanupMs+1000<end,
    'current finite root compiler lease with cleanup headroom required');
  check();
}
async function inventory(root, copyTo) {
  const files = new Map(); let bytes=0, count=0;
  async function visit(relative) {
    check(); const path=`${root}/${relative}`, st=await fs.lstat(path); check();
    assert(!st.isSymbolicLink(),'symlink source refused');
    if(st.isDirectory()) {
      const entries=await fs.readdir(path); check();
      assert(entries.length<=2048,'source entry cap');
      for(const name of entries.sort())await visit(`${relative}/${name}`);
    } else {
      assert(st.isFile() && st.size<=4*1024**2 && ++count<=2048,'source file/type cap');
      bytes+=st.size; assert(bytes<=32*1024**2,'source byte cap');
      const fd=await fs.open(path,constants.O_RDONLY|constants.O_NOFOLLOW);
      let data;
      try {
        // A growing live file cannot turn this into an unbounded readFile allocation.
        const buffer=Buffer.alloc(st.size+1);let offset=0;
        while(offset<buffer.length) {
          check();const {bytesRead}=await fd.read(buffer,offset,Math.min(65536,buffer.length-offset),offset);
          if(!bytesRead)break;offset+=bytesRead;
        }
        data=buffer.subarray(0,offset);
      } finally {await fd.close();}
      check(); assert(data.length===st.size,'source changed while read');
      files.set(relative,data);
    }
  }
  await visit('foundry.toml');
  for(const dir of ['src','test','script']) {
    try {await fs.lstat(`${root}/${dir}`);} catch(e) {if(e.code==='ENOENT'&&dir==='script')continue;throw e;}
    await visit(dir); // Missing nested inputs are never mistaken for an absent optional script root.
  }
  assert.equal(hash(files.get('foundry.toml')),configHash,'unreviewed Forge config refused');
  for(const [name,data] of files)if(name.endsWith('.sol')) {
    // Tokenize strings before comments so comment-like text in strings is preserved.
    const tokens=data.toString().match(/"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\/\/[^\n]*|\/\*[\s\S]*?\*\/|[A-Za-z_$][\w$]*|[^\s]/g) ?? [];
    const clean=tokens.filter(t=>!t.startsWith('//')&&!t.startsWith('/*'));
    for(let i=0;i<clean.length;i++)if(clean[i]==='import') {
      const clause=[]; while(++i<clean.length&&clean[i]!==';')clause.push(clean[i]);
      const paths=clause.filter(t=>t.startsWith('"')||t.startsWith("'"));
      assert(paths.length===1,'unrecognized import');
      const target=paths[0].slice(1,-1);
      assert(/^\.\.?\//.test(target)&&!target.includes('\\'),'external import refused');
      assert(files.has(posix.normalize(posix.join(posix.dirname(name),target))),`import outside snapshot: ${name} -> ${target}`);
    }
  }
  const manifest=Object.fromEntries([...files].sort(([a],[b])=>a<b?-1:a>b?1:0).map(([p,b])=>[p,hash(b)]));
  const digest=hash(JSON.stringify(manifest));
  if(copyTo) {
    const dirs=new Set([copyTo]);
    for(const name of ['src','test','script']) {
      await fs.mkdir(`${copyTo}/${name}`,{mode:0o700});dirs.add(`${copyTo}/${name}`);
    }
    for(const [name,data] of files) {
      check(); const dest=`${copyTo}/${name}`;
      await fs.mkdir(posix.dirname(dest),{recursive:true,mode:0o700});
      await fs.writeFile(dest,data,{flag:'wx',mode:0o400});
      let dir=posix.dirname(dest); while(dir.startsWith(copyTo)){dirs.add(dir);if(dir===copyTo)break;dir=posix.dirname(dir);}
    }
    for(const dir of [...dirs].sort((a,b)=>b.length-a.length))await fs.chmod(dir,0o500);
  }
  return {manifest,digest,bytes};
}
async function binaryDigest(path) {
  const fd=await fs.open(path,constants.O_RDONLY|constants.O_NOFOLLOW);
  try {
    const before=await fd.stat();
    assert(before.isFile()&&before.size<=128*1024**2,'toolchain file/type cap');
    const digest=createHash('sha256'),buffer=Buffer.alloc(65536);let offset=0;
    while(offset<before.size) {
      check();const {bytesRead}=await fd.read(buffer,0,Math.min(buffer.length,before.size-offset),offset);
      assert(bytesRead>0,'toolchain changed while hashing');
      digest.update(buffer.subarray(0,bytesRead));offset+=bytesRead;
    }
    const after=await fd.stat();
    assert(before.size===after.size&&before.mtimeMs===after.mtimeMs,'toolchain changed while hashing');
    return {path,bytes:offset,sha256:digest.digest('hex')};
  } finally {await fd.close();}
}
let scratchRoots;
async function disk() {
  const deadline=Date.now()+4000; let entries=0,scratchBytes=0;
  async function walk(path) {
    check(deadline); let st;
    try {st=await fs.lstat(path);} catch(e) {if(e.code==='ENOENT')return;throw e;}
    check(deadline); assert(++entries<=250000,'scratch entry cap');
    if(st.isDirectory()) {
      const dir=await fs.opendir(path);
      for await(const ent of dir)await walk(`${path}/${ent.name}`);
    } else scratchBytes+=st.size;
    assert(scratchBytes<15*1024**3,'15GiB total scratch budget');
  }
  const space=await fs.statfs(run);check(deadline);
  const freeBytes=space.bavail*space.bsize;
  assert(freeBytes>=50*1024**3,'50GiB free reserve');
  for(const root of scratchRoots)await walk(root);
  return {freeBytes,scratchBytes};
}
async function cleanupGroup() {
  signalGroup('SIGTERM');
  const deadline=Date.now()+3000;
  while(groupAlive()&&Date.now()<deadline) {signalGroup('SIGKILL');await sleep(50);}
  assert(!groupAlive(),'owned process group still alive; slot retained');
  if(childDone)await bounded(childDone,500,'child close');
  assert(childClosed,'child not reaped; slot retained');
  child=undefined;childDone=undefined;
}
function launch(command,args,options) {
  check();assert(!child,'previous child not cleaned');
  // No await separates the final cancellation/deadline check and spawn.
  child=spawn(command,args,{...options,detached:true});childClosed=false;
  childDone=new Promise((resolve,reject)=>{
    child.once('error',reject);
    child.once('close',(code,signal)=>{childClosed=true;resolve({code,signal});});
  });
  childDone.catch(()=>{});
  return child;
}
async function save() {
  if(!report)return;
  const data=JSON.stringify(record,null,2);
  await report.truncate(0);await report.write(data,0,'utf8');await report.sync();
}
try {
  report=await fs.open(reportPath,'wx',0o600);
  log=await fs.open(logPath,'wx',0o600);
  lease=await fs.open(slot,'wx',0o600);
  await lease.writeFile(JSON.stringify(owner));await lease.sync();
  record.slotOwner=owner;await save();check();
  if(mode!=='pin') {
    checkLease();assert(/^[a-f0-9]{64}$/.test(expected??''),'expected root handoff digest required');
    watchdog=setTimeout(()=>stop('absolute lease deadline'),end-Date.now()-cleanupMs);
    let ps='';
    const scan=launch('/bin/ps',['-axo','pid=,comm='],{stdio:['ignore','pipe','pipe']});
    scan.stdout.on('data',chunk=>{ps+=chunk; if(ps.length>1024**2)stop('ps output cap');});
    scan.stderr.resume();
    const outcome=await bounded(childDone,2000,'process scan');
    await cleanupGroup();check();assert.equal(outcome.code,0,'process scan failed');
    assert(!ps.split('\n').some(x=>/(?:^|\/)(anvil|forge|solc)(\s|$|-)/.test(x)),'heavy slot occupied');
  }
  const pins=JSON.parse(await fs.readFile('/tmp/efs-required-query-paid2-20260914.QM7xI0/pins.json','utf8'));
  scratchRoots=[...new Set([...pins.scratchRoots,run])];
  assert(scratchRoots.every(p=>typeof p==='string'&&p.startsWith('/tmp/efs-')),'unexpected scratch root');
  record.resources=await bounded(disk(),5000,'resource preflight');
  snapshot=`${run}/${label}.source`;
  await fs.mkdir(snapshot,{mode:0o700});
  const source=await bounded(inventory(lab,snapshot),10000,'source snapshot');
  record.source=source.manifest;record.sourceDigest=source.digest;record.snapshot=snapshot;
  if(mode!=='pin')assert.equal(source.digest,expected,'source digest differs from root handoff');
  const verify=await bounded(inventory(snapshot),10000,'snapshot verification');
  assert.equal(verify.digest,source.digest,'snapshot differs from pinned bytes');
  if(mode==='pin')record.outcome={code:0,signal:null,noChild:true};
  else {
    const state=`${run}/${label}.state`;
    await fs.mkdir(state,{mode:0o700});
    for(const dir of ['tmp','out','cache'])await fs.mkdir(`${state}/${dir}`,{mode:0o700});
    record.compiler={forge:await bounded(binaryDigest(forge),5000,'Forge binary hash'),solc:await bounded(binaryDigest(solc),5000,'solc binary hash')};
    await fs.access(forge,constants.X_OK);await fs.access(solc,constants.X_OK);
    const common=['--use',solc,'--offline','--root',snapshot,'--config-path',`${snapshot}/foundry.toml`,'--build-info','--build-info-path',`${state}/build-info`];
    const args=mode==='size'?['build','--sizes',...common]:['test',...common,'-vv',...(mode==='red'?['--match-contract','SignedClaimArchiveTest','--match-test','test_joined_diverged_cas_current_rejection_and_missing_body']:mode==='cold'?['--match-contract','ColdParentReadBudgetTest']:mode==='consumer'?['--match-contract','SignedClaimArchiveTest','--match-test','test_paid_consumer_emits_exact_first_last_action_hash_without_storage']:[])];
    record.args=args;
    record.resourcesBeforeSpawn=await bounded(disk(),5000,'fresh resource preflight');
    await save();
    await new Promise(resolve=>setImmediate(resolve));
    checkLease(); // Fresh absolute lease + cleanup headroom, immediately before spawn.
    launch(forge,args,{cwd:snapshot,env:{PATH:'/usr/bin:/bin',HOME:process.env.HOME,TMPDIR:`${state}/tmp`,FOUNDRY_PROFILE:'default',FOUNDRY_OUT:`${state}/out`,FOUNDRY_CACHE_PATH:`${state}/cache`,FOUNDRY_FFI:'false'},stdio:['ignore',log.fd,log.fd]});
    record.pid=child.pid;
    clearTimeout(watchdog);
    watchdog=setTimeout(()=>stop('ten-minute/lease watchdog'),Math.min(600000,end-Date.now()-cleanupMs));
    const budgetCheck=async()=>{
      try {record.resourcesLatest=await bounded(disk(),5000,'resource monitor');}
      catch(e){stop(e.message);}
      if(!cancelled&&child&&!childClosed)budgetTimer=setTimeout(()=>{budgetWork=budgetCheck();},5000);
    };
    budgetTimer=setTimeout(()=>{budgetWork=budgetCheck();},5000);
    await save();record.outcome=await childDone;
    if(cancelled)throw new Error(cancelled);
  }
} catch(e) {record.failure=String(e.stack??e);}
finally {
  clearTimeout(watchdog);clearTimeout(budgetTimer);
  try {await cleanupGroup();record.ownedProcessesStopped=true;}
  catch(e){record.failure??=String(e);record.ownedProcessesStopped=false;}
  clearTimeout(kills);
  if(budgetWork)await budgetWork;
  clearTimeout(budgetTimer);
  record.stopReason=cancelled; if(cancelled)record.failure??=cancelled;
  record.finishedAt=new Date().toISOString();
  if(lease&&record.ownedProcessesStopped) {
    try {
      const current=await fs.lstat(slot),owned=await lease.stat();
      assert(current.ino===owned.ino&&current.dev===owned.dev,'slot ownership changed; refusing unlink');
      assert.equal(JSON.parse(await fs.readFile(slot,'utf8')).token,owner.token,'slot token changed');
      await fs.unlink(slot);record.slotReleased=true;
    } catch(e){record.failure??=String(e);}
  }
  await lease?.close();await log?.close();await save();await report?.close();
  if(record.ownedProcessesStopped)for(const [kind,fn] of Object.entries(handlers))process.off(kind,fn);
}
console.log(JSON.stringify({reportPath,logPath,sourceDigest:record.sourceDigest,...record.outcome,failure:record.failure,ownedProcessesStopped:record.ownedProcessesStopped}));
process.exitCode=record.failure?1:record.outcome?.code??1;
