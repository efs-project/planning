// Offline falsifiers of the independent checker, using copies of the real packet.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const run='/tmp/efs-b-archive-task1.OXPOfb';
const raw=fs.readFileSync(path.join(run,'paid-1.measurement.json.raw.json'));
const scratch=fs.mkdtempSync(path.join(run,'audit-negative-'));
const cases=[
  ['missing transaction',p=>p.transactions.pop()],
  ['wrong fixture hash',p=>p.fixtures[0].actionsHash='0x'+'00'.repeat(32)],
  ['fabricated getter value',p=>p.branches[0].calls[0].returnData='0x'+'00'.repeat(512)],
  ['edited receipt gas',p=>p.transactions[3].receipt.gasUsed='0x1'],
  ['wrong immutable blob',p=>p.branches.find(b=>b.candidate==='codeblob').blob.code='0x00'],
  ['failed snapshot restore',p=>p.rpc.find(r=>r.request.method==='evm_revert').response.result=false],
];
const results=[];
for(const [name,mutate]of cases){
  const p=JSON.parse(raw);mutate(p);
  const file=path.join(scratch,`case-${results.length}.json`);fs.writeFileSync(file,JSON.stringify(p),{flag:'wx'});
  const result=spawnSync(process.execPath,[path.join(run,'audit-paid.mjs'),file],{encoding:'utf8',timeout:10000,maxBuffer:16384});
  assert(!result.error,`${name}: process failed, not a semantic rejection`);
  assert.equal(result.signal,null);assert.equal(result.status,1,`${name}: forged evidence accepted`);
  assert.match(result.stderr,/AssertionError/);assert(!result.stdout.includes('INDEPENDENT_RAW_AUDIT_PASS'));
  results.push({name,result:'REJECTED',exitCode:result.status});
}
const report={status:'NEGATIVE_CHECKS_PASS',rawSha256:createHash('sha256').update(raw).digest('hex'),checks:results,scratch,scope:'OFFLINE_CHECKER_FALSIFIERS_NO_COMPILER_CHAIN_OR_RPC'};
fs.writeFileSync(path.join(run,'paid-1.audit-negative.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(report,null,2));
