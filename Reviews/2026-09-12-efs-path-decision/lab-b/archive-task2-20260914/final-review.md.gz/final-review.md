# Final whole-archive review

Date: 2026-09-14. **Ready for disposable prototype publication: YES, with nonblocking minor notes.** No Critical or Important findings. This is not approval to merge planning main, adopt a production architecture/API, or deploy to mainnet.

## Scope and method

Reviewed the supplied 1,786-line package `review-1d8356c..08a4d0e.diff` once in sequential portions, the binding semantic seam, implementation plan, progress ledger, and both independent task reviews. Scope is Tasks 1+2 of the Road B signed-claim archive. The package's separately reviewed cold-parent diagnostic and retained artifacts were read for scope separation, not reopened as a separate Files review. No compiler, tests, Anvil, RPC, independent checker rerun, subagent, Git mutation, or source edit occurred. This temporary report is the sole write.

Code references below are relative to `/Users/james/Code/EFS/planning-warroom-b-run/Reviews/2026-09-12-efs-path-decision/lab-b/`. Evidence references are relative to `/tmp/efs-b-archive-task1.OXPOfb/`.

## Strengths and integrated semantic assessment

- **Full-vector authentication remains the common gate.** `src/SignedClaimArchive.sol:60` hashes the complete ordered ABI Action vector and retains the exact signed Intent/digest. Signature recovery requires 65 bytes, low-s, v 27/28 and nonzero matching recovery; empty signatures explicitly report unsupported. Neither expiry nor account code length is used to invent a present or historical authority fact. The retained header/vector is written only on first creation; a same-nonce different digest remains a different claim. The Ledger digest oracle, malformed-signature tests, and omitted/mutated/reordered-vector cases exercise this boundary.
- **Bodies cannot acquire coverage implicitly.** The shared retain/attach path checks bounded descriptors, aggregate lengths, unique in-range record-bearing leaves and every Type-qualified body hash before writes (`src/SignedClaimArchive.sol:105,180,200,221`). Global cache existence distinguishes empty bytes from absent bytes, while `selectedRecord` gates bytes on the selected claim's own bitmap. The Task 1 cache-hit test explicitly observes only the local coverage slot being written; repeated correct attachments/retentions observe zero writes. No vector, body or first-importer metadata is overwritten.
- **Discovery remains claims, not acceptance.** First creation adds one append-only posting per PUBLISH/REUSE leaf, including repeated Record IDs; retries add none. Unknown Types and arbitrary signed tuples can be retained without admission. This is coherent with the archive's sole positive proof label, `AUTHOR_SIGNATURE_VERIFIED`, and its absence of Ledger calls, forwarding entrypoints or validity state (`src/SignedClaimArchive.sol:93,149`).
- **Representations share semantics rather than duplicating them.** Packed rows preserve all nine logical fields in eight storage words. Codeblob stores STOP plus the complete ABI vector and reads exactly 288 bytes from `65 + 288*leaf`; the neutral location event creates no authority label (`src/SignedClaimArchive.sol:239,273`). The 1/2/64 equivalence tests cover full reconstruction, headers/signatures, repeated postings, attached-empty versus missing bodies and high-bit coverage. Codeblob retries additionally preserve CREATE nonce, event absence, carrier bytes and header. The only alias remains packed (`src/SignedClaimArchive.sol:297`).
- **Destination authority remains separate and current.** The joined test uses a real Ledger, reaches the exact stale CAS error before the missing unrelated body, checks the full six-field HEAD/count/nonces snapshot, and separately publishes selected bytes as the actual destination caller. It also reads the retained claim while current destination policy is still rejecting (`test/SignedClaimArchive.t.sol:116`). No source binding, unrelated action or signer authority is replayed through archival.
- **Bounds remain intact across both representations.** The shared limits are 64 actions/body inputs, 8,192 raw body bytes per call, and 37,316/18,468-byte calldata ceilings. Fixed getters are statically bounded; selected bytes cannot exceed the bounded cache insertion size, yielding the specified 8,352-byte maximum ABI return. Tests cover the exact calldata envelopes and one-byte excess, leaf 63, staged bits, invalid descriptors and full vector reconstruction. Codeblob's largest carrier is 18,497 bytes, not an unbounded vector deployment.

## Findings and dispositions

### Critical

None found.

### Important

None found.

### Minor

1. **The unknown-kind fixture was not carried into codeblob equivalence.** `test/SignedClaimArchive.t.sol:431` constructs only kind 1/2 actions for the Task 2 representation fixture. The plan also asked to carry the Task 1 unknown-kind/high-revision arbitrary tuple into both representations; its kind-251 case currently runs against the packed alias only (`test/SignedClaimArchive.t.sol:299,391`). The rich Task 2 vectors cover all fields and high revisions, and the shared validator plus fixed-width codeblob decoder supports unknown uint8 kinds by inspection, so this is a narrow regression-test gap, not a demonstrated semantic failure. If the lab is extended, add a no-body unknown-kind tuple comparison for both candidates and assert exact tuple/vector hash. **Disposition: defer; nonblocking for prototype publication.**
2. **Intentional lint noise.** The controlled retained-time comparisons and `(i / 2) * 2` paired-posting assertion intentionally trigger lint (`test/SignedClaimArchive.t.sol:111,480,516`). Reordering the arithmetic would change the intended round-down semantics. Narrow explanatory annotations are optional if maintained. **Disposition: retain prior deferral; no semantic or measurement blocker.**
3. **Oversized Forge-only harness.** The retained final log warns that the archive test harness initcode is 120,638 bytes (`final-green-1.log:119`). This does not establish deployability of that harness under ordinary chain limits, and must not be presented that way. Actual archives and the paid consumer are independently sized/deployed. **Disposition: retain prior deferral; split only if this harness itself needs ordinary deployment. No archive runtime-limit waiver.**

## Verification evidence and representation decision

The retained final suite reports **102 passed, zero failed/skipped**, including all 17 archive tests (`final-green-1.log:238-258`). Final semantic and size reports identify the same compiler-source digest `2b9373560bd428de43f63c8190552752896b323f90a7415261321b5b29c35e62`, exit code 0, stopped owned processes and released slot. I independently hashed the current archive, archive tests and consumer: each matches both final manifests and the raw paid packet. The full compiler snapshot also includes separately coordinated cold-parent work; this review does not relabel that wider snapshot as exactly the scoped five-commit package.

The size log reports runtime/initcode of 6,160/6,361 bytes for packed and alias, 6,324/6,525 for codeblob, and 658/684 for the consumer (`final-size-1.log:135,183-187`). The generic carrier artifact is not used to claim its actual deployed payload size.

I independently recomputed raw-packet SHA-256 `87e0c642e9d2a923f01c9e2bbc57e28b4a553822c046bdbd98d6457a5c8a3177` and checked targeted inventory/provenance fields: 21 unique transactions, six same-baseline branches, pinned timestamp 1800000100, two reads per branch, 5/9/257 getter observations and 353/641/18,497-byte blobs. The retained root audit separately supplies full receipt/transaction/header/getter/signature/compiler recomputation; its six retained offline corruption cases all reject. This review did not rerun that independent checker or treat runner self-check booleans as independent proof.

**KEEP PACKED is the correct predeclared outcome.** At N=2, codeblob retention uses 585,046 gas versus packed's 578,709, failing the required strict savings at both N=2 and N=64. Codeblob's cheaper reads and N=64 retention do not override that conjunction. N=1 retention is 429,833 packed / 456,481 codeblob; N=64 is 9,817,718 / 8,571,876. Paid first reads are 50,726 / 36,787; last reads at N=2/64 are 50,738 / 36,799; N=1 has two distinct same-leaf receipts at the first-read figures. Deployments are reported separately at 1,387,764 / 1,423,208; consumer deployment is 195,652 (`paid-1.root-audit-final.json`). All figures are whole local receipts for the frozen no-body vector workload, with no estimated overhead subtraction.

The original measured runner hash remains `a2ca8e4297dfcd2bed61952a64dd442a8b2f82ed53f9385a9c97795cc2ef3f1e`. The supplied package/ledger identify `08a4d0e` as removing two trailing comment spaces only; do not substitute a current runner hash for the measured bytes. Likewise, preserve the old Task 1-only cost-unmeasured status as dated evidence rather than silently treating it as current.

## Assessment

**Approved for disposable prototype publication, with the three minor dispositions above.** The full archive integrates immutable signature evidence, explicit local byte recovery, bounded discovery and representation equivalence without introducing a source/destination authority shortcut. Publication should carry the retained raw evidence, its independent audit and the declared packed-choice rule together.

This earns neither historical native/contract source proof nor source admission, accepted typed membership, current validity, destination binding authority, Core changes, production SDK/API adoption, permanent B selection or protocol affordability. Historical native/source-state proof remains explicitly **UNSUPPORTED**. The paid evidence is **OWNED_LOCAL_RPC_OBSERVATION**, not authenticated state proof or the cost of the joined recovery/destination admission workflow.
