// Independent root checker. Imports no runner/checker code; derives named fixtures.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
const e=createRequire(import.meta.url)(process.env.EFS_ETHERS_PATH||'/Users/james/Code/EFS/planning-efs21/Reviews/2026-09-04-mvp-rehearsal/node_modules/ethers');
const [packetPath,outputPath]=process.argv.slice(2);
assert(packetPath&&process.argv.length>=3&&process.argv.length<=4,'raw packet path and optional output path');
const raw=fs.readFileSync(packetPath);assert(raw.length<64*1024**2);
const p=JSON.parse(raw),c=e.AbiCoder.defaultAbiCoder();
const hash=b=>createHash('sha256').update(b).digest('hex');
const eq=(a,b,m='raw evidence mismatch')=>assert.equal(a,b,m), deep=(a,b,m='raw evidence structure mismatch')=>assert.deepEqual(a,b,m);
const low=x=>x===null?null:x.toLowerCase();
const act='tuple(uint8,bytes32,bytes32,bytes32,bytes32,bytes32,bytes32,uint32,bytes32)';
const intent='tuple(bytes32,bytes32,address,uint64,uint64,bytes32,bytes32)';
const domain=e.TypedDataEncoder.hashDomain({name:'EFS2-RoadB-Lab',version:'1'});
const fields=[{name:'realmId',type:'bytes32'},{name:'coreCodeCommitment',type:'bytes32'},{name:'author',type:'address'},{name:'nonce',type:'uint64'},{name:'deadline',type:'uint64'},{name:'acceptanceProfile',type:'bytes32'},{name:'indexObligations',type:'bytes32'},{name:'actionsHash',type:'bytes32'}];
const author=new e.Wallet(e.toBeHex(0xa11ce,32));
const mnemonic='test test test test test test test test test test test junk';
const deployer=e.HDNodeWallet.fromPhrase(mnemonic,undefined,"m/44'/60'/0'/0/0").address;
const importer=e.HDNodeWallet.fromPhrase(mnemonic,undefined,"m/44'/60'/0'/0/1").address;
const fixture=new Map([1,2,64].map(n=>{
  const actions=Array.from({length:n},(_,i)=>[1,e.id('archive/measure/type/1'),e.id(`archive-body-${n}-${i}`),e.ZeroHash,e.ZeroHash,e.ZeroHash,e.ZeroHash,0,e.ZeroHash]);
  const x=[e.id('archive/measure/realm/1'),e.id('archive/measure/core/1'),author.address,n,1,e.id('archive/measure/acceptance/1'),e.id('archive/measure/index/1')];
  const encoded=c.encode([act+'[]'],[actions]),actionsHash=e.keccak256(encoded);
  const message=Object.fromEntries(fields.slice(0,7).map((f,i)=>[f.name,x[i]]));message.actionsHash=actionsHash;
  const digest=e.TypedDataEncoder.hash({name:'EFS2-RoadB-Lab',version:'1'},{PublicationIntent:fields},message);
  return[n,{n,actions,x,encoded,actionsHash,digest,signature:author.signingKey.sign(digest).serialized}];
}));
eq(p.schema,'efs-lab-b/archive-representation/1');eq(p.evidenceLevel,'OWNED_LOCAL_RPC_OBSERVATION');
eq(p.chain.stopped,true);assert(!p.failure,'runner failure packet');
eq(p.transactions.length,21);eq(p.branches.length,6);eq(p.fixtures.length,3);
const archiveAbi=[`function retainSignedClaim(${intent},${act}[],bytes,tuple(uint16,bytes)[]) returns(bytes32)`,`function claim(bytes32) view returns(${intent},bytes32,uint16,bytes32,bytes32,uint8,uint64,uint8,address,uint64)`,`function actionAt(bytes32,uint16) view returns(${act})`,'function selectedRecord(bytes32,uint16) view returns(bytes32,bytes32,bool,bytes)','function signedRecordClaimCount(bytes32) view returns(uint64)','function signedRecordClaimAt(bytes32,uint64) view returns(bytes32,uint16)','event ClaimRetained(bytes32 indexed,address,uint16)'];
const ai=new e.Interface(archiveAbi),ci=new e.Interface(['function readAction(address,bytes32,uint16)','event ActionRead(bytes32 indexed,uint16 indexed,bytes32)']);
const inventory=new Set();
for(let i=0;i<p.rpc.length;i++) {const r=p.rpc[i];eq(r.request.id,i+1);if(r.response){eq(r.response.id,i+1);eq(r.response.jsonrpc,'2.0');}}
function observation(branch,method,params,result) {
  const matches=p.rpc.filter(r=>r.branch===branch&&r.request.method===method&&JSON.stringify(r.request.params)===JSON.stringify(params)&&r.response&&!r.response.error&&JSON.stringify(r.response.result)===JSON.stringify(result));
  assert(matches.length>0,`no matching raw RPC: ${branch} ${method}`);
}
function txCheck(t,from,to,data,nonce) {
  assert(!inventory.has(t.hash),'duplicate paid transaction');inventory.add(t.hash);
  const d=e.Transaction.from(t.rawTransaction),r=t.receipt,b=t.block,o=t.transaction;
  eq(d.hash,t.hash);eq(e.keccak256(t.rawTransaction),t.hash);eq(o.hash,t.hash);eq(r.transactionHash,t.hash);
  for(const v of [d,o,r]) {eq(low(v.from),low(from));eq(low(v.to),low(to));}
  eq(d.data,data);eq(o.input,data);eq(d.nonce,nonce);eq(BigInt(o.nonce),BigInt(nonce));
  eq(d.chainId,31337n);eq(BigInt(o.chainId),31337n);eq(d.value,0n);eq(BigInt(o.value),0n);
  eq(d.type,0);eq(d.gasPrice,2_000_000_000n);eq(BigInt(r.effectiveGasPrice),d.gasPrice);
  eq(BigInt(r.status),1n);assert(BigInt(r.gasUsed)>0n&&BigInt(r.gasUsed)<=d.gasLimit);
  eq(b.hash,r.blockHash);eq(o.blockHash,b.hash);eq(b.number,r.blockNumber);eq(o.blockNumber,b.number);
  eq(o.transactionIndex,r.transactionIndex);eq(b.transactions[Number(BigInt(r.transactionIndex))],t.hash);
  assert(BigInt(b.gasUsed)<=30_000_000n&&BigInt(b.gasLimit)===30_000_000n);
  for(const l of r.logs){eq(l.transactionHash,t.hash);eq(l.blockHash,b.hash);eq(l.blockNumber,b.number);eq(l.transactionIndex,r.transactionIndex);assert(l.removed!==true);}
  observation(t.branch,'eth_sendRawTransaction',[t.rawTransaction],t.hash);
  observation(t.branch,'eth_getTransactionReceipt',[t.hash],r);
  observation(t.branch,'eth_getTransactionByHash',[t.hash],o);
  observation(t.branch,'eth_getBlockByHash',[b.hash,false],b);
}
function runtimeCheck(observed,address,branch,basis,expected) {
  eq(low(observed.address),low(address));eq(observed.blockHash,basis.blockHash);eq(observed.blockNumber,basis.blockNumber);
  eq(observed.code,expected);eq(observed.codehash,e.keccak256(expected));eq(observed.runtimeBytes,e.dataLength(expected));
  assert(observed.runtimeBytes<=24_576);
  observation(branch,'eth_getCode',[address,{blockHash:basis.blockHash,requireCanonical:true}],expected);
}
eq(p.build.compilerVersion,'0.8.30');eq(p.build.input.settings.evmVersion,'cancun');eq(p.build.input.settings.viaIR,true);eq(p.build.input.settings.optimizer.enabled,true);eq(p.build.input.settings.optimizer.runs,200);
assert(p.build.compilerInputFile.startsWith('/tmp/efs-b-archive-task1.OXPOfb/')||p.build.compilerInputFile.startsWith('/private/tmp/efs-b-archive-task1.OXPOfb/'));
const buildRaw=fs.readFileSync(process.env.EFS_ARCHIVE_BUILD_INFO||p.build.compilerInputFile),build=JSON.parse(buildRaw);
eq(hash(buildRaw),p.build.compilerInputFileSha256);assert(build.input&&build.output&&build.solcVersion==='0.8.30');deep(build.input,p.build.input);
for(const [path,s] of Object.entries(p.build.input.sources)) {
  const bytes=Buffer.from(s.content);eq(p.build.sources[path].sha256,hash(bytes));eq(p.build.sources[path].keccak256,e.keccak256(bytes));eq(p.source.inventory[path].sha256,hash(bytes));
}
const addresses={},runtimes={},deployments={};
for(const [nonce,name] of ['packed','codeblob','consumer'].entries()) {
  const ts=p.transactions.filter(t=>t.branch==='setup'&&t.label===`deploy/${name}`);eq(ts.length,1);const t=ts[0],a=p.build.artifacts[name];
  const contract={packed:'SignedClaimArchivePacked',codeblob:'SignedClaimArchiveCodeBlob',consumer:'ArchiveReadConsumer'}[name];
  const compiled=build.output.contracts[name==='consumer'?'test/ArchiveReadConsumer.sol':'src/SignedClaimArchive.sol'][contract];
  eq(a.creation,'0x'+compiled.evm.bytecode.object);eq(a.runtime,'0x'+compiled.evm.deployedBytecode.object);deep(a.immutableReferences,compiled.evm.deployedBytecode.immutableReferences||{});deep(a.abi,compiled.abi);
  eq(a.metadata.settings.evmVersion,'cancun');eq(a.metadata.settings.optimizer.runs,200);eq(a.metadata.settings.viaIR,true);
  for(const [path,s] of Object.entries(a.metadata.sources))eq(p.build.sources[path].keccak256,s.keccak256);
  txCheck(t,deployer,null,a.creation,nonce);assert(e.dataLength(a.creation)<=49_152);
  const address=e.getCreateAddress({from:deployer,nonce});addresses[name]=address;eq(low(t.receipt.contractAddress),low(address));
  const bytes=e.getBytes(a.runtime);for(const refs of Object.values(a.immutableReferences))for(const ref of refs){eq(ref.length,32);bytes.set(e.getBytes(domain),ref.start);}
  const expected=e.hexlify(bytes);runtimes[name]=expected;
  runtimeCheck(p.deployments[name],address,'setup',{blockHash:t.block.hash,blockNumber:t.block.number},expected);
  eq(p.deployments[name].transactionHash,t.hash);deployments[name]=BigInt(t.receipt.gasUsed);
}
eq(p.baseline.hash,p.transactions.find(t=>t.label==='deploy/consumer').block.hash);
const cells={},seenBranches=new Set();
for(const b of p.branches) {
  assert(!seenBranches.has(b.id));seenBranches.add(b.id);assert(['packed','codeblob'].includes(b.candidate));eq(b.id,`${b.n}/${b.candidate}`);
  const f=fixture.get(b.n);assert(f);eq(b.timestamp,1_800_000_100);eq(b.baseline.hash,p.baseline.hash);
  const pf=p.fixtures.find(x=>x.n===b.n);eq(pf.encodedActions,f.encoded);eq(pf.actionsHash,f.actionsHash);eq(pf.digest,f.digest);eq(pf.signature,f.signature);eq(pf.caller,importer);deep(pf.bodies,[]);
  eq(c.encode([intent],[fields.slice(0,7).map(x=>pf.intent[x.name])]),c.encode([intent],[f.x]));
  eq(c.encode([act+'[]'],[pf.actions.map(x=>['kind','typeId','bodyHashOrRecordId','purpose','subject','role','target','expectedRevision','salt'].map(k=>x[k]))]),f.encoded);
  eq(e.recoverAddress(f.digest,pf.signature),author.address);
  const address=addresses[b.candidate],ts=p.transactions.filter(t=>t.branch===b.id);eq(ts.length,3);
  const t=ts.find(t=>t.label==='retain');assert(t);
  txCheck(t,importer,address,ai.encodeFunctionData('retainSignedClaim',[f.x,f.actions,f.signature,[]]),0);
  eq(t.hash,b.retentionHash);eq(t.block.hash,b.retentionBasis.blockHash);eq(t.block.number,b.retentionBasis.blockNumber);eq(Number(BigInt(t.block.timestamp)),b.timestamp);
  eq(t.block.parentHash,p.baseline.hash);eq(t.receipt.logs.length,1);
  const l=t.receipt.logs[0];eq(low(l.address),low(address));eq(l.topics.length,2);eq(l.topics[0],e.id('ClaimRetained(bytes32,address,uint16)'));eq(l.topics[1],f.digest);
  const [loc,n]=c.decode(['address','uint16'],l.data);eq(Number(n),b.n);eq(loc,b.vectorLocation);
  for(const name of ['packed','codeblob','consumer'])runtimeCheck(b.runtime[name],addresses[name],b.id,b.retentionBasis,runtimes[name]);
  if(b.candidate==='codeblob'){assert(loc!==e.ZeroAddress);runtimeCheck(b.blob,loc,b.id,b.retentionBasis,'0x00'+f.encoded.slice(2));eq(b.blob.runtimeBytes,65+288*b.n);}else eq(loc,e.ZeroAddress);
  const expectedCalls=[];
  function expected(fn,args,result){expectedCalls.push({fn,args,data:ai.encodeFunctionData(fn,args),result});}
  const sig=e.Signature.from(f.signature);
  expected('claim',[f.digest],c.encode([intent,'bytes32','uint16','bytes32','bytes32','uint8','uint64','uint8','address','uint64'],[f.x,f.actionsHash,b.n,sig.r,sig.s,sig.v,0,1,importer,b.timestamp]));
  for(let leaf=0;leaf<b.n;leaf++) {
    const action=f.actions[leaf],rid=e.keccak256(c.encode(['bytes32','bytes32','bytes32'],[e.id('efs2/record/1'),action[1],action[2]]));
    expected('actionAt',[f.digest,leaf],c.encode([act],[action]));
    expected('signedRecordClaimCount',[rid],c.encode(['uint64'],[1]));
    expected('signedRecordClaimAt',[rid,0],c.encode(['bytes32','uint16'],[f.digest,leaf]));
    expected('selectedRecord',[f.digest,leaf],c.encode(['bytes32','bytes32','bool','bytes'],[rid,action[1],false,'0x']));
  }
  eq(b.calls.length,expectedCalls.length);
  for(let i=0;i<b.calls.length;i++) {
    const got=b.calls[i],want=expectedCalls[i];eq(got.fn,want.fn);deep(got.args,want.args);eq(got.calldata,want.data);eq(got.returnData,want.result);eq(low(got.to),low(address));eq(got.blockHash,t.block.hash);eq(got.blockNumber,t.block.number);
    observation(b.id,'eth_call',[{to:address,data:want.data},{blockHash:t.block.hash,requireCanonical:true}],want.result);
  }
  eq(b.paidReads.length,2);const readGas=[];
  for(const [i,leaf] of [0,b.n-1].entries()) {
    const rtx=ts.find(t=>t.label===`read/${i}/${leaf}`);assert(rtx);
    txCheck(rtx,importer,addresses.consumer,ci.encodeFunctionData('readAction',[address,f.digest,leaf]),i+1);
    const prev=i===0?t:ts.find(t=>t.label===`read/0/0`);eq(rtx.block.parentHash,prev.block.hash);eq(Number(BigInt(rtx.block.timestamp)),b.timestamp+i+1);
    const r=rtx.receipt;eq(r.logs.length,1);const event=r.logs[0];eq(low(event.address),low(addresses.consumer));deep(event.topics,[e.id('ActionRead(bytes32,uint16,bytes32)'),f.digest,e.toBeHex(leaf,32)]);
    eq(event.data,c.encode(['bytes32'],[e.keccak256(c.encode([act],[f.actions[leaf]]))]));
    eq(b.paidReads[i].leaf,leaf);eq(b.paidReads[i].transactionHash,rtx.hash);eq(b.paidReads[i].blockHash,rtx.block.hash);eq(BigInt(b.paidReads[i].gasUsed),BigInt(r.gasUsed));readGas.push(BigInt(r.gasUsed));
  }
  cells[b.n]??={};cells[b.n][b.candidate]={retainGas:BigInt(t.receipt.gasUsed),paidReads:readGas};
}
eq(inventory.size,21);eq(seenBranches.size,6);
const snap=p.rpc.filter(r=>r.request.method==='evm_snapshot'),rev=p.rpc.filter(r=>r.request.method==='evm_revert');eq(snap.length,7);eq(rev.length,6);
for(let i=0;i<6;i++){eq(rev[i].response.result,true);eq(rev[i].request.params[0],snap[i].response.result);eq(p.branches[i].previousSnapshot,snap[i].response.result);eq(p.branches[i].snapshot,snap[i+1].response.result);}
const choice=[2,64].every(n=>cells[n].codeblob.retainGas<cells[n].packed.retainGas)?'codeblob':'packed';
const out={status:'INDEPENDENT_RAW_AUDIT_PASS',evidenceLevel:'OWNED_LOCAL_RPC_OBSERVATION_NOT_STATE_PROOF',rawSha256:hash(raw),transactions:21,branches:6,deployments,cells,choice,scope:'NO_BODY_VECTOR_RETENTION_AND_PAID_ACTION_READS_ONLY'};
const output=JSON.stringify(out,(_,v)=>typeof v==='bigint'?v.toString():v,2)+'\n';
if(outputPath)fs.writeFileSync(outputPath,output,{flag:'wx'});
console.log(output);
