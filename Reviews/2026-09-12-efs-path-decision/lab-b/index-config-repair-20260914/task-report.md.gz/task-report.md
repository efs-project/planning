# Task 1: index configuration repair

## 2026-09-14 12:17 UTC — DRAFT_READY, not installed

Read the full approved main `Reviews/2026-09-12-efs-path-decision/index-config-repair-plan-20260914.md`. Used executing-plans and TDD; parent owns actual compilation/RED/GREEN. No Forge, compiler, Anvil, RPC, Git, dependency installation, or subagents used. No live lab source edited. No guards implemented, including in drafts. Await explicit root INSTALL RED; withdrawal correction retains its live input freeze.

Draft root: `/tmp/efs-index-config-repair-draft/`. These are complete proposed files, copied from the live baseline then patched only in the authorized regions. Before installing, compare live hashes with the baseline pins below; if another task changed a file, apply only the reviewed method diff rather than overwriting it.

### Exact changes

- `src/IndexModule.sol`: add only `error E_MANDATORY_FAMILY();` for compiling RED. `_declare` remains unchanged and unenforced.
- `test/IndexConfigExpectation.t.sol`: invert `test_admin_family_downgrade_does_not_invalidate_signed_publication` into `test_required_downgrade_refuses_without_invalidating_signed_publication`, retaining genuine pre-mutation signature and exact state/posting controls. Add test-only `IndexConfigDeclarationProbe.constructor`/`declareForTest`, private `_refuseDeclaration`, and four tests:
  - `test_internal_required_declarations_are_constructor_only`: real internal required addition, optional promotion, required-start replacement, and optional overwrite all refuse exact error; base constructor and optional/UNKNOWN controls.
  - `test_signed_write_survives_other_author_optional_and_generation_progress`: Bob's actual contract-authored native publication advances admission 5; late optional declaration plus generation bump do not consume Alice's nonce. Real listing cursor captured immediately before the generation bump refuses exactly `E_CURSOR` without an intervening admission. Alice's untouched signature then admits exact Record/posting at admission 6. Mandatory COMPLETE and optional PARTIAL remain distinct.
  - `test_actual_module_replacement_rejects_old_signature`: actual new module attachment, exact `E_INTENT(4)` for untouched old input, unchanged counters/nonce, and successful freshly signed indexed publication.
  - `test_default_unset_index_keeps_zero_obligation_and_unknown_listing`: newly deployed default-unset Ledger, genuine signed publication/retained Record, and zero-index Lens UNKNOWN rather than COMPLETE.
- `test/IncomingQuotes.t.sol`: only replace `test_downgraded_mandatory_families_never_complete` with `test_required_family_downgrades_refuse_and_queries_remain_complete`. Exact error for base and actual specialized family, constructor-required COMPLETE from 1 through actual admission 4, then both real readers return the exact quote. Genuine late-attachment and detached-gap tests remain untouched.
- `test/FilesJoined.t.sol`: only edit `test_reader_rechecks_parent_and_scope_coverage`. Establish actual healthy folder/point plus specialized required-family COMPLETE; detach, admit signed BINARY d1, reattach, admit signed BINARY d2; verify records/evidence, stale-then-current processed frontier, sticky real gap, unchanged obligation/parent postings, fresh Basis, both families PARTIAL, folder `E_INCOMPLETE`, and exact same revision bytes/tags. Payload comparison excludes any full-basis comparison. This is combined family incompleteness, not selective isolated degradation.

### Expected RED focus (not observed yet)

Seven focused tests are the five IndexConfigExpectationTest tests plus the renamed IncomingQuotes test and the single Files coverage test. Expect three behavior failures before guards: required downgrade refusal, runtime internal required addition refusal, and base/specialized downgrade refusal. The signed-progress, replacement, default-unset, and real-gap controls should already pass. Any compile failure or unrelated assertion failure is not valid RED and must be corrected before implementing guards.

Existing callback/coverage/withdrawal controls are not edited or waived: `FilesJoinedTest.test_required_parent_callback_failure_rolls_back`, `test_index_constructor_pins_exact_reviewed_profile`, `test_revision_acceptance_history_and_parent_backlinks`, `LedgerMatrixTest.test_failed_index_module_reverts_and_coverage_is_honest`, the MatchedRollback tests, LedgerImport cursor controls, IncomingQuotes late/gapped coverage controls, and the separate withdrawal characterization/correction. Current real Files and selective-reference constructors provide specialized-family positive controls; the new helper is not a substitute for them.

### SHA-256 baseline → RED draft

| File | Live baseline | RED draft |
|---|---|---|
| src/IndexModule.sol | `43618a994095f3d73902f23521c055c8950cdc043f8d8ca74e9b83aef67f1592` | `88a3e007125484fba6f00d7b330804faa9d57d26068a4bb47dc214507ebbccd8` |
| test/IndexConfigExpectation.t.sol | `4254d19282b227c62d0cde6a2df33080c48d866513ac1f8524bb59a564e5a61d` | `bef6a87c19a49b4b8e409869ae9589f61f012e5c155b4e5176f030efc96e7ef3` |
| test/IncomingQuotes.t.sol | `ef136398bb2f3fc476768fe880b3e05b81143b765f26eeef86c9fac5700cdd03` | `e683ce0198b343ba3f4b7888f0ba9cc04d002158ec75606eb84928066cb07150` |
| test/FilesJoined.t.sol | `65d4dc7514cc026d7879aec158fd562953b63135161730af0290f3d25be00b18` | `f162b2bc4feec913b9b2d92f90d76abcd7dde8613f02471b695946321cddc4e4` |

Source-only review checked helper side effects, literal fixture ordinals, exact errors, signed input reuse, cursor ordering, constructor lifetimes, and scoped diffs. Compilation/execution remains UNKNOWN until root's gate. No production/proxy policy, COMPLETE-at-write guarantee, arbitrary callback safety, new backfill, paid-cost revision, or native historical-proof claim. The old paid/query/archive packets are not touched.

## INSTALL RED authorized — REDREADY

Root explicitly released the withdrawal gate after commit `d60318efbc6b3a71a0914ebb11b2ebeebab08893` and authorized installation. All four live baseline hashes exactly matched the table before installation. Installed only their reviewed diffs using apply_patch; all four live hashes now exactly equal the RED draft column. No enforcing guards were added; `_declare` remains the original unconditional store/event body. Await root's actual seven-test compiling RED before any guard implementation. No execution or Git performed by worker.

Protected live pins verified both before and after installation:

- `test/FilesJoinedConsumer.sol`: `0d45a6603f4fd055abe59307d93bcf651b4d66d98d89854a073265d0860713ae`
- `test/FilesWithdrawal.t.sol`: `f191978d5881a9660ceb58b3424f90bb5361503230905f3cf9dae5c5b2b8e0d2`

## Root-observed RED → GREENREADY

Root's first `index-config-repair-red.{json,log}` invocation compiled but selected zero tests because of the anchored harness selector. Child exit 0 is not RED or GREEN evidence. That failed selection attempt is retained, not relabeled; worker made no source changes in response.

Root corrected only the harness selector and reported actual compiling RED in `index-config-repair-red-2.{json,log}` at source digest `1433275f55abdc42bbd29ac9e03a950ec8fdc6a6f1cb2bb20b21d58f68168013`: exactly seven tests, four PASS controls and three intended assertion FAILs (required downgrade refusal, runtime internal required mutation refusal, and base/specialized required downgrade refusal). Root reports nonempty test-count validation and gate cleanup. This is parent-reported executed evidence, not a worker rerun.

After explicit GREEN authorization, reverified all four RED source pins and applied only the two combined conditions in `IndexModule._declare`, plus concise direct-deployment lifecycle comments. The guard rejects any existing mandatory redeclaration and rejects `mandatory=true` after construction. No RED test/assertion or other source changed. Draft files remain the retained RED stage.

GREENREADY live `src/IndexModule.sol` SHA-256: `2072d1b796af5143c3341363778bfd3b875c19da9dd3970c26b4cfac790a82a9`.

All three test file hashes remain exactly the RED draft column; protected consumer `0d45a660…` and withdrawal `f191978d…` pins were rechecked unchanged. Worker performed no compiler/test/RPC/Git execution. Actual GREEN, full suite, sizes, and independent review remain pending root's frozen-input gates; this stage is not a passing or completed-repair claim.

## Final executed evidence and implementation closure

Root's actual full gate `index-config-repair-full.{json,log}` at `62e1f17ff2d3a042078063cab0ca158a40e0e97ef00e686ffcad168ddea67cf9`, 12:32:18.781–12:33:11.469 UTC, reports 162 passing executions, zero failures/skips: 128 distinct named cases and 34 inherited repeats (17 base Files tests also execute in each of two derived suites). All seven targeted cases are present. Normal-size gate `index-config-repair-size.{json,log}`, 12:34:35.550–12:35:28.084 UTC, succeeds at the identical frozen input. Both report owned-process stop and slot release. The complete independent review was read, SHA-256 `27dc27a3d9c5ce43030aef130ee5159b0f903d5810a23f2ce0a540c0b14a200e`: SpecCompliant / QualityApproved, no open Critical/Important/actionable Minor issue. Existing warnings are not represented as a warning-free build.

Root reports exact four-file source commit `30073fcdeedfdc24a4d54004afc209ab9c8b8773`. Worker performed no Git action. Normal Solidity 0.8.30 / optimizer200 / viaIR / Cancun sizes (runtime / compiled initcode, constructor arguments excluded): IndexModule 4,179 / 6,021; SelectiveReferenceIndexModule 5,240 / 8,515; FilesParentIndex 5,339 / 9,325; FilesJoinedConsumer 15,865 / 19,976; Ledger 17,280 / 17,670. Oversized test-harness warnings are not application deployment sizes or paid costs.

Implementation status: DONE_WITH_CONCERNS, with the plan's bounded policy and coverage limits retained. The old address/code-hash gap is repaired only by constructor-freezing required declarations in these reviewed direct modules. Actual detached coverage remains PARTIAL despite unchanged configuration; no COMPLETE-at-write precondition, proxy policy, mutable semantic-epoch ABI, arbitrary callback safety, new backfill, or new paid measurement was added.

Retained packet location: `lab-b/index-config-repair-20260914/`. Its mechanically checked manifest is the authority for exact payload inventory, compressed/raw hashes, byte counts and roundtrip results. The generator checks every frozen source/config/script against the execution inventories, complete actual RED2/size compiler source content, actual seven-case RED/full-suite counts, only-Index RED-to-GREEN source change, unchanged tests/consumer/withdrawal pins, full/size identity and gate cleanup. It preserves the initial zero-test report/log as non-evidence and retains full task report and independent review. Retention does not rerun tests, compiler, RPC, paid workflows or Git, and leaves old paid/query/archive packets untouched.
