# Independent review: constructor-frozen required index declarations

2026-09-14. Reviewer: `/root/files_paid_runner`, independent of this repair's implementer. This review covers only the approved compact-B Index configuration repair, not my separately authored paid Files instrumentation.

## Status

Final verdict: **SpecCompliant; QualityApproved** for the authorized direct-deployment prototype repair. No Critical or Important finding identified. The actual root-owned full-suite and normal-size outputs were independently read at the same GREEN input. This is not a production or protocol-adoption review.

I read the full approved `planning/Reviews/2026-09-12-efs-path-decision/index-config-repair-plan-20260914.md`, the implementer's full task report, the exact four-file baseline-to-RED delta, the sole RED-to-GREEN guard delta, relevant complete source modules, and the actual root-owned RED and full-suite reports/logs. I did not compile, run Forge, use RPC/Anvil, run Git, change source, or create subagents. Light local hash/inventory/log checks corroborate the frozen evidence rather than repeat the experiments.

## Scope and frozen source evidence

Source paths below are relative to `planning-warroom-b-run/Reviews/2026-09-12-efs-path-decision/lab-b/`.

- Baseline commit: `d60318efbc6b3a71a0914ebb11b2ebeebab08893`; independently compared its retained `files-withdraw-fix-size.source` snapshot with `index-config-repair-red-2.source`.
- Only baseline-to-RED differences in the complete src/test/script inventories are `src/IndexModule.sol`, `test/IndexConfigExpectation.t.sol`, `test/IncomingQuotes.t.sol`, and `test/FilesJoined.t.sol`. Script inventories are identical.
- RED source digest: `1433275f55abdc42bbd29ac9e03a950ec8fdc6a6f1cb2bb20b21d58f68168013`.
- GREEN source digest: `62e1f17ff2d3a042078063cab0ca158a40e0e97ef00e686ffcad168ddea67cf9`.
- Independently recomputed all 47 file hashes against each RED-2, full-suite and normal-size report's frozen source manifest. Every pin matched. The sole manifest difference from RED to GREEN is `src/IndexModule.sol`; full-suite and size source manifests and digests are identical.
- GREEN Index SHA-256: `2072d1b796af5143c3341363778bfd3b875c19da9dd3970c26b4cfac790a82a9`.
- Frozen test pins, unchanged RED to GREEN: IndexConfigExpectation `bef6a87c19a49b4b8e409869ae9589f61f012e5c155b4e5176f030efc96e7ef3`; IncomingQuotes `e683ce0198b343ba3f4b7888f0ba9cc04d002158ec75606eb84928066cb07150`; FilesJoined `f162b2bc4feec913b9b2d92f90d76abcd7dde8613f02471b695946321cddc4e4`.
- Ledger, Interfaces, existing consumer/profile modules, rollback tests, archive/query/paid runners, and the separate withdrawal correction remain unchanged. Protected Files consumer is `0d45a6603f4fd055abe59307d93bcf651b4d66d98d89854a073265d0860713ae`; withdrawal test is `f191978d5881a9660ceb58b3424f90bb5361503230905f3cf9dae5c5b2b8e0d2`.

## What the implementation actually fixes

`src/IndexModule.sol:90` applies both conditions inside `_declare`: an existing mandatory family cannot be redeclared, and a new/promoted mandatory family cannot be declared when the deployed contract has code. The only GREEN addition is this combined guard using the exact error, plus concise lifecycle comments; the error declaration was already present without enforcement for RED.

This protects the reviewed modules' required family set and start admissions, not merely the optional public setter. Base construction at `src/IndexModule.sol:66` installs the five required families using the actual current admission plus one. The existing `SelectiveReferenceIndexModule` and `FilesParentIndex` constructors still add their distinct required families during construction; they do not redeclare existing mandatory keys. The runtime maintenance paths do not invoke `_declare`.

Optional declaration remains admin-only and can still introduce/update optional families. `lastProcessed`, live occurrence-related posting counts, and cursor generation remain mutable. None of these routine progress values has been added to the signed obligation.

The unchanged `src/Ledger.sol:788` commitment still hashes attached module address and runtime codehash (or explicit zero when unset). The reviewed constructor-fixed declarations are therefore no longer silently downgradable via their public/internal declaration path behind that identity. An actual module replacement changes the obligation and rejects a stale signature. This is not a claim that codehash generally commits arbitrary mutable storage or arbitrary malicious derived-module behavior.

## Seven focused cases: substance, not successful-call assertions

1. **Required downgrade with a queued signature** — `test/IndexConfigExpectation.t.sol:35`. A real Alice-signed seed publication creates the initial posting. A second exact intent/signature/actions/bodies bundle is signed before mutation. Non-admin mutation returns exact `E_ADMIN`; admin downgrade returns exact `E_MANDATORY_FAMILY`. Counters, nonce, coverage, generation, runtime identity and obligation remain unchanged. The untouched signed input is then actually executed and checked against exact body, Type, first admission, occurrence count, publication ordinal, new posting, live/count delta and COMPLETE coverage.
2. **Internal mandatory mutation** — `test/IndexConfigExpectation.t.sol:109`. A test-only derived module exposes the real internal `_declare`, not mocked coverage or direct test storage edits. New mandatory addition, optional promotion, mandatory-start replacement and mandatory-to-optional replacement each refuse the exact error. Real constructor success, undeclared UNKNOWN, and genuinely optional PARTIAL controls distinguish refusal from a blanket broken setter.
3. **Unrelated progress does not invalidate queued writes** — `test/IndexConfigExpectation.t.sol:131`. Bob performs real contract-authored actions and publication while Alice's intent is pending. An optional declaration and generation bump occur without consuming Alice's nonce or changing her original input/obligation. A real partial cursor is obtained immediately before the generation bump; without an intervening admission, continuation refuses exact `E_CURSOR`. Alice's untouched signature then admits the exact expected Record and posting at the checked ordinal. Required COMPLETE and optional PARTIAL remain separate.
4. **Actual module replacement** — `test/IndexConfigExpectation.t.sol:181`. A distinct module is deployed and attached. The original signed bundle is submitted unchanged and refuses exactly `E_INTENT(4)` with zero counters/nonce. A freshly signed replacement obligation succeeds and maintains the new module's posting. This tests actual address replacement rather than manually corrupting an intent field.
5. **Default-unset index** — `test/IndexConfigExpectation.t.sol:202`. A fresh Ledger truly starts without a module. A zero-obligation signed publication succeeds and retains the exact Record; its zero-index Lens returns UNKNOWN, not fabricated COMPLETE. This is explicitly an ablation control, not equivalence to required indexing.
6. **Base plus real specialized declaration** — `test/IncomingQuotes.t.sol:319`. A real Pair/Quote fixture yields an admitted Record; attempts to downgrade both BY_TYPE and the specialized reference-position family refuse exactly. Both maintained families remain COMPLETE from 1 through actual admission 4. Both actual scan and indexed readers return the exact admitted singleton. Existing genuine late-attachment and detached-gap tests at lines 300 and 308 remain unchanged and still exhaust PARTIAL pages.
7. **Real Files coverage gap** — `test/FilesJoined.t.sol:474`. Healthy actual point and folder controls precede an index detach, signed `d1` publication, reattachment and signed `d2` publication. Exact records/evidence, stale-then-current processed frontier, sticky gap, unchanged obligation and retained parent-posting digest are checked. At a fresh Basis, scope and parent coverage are PARTIAL and folder reading refuses `E_INCOMPLETE`, while exact revision bytes and both tag results remain equal to their pre-gap values. The comparison intentionally excludes full encodings with a changed Basis. This demonstrates combined-family incompleteness, not independent single-family degradation.

Existing callback atomicity, stale/corrupt response, current-basis, immutable parent membership, and withdrawal controls were not weakened. In particular, `FilesJoinedTest.test_required_parent_callback_failure_rolls_back`, the Ledger mandatory-callback coverage test, the MatchedRollback suite, and IncomingQuotes late/gapped controls remain substantive and appear passing in the actual full log.

## Executed evidence and chronology

Evidence lives under `/tmp/efs-b-archive-task1.OXPOfb/`.

- `index-config-repair-red.{json,log}` compiled but selected **zero tests**. Its successful child exit is neither RED nor GREEN. The unanchored selector retry is a harness correction, not a source/assertion change; the first attempt must remain retained as a non-evidence attempt.
- `index-config-repair-red-2.{json,log}`, 12:28:55.433–12:29:14.069 UTC, compiled at the frozen RED input and ran exactly **7 cases: 4 PASS controls, 3 intended refusal-assertion FAILs, 0 skipped**. The failures are mandatory downgrade refusal, internal mandatory mutation refusal, and base/specialized family downgrade refusal. Both report and complete log were read. Cleanup/slot release are reported true.
- Only after root observed that RED and explicitly authorized implementation was the internal guard added; all three test files remain byte-identical to RED.
- `index-config-repair-full.{json,log}`, 12:32:18.781–12:33:11.469 UTC, compiled Solc 0.8.30 at the frozen GREEN input and reports **162 PASS, 0 FAIL, 0 skipped** across 14 suites. Independent log parsing confirms **128 distinct test names plus 34 inherited repeats**: the 17 base Files cases also execute in each of the paid and withdrawal derived test contracts. All seven targeted cases are present. Cleanup/slot release are reported true.
- `index-config-repair-size.{json,log}`, 12:34:35.550–12:35:28.084 UTC, completed successfully at the identical GREEN input, with cleanup/slot release reported true. Its frozen config uses Solc 0.8.30, Cancun, via-IR and optimizer runs 200, without a raised code-size limit. The application-module size table was independently read: IndexModule **4,179 runtime / 6,021 compiled initcode bytes**; SelectiveReferenceIndexModule **5,240 / 8,515**; FilesParentIndex **5,339 / 9,325**; FilesJoinedConsumer **15,865 / 19,976**; Ledger **17,280 / 17,670**. These are compiled initcode lengths before appended constructor arguments, not paid deployment measurements. All named modules have ample normal runtime/initcode margins. Oversized test-harness initcode warnings are explicitly not deployment evidence for application modules. Existing lint warnings remain; this is not a warning-free-build claim.

## Remaining explicit limits

- **Configuration identity is not COMPLETE-at-write.** The actual gap control proves that the same attached module/configuration can be PARTIAL while accepted writes continue. Read consumers must retain coverage qualifications; an eventual write-time coverage precondition would be separate design/work.
- **Direct construction only.** `address(this).code.length` is used solely for these reviewed direct deployments. This is not a proxy initializer, an upgradeable testnet policy, or a permanent protocol decision about configurable indexes. Future same-address mutable configuration needs its own explicitly bound semantic commitment/epoch and review.
- **Reviewed implementations, not arbitrary callbacks.** This does not prove reentrancy safety, detect malicious assembly/storage mutation or arbitrary upgradeable module internals, or add an execution-time external configuration getter to Ledger. Existing bounded callback rollback evidence is retained, not generalized.
- **No backfill or optional-data completion.** Optional families are declarations only in this lab; they remain PARTIAL. The patch neither reconstructs detached history nor adds per-scope repair or a new query ABI.
- **No new economics or portability proof.** No paid workflow, archive or query measurement was rerun. Old price packets remain tied to their original sources. There is no state-proof/native-history portability, MUD parity, production-readiness, or full EFS-readiness claim.

## Findings

Critical: none identified. Important: none identified. Minor: no blocking/actionable repair issue identified. Compiler shadowing warnings in test-local scoped variables remain non-semantic housekeeping, not an excuse to alter frozen assertions during this gate.

The authorized repair is ready for root's exact-file publication and evidence retention. No further source change or new paid run is required by this review. The explicit limitations above remain open design/engineering gates, not claims that this repair has solved the entire index layer.
