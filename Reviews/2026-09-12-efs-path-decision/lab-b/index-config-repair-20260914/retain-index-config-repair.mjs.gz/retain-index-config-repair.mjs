import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {gzipSync, gunzipSync} from 'node:zlib';
import {fileURLToPath} from 'node:url';

// Mechanical retention only: no subprocess, compiler, test, RPC, Git or live source mutation.
const run = '/tmp/efs-b-archive-task1.OXPOfb';
const work = '/Users/james/Code/EFS/planning-warroom-b-run';
const dest = work + '/Reviews/2026-09-12-efs-path-decision/lab-b/index-config-repair-20260914';
const task = work + '/.superpowers/sdd/index-config-repair-plan-20260914/task-1-report.md';
const main = '/Users/james/Code/EFS/planning/Reviews/2026-09-12-efs-path-decision';
const review = '/tmp/efs-b-index-config-repair-review-20260914.md';
const redDigest = '1433275f55abdc42bbd29ac9e03a950ec8fdc6a6f1cb2bb20b21d58f68168013';
const greenDigest = '62e1f17ff2d3a042078063cab0ca158a40e0e97ef00e686ffcad168ddea67cf9';
const sha = b => createHash('sha256').update(b).digest('hex');
function read(file) {
  const st = fs.lstatSync(file);
  assert(st.isFile() && !st.isSymbolicLink() && st.size <= 64 * 1024 * 1024, 'regular bounded input ' + file);
  return fs.readFileSync(file);
}
const json = file => JSON.parse(read(file));
const encode = value => Buffer.from(JSON.stringify(value, null, 2) + '\n');
const zero = json(run + '/index-config-repair-red.json');
const red = json(run + '/index-config-repair-red-2.json');
const full = json(run + '/index-config-repair-full.json');
const size = json(run + '/index-config-repair-size.json');
const gates = [zero, red, full, size];
assert.equal(sha(read(review)), '27dc27a3d9c5ce43030aef130ee5159b0f903d5810a23f2ce0a540c0b14a200e');
for (const gate of gates) {
  assert.equal(sha(JSON.stringify(gate.source)), gate.sourceDigest);
  assert.equal(gate.sourceDigest, gate.expectedSourceDigest);
  assert.equal(gate.outcome.signal, null);
  assert(gate.ownedProcessesStopped && gate.slotReleased && !gate.failure && !gate.stopReason);
  assert.equal(Object.keys(gate.source).length, 47);
  for (const [name, hash] of Object.entries(gate.source)) {
    assert(!path.isAbsolute(name) && !name.split('/').includes('..'));
    assert.equal(sha(read(path.join(gate.snapshot, name))), hash, gate.label + ': ' + name);
  }
}
assert.equal(zero.sourceDigest, redDigest);
assert.equal(zero.outcome.code, 0);
assert.equal(red.sourceDigest, redDigest);
assert.equal(red.outcome.code, 1);
assert.deepEqual(red.tests, {passed: 4, failed: 3, skipped: 0});
for (const g of [full, size]) {
  assert.equal(g.sourceDigest, greenDigest);
  assert.equal(g.outcome.code, 0);
  assert.deepEqual(Object.keys(g.source).filter(n => g.source[n] !== red.source[n]), ['src/IndexModule.sol']);
}
assert.deepEqual(full.source, size.source);
assert.equal(red.source['src/IndexModule.sol'], '88a3e007125484fba6f00d7b330804faa9d57d26068a4bb47dc214507ebbccd8');
assert.equal(size.source['src/IndexModule.sol'], '2072d1b796af5143c3341363778bfd3b875c19da9dd3970c26b4cfac790a82a9');
for (const [name, hash] of Object.entries({
  'test/IndexConfigExpectation.t.sol': 'bef6a87c19a49b4b8e409869ae9589f61f012e5c155b4e5176f030efc96e7ef3',
  'test/IncomingQuotes.t.sol': 'e683ce0198b343ba3f4b7888f0ba9cc04d002158ec75606eb84928066cb07150',
  'test/FilesJoined.t.sol': 'f162b2bc4feec913b9b2d92f90d76abcd7dde8613f02471b695946321cddc4e4',
  'test/FilesJoinedConsumer.sol': '0d45a6603f4fd055abe59307d93bcf651b4d66d98d89854a073265d0860713ae',
  'test/FilesWithdrawal.t.sol': 'f191978d5881a9660ceb58b3424f90bb5361503230905f3cf9dae5c5b2b8e0d2',
})) for (const g of gates) assert.equal(g.source[name], hash, name);

const zeroLog = read(run + '/' + zero.label + '.log').toString();
const redLog = read(run + '/' + red.label + '.log').toString();
const fullLog = read(run + '/' + full.label + '.log').toString();
assert.match(zeroLog, /No tests found in project/);
assert.equal([...zeroLog.matchAll(/^\[(?:PASS|FAIL)/gm)].length, 0);
assert.match(redLog, /4 tests passed, 3 failed, 0 skipped/);
const primaryRed = redLog.split('Failing tests:')[0];
const failed = [...primaryRed.matchAll(/^\[FAIL: .*?\] (\S+) /gm)].map(m => m[1]);
assert.deepEqual(failed.sort(), [
  'test_required_downgrade_refuses_without_invalidating_signed_publication()',
  'test_internal_required_declarations_are_constructor_only()',
  'test_required_family_downgrades_refuse_and_queries_remain_complete()',
].sort());
assert.equal([...primaryRed.matchAll(/^\[PASS\]/gm)].length, 4);
assert.match(fullLog, /162 tests passed, 0 failed, 0 skipped/);
const names = [...fullLog.matchAll(/^\[PASS\] (\S+) /gm)].map(m => m[1]);
assert.equal(names.length, 162);
assert.equal(new Set(names).size, 128);
const multiplicities = new Map();
for (const n of names) multiplicities.set(n, (multiplicities.get(n) ?? 0) + 1);
assert.equal([...multiplicities.values()].filter(n => n === 3).length, 17);
assert([...multiplicities.values()].every(n => n === 1 || n === 3));
const targeted = [
  ...failed, 'test_signed_write_survives_other_author_optional_and_generation_progress()',
  'test_actual_module_replacement_rejects_old_signature()',
  'test_default_unset_index_keeps_zero_obligation_and_unknown_listing()',
  'test_reader_rechecks_parent_and_scope_coverage()',
];
for (const n of targeted) assert(names.includes(n), 'GREEN targeted ' + n);

const payloads = new Map();
function add(name, file, description) {
  assert.equal(path.basename(name), name);
  assert(!payloads.has(name));
  payloads.set(name, {bytes: read(file), description});
}
function generated(name, value, description) {
  assert(!payloads.has(name));
  payloads.set(name, {bytes: encode(value), description});
}
for (const gate of gates) for (const ext of ['json', 'log']) {
  add(gate.label + '.' + ext, run + '/' + gate.label + '.' + ext, gate === zero
    ? 'Complete original zero-test selector attempt; explicitly NOT RED or GREEN evidence.'
    : 'Complete original gate report or unabridged execution log.');
}
let sizeBuild;
for (const [name, gate, file] of [
  ['red-2-full-compiler-info.json', red, run + '/index-config-repair-red-2.state/build-info/025f421f367ba8be.json'],
  ['size-full-compiler-info.json', size, run + '/index-config-repair-size.state/build-info/49ff0d8bea02e56b.json'],
]) {
  const build = json(file);
  assert(build.input?.sources && build.output?.contracts && build.output?.sources);
  assert.equal(build.solcVersion, '0.8.30');
  assert.equal(build.input.settings.viaIR, true);
  assert.equal(build.input.settings.optimizer.enabled, true);
  assert.equal(build.input.settings.optimizer.runs, 200);
  assert.equal(build.input.settings.evmVersion, 'cancun');
  for (const [source, value] of Object.entries(build.input.sources)) assert.equal(sha(value.content), gate.source[source], source);
  add(name, file, 'Original full compiler input/output including sources, settings, AST, ABI, metadata, creation/deployed bytecode and immutable references.');
  if (gate === size) sizeBuild = build;
}
const sizes = {};
for (const [source, contract, runtime, init] of [
  ['src/IndexModule.sol', 'IndexModule', 4179, 6021],
  ['src/SelectiveReferenceIndexModule.sol', 'SelectiveReferenceIndexModule', 5240, 8515],
  ['test/FilesJoinedProfile.sol', 'FilesParentIndex', 5339, 9325],
  ['test/FilesJoinedConsumer.sol', 'FilesJoinedConsumer', 15865, 19976],
  ['src/Ledger.sol', 'Ledger', 17280, 17670],
]) {
  const evm = sizeBuild.output.contracts[source][contract].evm;
  assert.equal(evm.deployedBytecode.object.replace(/^0x/, '').length / 2, runtime);
  assert.equal(evm.bytecode.object.replace(/^0x/, '').length / 2, init);
  sizes[contract] = {runtimeBytes: runtime, compilerInitcodeBytes: init};
}
for (const [name, gate] of [['red-2', red], ['green', size]]) {
  const files = {};
  for (const [source, hash] of Object.entries(gate.source)) {
    const bytes = read(path.join(gate.snapshot, source));
    files[source] = {sha256: hash, bytes: bytes.length, content: bytes.toString('utf8')};
    assert.equal(sha(files[source].content), hash, 'UTF-8 escrow ' + source);
  }
  generated(name + '-frozen-source-inventory.json', {sourceDigest: gate.sourceDigest, sourceHashes: gate.source, files},
    'Mechanical UTF-8 escrow of all 47 gate-inventoried sources/config/scripts, checked against frozen execution snapshot.');
}
add('red-2-IndexModule.sol', red.snapshot + '/src/IndexModule.sol', 'Exact error-only RED module, no guards.');
add('green-IndexModule.sol', size.snapshot + '/src/IndexModule.sol', 'Exact GREEN module, only two conditions plus lifecycle comments after actual RED.');
for (const file of ['IndexConfigExpectation.t.sol', 'IncomingQuotes.t.sol', 'FilesJoined.t.sol']) {
  add('unchanged-' + file, size.snapshot + '/test/' + file, 'Exact repaired test file, unchanged from actual RED2 through GREEN/size.');
}
add('frozen-foundry.toml', size.snapshot + '/foundry.toml', 'Exact frozen normal build configuration, not changing live configuration.');
add('task-report.md', task, 'Complete implementer report through full/size evidence, final independent review and source commit closure.');
add('independent-final-review.md', review, 'Complete execution-linked final independent SpecCompliant / QualityApproved review.');
add('approved-plan.md', main + '/index-config-repair-plan-20260914.md', 'Approved narrow reversible direct-deployment repair plan.');
add('prior-executed-finding.md', main + '/index-obligation-config-finding-20260914.md', 'Original executed admin-downgrade finding, historical provenance rather than current unrepaired behavior.');
add('bounded-remedy-review.md', '/tmp/efs-b-index-config-remedy-review-20260914.md', 'Pre-implementation bounded alternatives and limits review.');
add('outer-forge-gate-at-retention.mjs', run + '/forge-gate.mjs', 'Outer harness as retained after selector/count correction, not a claim of byte identity for every historical attempt; each original invocation is in its report.');
add('outer-forge-gate-at-retention.test.mjs', run + '/forge-gate.test.mjs', 'Outer harness test source at retention, not run by this packager.');
add('retain-index-config-repair.mjs', fileURLToPath(import.meta.url), 'This apply_patch-authored mechanical retention generator; no experiment rerun.');

const manifest = {
  kind: 'DISPOSABLE_DIRECT_DEPLOYMENT_REQUIRED_INDEX_DECLARATION_REPAIR',
  sourceCommit: '30073fcdeedfdc24a4d54004afc209ab9c8b8773', sourceCommitAuthority: 'ROOT_REPORTED; NO_WORKER_GIT',
  sourceDigest: greenDigest, redSourceDigest: redDigest,
  tests: {initialAttempt: {selected: 0, childExit: 0, evidentiaryStatus: 'NOT_RED_OR_GREEN'},
    red: {passed: 4, failed: 3, skipped: 0, cases: 7, intendedFailures: failed},
    green: {executionsPassed: 162, distinctNamedCases: 128, inheritedRepeats: 34, failures: 0, skipped: 0, targetedCases: targeted},
    assertionsUnchangedAfterRed: true},
  review: {verdict: 'SPEC_COMPLIANT_QUALITY_APPROVED', sha256: sha(read(review))},
  change: 'INTERNAL_DECLARE_ONLY_TWO_CONDITIONS_AND_COMMENTS_AFTER_RED; NO_LEDGER_ABI_OR_INTENT_SCHEMA_CHANGE',
  behavior: 'REQUIRED_SET_AND_START_CONSTRUCTOR_FROZEN_IN_REVIEWED_DIRECT_MODULES; OPTIONAL_PROGRESS_GENERATION_AND_WITHDRAWAL_MAINTENANCE_PRESERVED',
  sizes: {compiler: 'Solidity 0.8.30 viaIR optimizer200 Cancun', ...sizes, constructorArgumentsExcludedFromCompilerInitcode: true},
  gates: gates.map(g => ({label: g.label, startedAt: g.startedAt, finishedAt: g.finishedAt,
    sourceDigest: g.sourceDigest, exitCode: g.outcome.code, ownedProcessesStopped: g.ownedProcessesStopped,
    slotReleased: g.slotReleased, evidentiaryStatus: g === zero ? 'ZERO_TEST_NON_EVIDENCE' : 'EXECUTED_EVIDENCE'})),
  limits: 'CONFIGURATION_NOT_COMPLETE_AT_WRITE; REAL_GAPS_REMAIN_PARTIAL; NO_PROXY_POLICY_OR_UNIVERSAL_MUTABLE_INDEX_ABI; NO_ARBITRARY_CALLBACK_PROOF; NO_BACKFILL; NO_NEW_PAID_COSTS_OR_PORTABILITY_PROOF',
  custody: 'Mechanical retention, no new tests/compiler/RPC/Git or paid run. Complete frozen source inventories and compiler bytes verified before writing. Old paid/query/archive packets untouched.',
  files: {},
};
assert(!fs.existsSync(dest), 'refuse an existing packet');
fs.mkdirSync(dest);
for (const [name, item] of payloads) {
  const raw = item.bytes;
  const gzName = name + '.gz';
  fs.writeFileSync(path.join(dest, gzName), gzipSync(raw, {level: 9}), {flag: 'wx'});
  const gz = read(path.join(dest, gzName));
  assert.deepEqual(gunzipSync(gz), raw, 'byte roundtrip ' + name);
  manifest.files[gzName] = {rawBytes: raw.length, rawSha256: sha(raw), gzipBytes: gz.length,
    gzipSha256: sha(gz), roundtripVerified: true, description: item.description};
}
manifest.totals = Object.values(manifest.files).reduce((a, f) => ({files: a.files + 1,
  rawBytes: a.rawBytes + f.rawBytes, gzipBytes: a.gzipBytes + f.gzipBytes}), {files: 0, rawBytes: 0, gzipBytes: 0});
const encoded = encode(manifest);
fs.writeFileSync(path.join(dest, 'manifest.json'), encoded, {flag: 'wx'});
assert.deepEqual(json(path.join(dest, 'manifest.json')), manifest);
console.log(JSON.stringify({status: 'RETENTION_BYTE_ROUNDTRIP_PASS', dest, manifestSha256: sha(encoded), ...manifest.totals}, null, 2));
