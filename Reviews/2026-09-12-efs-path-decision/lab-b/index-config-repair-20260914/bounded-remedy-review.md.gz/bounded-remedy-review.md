# B index configuration: bounded remedy review

2026-09-14, source-only recommendation. No implementation, compiler, RPC, Git, or new measured outcomes. Withdrawal tests and paid evidence remain frozen. This is a reversible prototype proposal, not an owner-ratified execution-contract policy.

## Recommendation

Choose **constructor-frozen mandatory declarations** for this bounded repair. Protect the internal declaration function, not just the public optional setter. Preserve optional declarations, index progress, cursor generation, and the current Ledger obligation encoding. Explicitly limit the resulting claim to the reviewed direct-deployment modules: their required declaration set and coverage-start configuration cannot change after construction. This closes the demonstrated admin downgrade without adding an execution-time external getter to Core.

The smallest coherent version is two conditions in `IndexModule._declare`:

```solidity
if (_family[family].mandatory || (mandatory && address(this).code.length != 0)) {
    revert E_MANDATORY_FAMILY();
}
```

This is proposed pseudocode, not an applied patch. Reject even an identical redeclaration of an existing mandatory family; current constructors declare each once. The first condition prevents optional downgrade, required-from changes, and constructor duplicate replacement. The second prevents a future derived runtime entry point from adding a required family or promoting an optional one after deployment. Both current derived constructors still run before runtime code exists. This lifecycle test is appropriate to these direct deployments; it is not a proposed proxy-initialization contract.

Changing the required set/profile then means constructing a new reviewed module and having the Ledger admin explicitly attach it. A new module address changes the existing obligation hash and makes an old signed intent fail `E_INTENT(4)`. Late attachment honestly remains PARTIAL; this repair must not pretend that a new module already indexed history. Deploying/attaching a replacement is the reversible experiment boundary, not an in-place change to an already deployed immutable module.

## Source facts and limits

All code pointers below are relative to `planning-warroom-b-run/Reviews/2026-09-12-efs-path-decision/lab-b/`.

- `src/IndexModule.sol:65`: base constructor declares five mandatory families from `admissions + 1`; `attachedFrom` is immutable. `:78` authorizes `declareOptional` using the module's immutable deployment admin, which need not be the Ledger admin. `:89` currently overwrites any family, without preserving mandatory status or start. There is no base external add/change-mandatory operation, but `_declare` is an internal capability available to derived code.
- `src/SelectiveReferenceIndexModule.sol:45` and `test/FilesJoinedProfile.sol:70` configure immutable profile fields and add their required family in constructors. Their runtime callbacks do not declare families. They read Core state through view calls and append real first-admission postings after `super.onAdmission`.
- `src/Ledger.sol:788` currently commits exactly `keccak256(abi.encode(moduleAddress, moduleCodehash))`, or zero when unset. `:248` compares it at signed ingress; `:224`, `:303`, and `:398` capture it for native/import/convenience paths. `:946` allows only the Ledger admin to attach a module, with no interface validation. This is not a universal guarantee about arbitrary module storage or malicious replacement code.
- `src/IndexModule.sol:95` advances processed/publication state and posting heads on ordinary admissions. `:124` returns COMPLETE only for mandatory/from-1/up-to-date/ungapped families. New optional declarations stay PARTIAL; undeclared families are UNKNOWN. `:84` advances cursor generation after backfill/reindex, but the lab has no actual gap-repair/backfill operation: `gapped` remains sticky. Preserve that honesty; do not claim a new backfill implementation.
- `src/IndexModule.sol:113` releases live by-Type/by-author counts on withdrawal without removing historical postings. Frozen configuration must not freeze those counters, redefine withdrawal, or make retained content disappear.

The original finding's executed result is reported in main `Reviews/2026-09-12-efs-path-decision/index-obligation-config-finding-20260914.md`, not rerun here. `test/IndexConfigExpectation.t.sol:60` performs the genuine admin downgrade after signing, and `:69` submits the unchanged signed publication. The source confirms why the current characterization expects success.

**Do not overclaim:** immutable configuration is not immutable coverage. Detach, publish, and reattach the same module can make coverage PARTIAL while the address/codehash returns to its old value. The old signature can still be accepted. If a write itself promises COMPLETE discovery at admission, that requires a separate explicit coverage precondition; this repair does not add one. Consumers must still validate their actual read basis and coverage. Existing `indexObligations` also never promises that arbitrary administrator-selected code obeys the reviewed implementation.

## Alternative: mutable semantic configuration commitment

Use this only if changing mandatory configuration on the same deployed module is an actual requirement. Bind `keccak256(abi.encode(module, codehash, semanticConfigCommitment))` into the existing intent field, with a domain-separated configuration identity covering required family/profile/start semantics. A monotonic configuration epoch can accompany a rolling commitment to distinguish change-and-restore; it must advance on every authorized obligation-affecting change and never on admission progress. Do not hash `lastProcessed`, `lastPublication`, posting counts, current COMPLETE/PARTIAL, or routine frontier updates. Do not reuse cursor `generation` without changing and specifying its currently different meaning.

This alternative needs a new bounded read interface, fail-closed handling of missing/reverting/malformed getters, and explicit setter authorization. `IIndexModule` at `src/Interfaces.sol:38` currently has only the callback, so `src/LabHarness.sol:43`'s standalone failing module would need deliberate adaptation. Existing IndexModule derivatives inherit a base getter; bespoke modules cannot silently receive a zero fallback. The unset-module branch must remain exactly zero and skip getter/callback calls. Signed destination-import checks must continue using the same commitment; immutable source evidence is not to be rewritten.

A getter checked only at ingress does not settle callback-time configuration mutation. That is additional design/test surface, which is why it is not the recommended bounded patch.

## Callback and authority boundary

`src/Ledger.sol:422` writes nonce/evidence, `:442` commits counters, and `:725` makes the bounded ordinary index CALL. A failed callback reverts the entire publication via `E_INDEX`; effects written by `super` also roll back. Core has no visible execution reentrancy lock or post-callback obligation equality check. Reviewed base maintenance makes no mutating external calls; specialized modules' Core reads are view calls. Acceptance uses static calls (`:578`), not a route to mutate declarations.

Do not infer safety for a newly authorized arbitrary callback from the gas bound. Such code could attempt nested Ledger execution; changing the Ledger module would additionally require Ledger-admin authority (possibly mediated by a contract admin). Constructor-freezing blocks normal `_declare` mutation even from an authorized runtime helper/callback, but does not prove all malicious subclass/storage behavior safe. A future mutable-config route must specify whether mutation during publication is forbidden and enforce it; final equality alone misses change-and-restore unless an epoch records it. Do not silently add a broad reentrancy repair to this patch.

## Tests that must change versus remain

1. Invert `IndexConfigExpectationTest.test_admin_family_downgrade_does_not_invalidate_signed_publication` into a refused-reconfiguration regression. Preserve genuine pre-mutation signing, non-admin `E_ADMIN`, exact refused mandatory mutation, unchanged config/counters/nonce after refusal, then successful untouched signature with COMPLETE coverage and the exact new posting. This intentionally retires the old observed-behavior assertion; keep its historical packet.
2. `IncomingQuotes.t.sol:318`, `test_downgraded_mandatory_families_never_complete`, uses the now-prohibited setup. Replace it with exact refusal of both base by-Type and specialized reference-family mutations plus an actual healthy reader control. Keep existing `test_late_attachment_exhausted_partial_never_complete` and `test_gapped_and_optional_family_never_complete` as genuine coverage-negative cases; do not waive them.
3. `FilesJoined.t.sol:473`, `test_reader_rechecks_parent_and_scope_coverage`, also creates incompleteness by prohibited mutation. Replace that setup with a real detached-admission gap and reattachment of the same Files index, followed by an actual indexed admission and a fresh basis. Prove folder `E_INCOMPLETE`, honest PARTIAL scope/parent coverage, and correct exact point content/tags independent of reverse-parent enumeration. Compare meaningful point payload, not whole result bytes across changed bases. This combines partial families; do not claim selective single-family failure isolation from this replacement.
4. Preserve `LedgerMatrix.t.sol:318` failure/rollback, index-zero ablation, gap, new-optional, and UNKNOWN controls; `LedgerImport.t.sol:171` generation/cursor invalidation; the withdrawal characterization; `MatchedRollback.t.sol` refusal after real maintenance; and `FilesJoinedProfile.sol:120` forced Child refusal after inherited/parent maintenance. None needs semantic relaxation.

## Four strong falsifiers for the proposed patch

1. **Signed downgrade control:** the old pre-signed publication remains valid after an actually refused admin downgrade, while the required declaration and COMPLETE coverage remain intact. Assert precise errors and posting/counter effects; a test that only expects some revert is insufficient.
2. **Internal lifecycle bypass:** a small test-only derived admin helper attempts mandatory addition, optional-to-mandatory promotion, required-start change, and required-to-optional overwrite after deployment. Each must refuse; both current real specialized constructors must still deploy and maintain their extra family. This catches a public-setter-only repair.
3. **Progress is not configuration:** sign author A's publication; perform an unrelated real author B publication, an authorized new optional declaration, and a generation bump; submit A's unchanged signature successfully. Confirm moving frontiers and invalidated old listing cursor without changed obligation identity, then retain honest late/gapped/withdrawal coverage and historical postings.
4. **Atomicity and replacement:** retain exact rollback after a callback refuses following full real maintenance, and add/retain stale signed-intent refusal after actual module replacement. Assert zero-module commitment/operation behavior explicitly. These are separate guarantees: neither implies arbitrary callback reentrancy safety.

## Approval and evidence boundary

Parent/owner still chooses whether constructor-frozen mandatory sets are the intended bounded policy and authorizes the specific source/test changes. A future same-address mutable configuration policy and any COMPLETE-at-write precondition remain owner choices. No production guarantee, old-price correction, native historical-proof claim, or passing repair test is asserted here. Root must obtain actual compiling RED then GREEN for changed behavior and rerun the relevant/full gates; existing characterization passing before repair is not fabricated RED. New source/build evidence must not be conflated with the frozen paid run.

Inspected SHA-256 pins:

- `src/IndexModule.sol`: `43618a994095f3d73902f23521c055c8950cdc043f8d8ca74e9b83aef67f1592`
- `src/Ledger.sol`: `7576874b52a81ebc0f7b64640332b345096e0c09000ed4f09811bdc21dd6c3d5`
- `test/IndexConfigExpectation.t.sol`: `4254d19282b227c62d0cde6a2df33080c48d866513ac1f8524bb59a564e5a61d`
- Main finding: `be20bdb368b83bedc33e38aa313c3ef119711c860d53e424dc52bbf26af6a652`
